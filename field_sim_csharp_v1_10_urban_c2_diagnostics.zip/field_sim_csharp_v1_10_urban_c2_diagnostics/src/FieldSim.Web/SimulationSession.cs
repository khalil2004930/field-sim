using FieldSim.Core;
using FieldSim.Data;
using FieldSim.Domain;
using FieldSim.Scenarios;

public sealed class SimulationSession
{
    private readonly object _gate = new();
    private TacticalState _state = null!;
    private ScenarioOrbatDataset _orbat = null!;
    private ScenarioPackage _package = null!;
    private SupportAssetCatalog _supportCatalog = null!;
    private ScenarioPlacementResolver _placements = null!;
    private Dictionary<string, string> _entityAssignments = new(StringComparer.Ordinal);
    private Dictionary<string, HashSet<string>> _descendantNodeIds = new(StringComparer.Ordinal);
    private readonly List<QueuedFormationOrder> _queuedOrders = [];
    private readonly HashSet<string> _appliedSupportMissionEffects = new(StringComparer.Ordinal);
    private long _nextCommandMessageId = 1;
    private bool _running;
    private int _speed = 1;
    private double _stepAccumulator;
    private long _revision;
    private long _cachedRevision = -1;
    private WebSnapshot? _cachedSnapshot;
    private string _runId = Guid.NewGuid().ToString("N");
    private DateTimeOffset _runStartedUtc = DateTimeOffset.UtcNow;

    public SimulationSession() => Reset();

    public void Reset()
    {
        lock (_gate)
        {
            var dataRoot = ResolveDataRoot();
            _package = ScenarioPackageLoader.LoadCountryScaleV110(dataRoot);
            _placements = new ScenarioPlacementResolver(_package);
            _supportCatalog = SupportDataLoader.LoadV19Catalog(dataRoot);
            _orbat = ScenarioOrbatDataLoader.Load(dataRoot, _package.OrbatFile);
            _orbat.BuildIndexes();
            var smallArms = SmallArmsDataLoader.LoadHezbollahSmallArms(dataRoot);
            var weaponAssignments = _package.EntityAssignments
                .Where(item => !string.IsNullOrWhiteSpace(item.WeaponId))
                .ToDictionary(item => item.EntityKey, item => item.WeaponId!, StringComparer.Ordinal);
            _state = CountryScaleScenario.Create(_package, smallArms, weaponAssignments);
            _state.ScenarioName = _package.Name;
            _state.MissionBriefing =
                "Bint Jbeil-centered country-scale sandbox. Public geography anchors the scenario; all lower-level positions and urban geometry are synthetic. " +
                "Exact entity motion is meter-native; contacts propagate through delayed C2 reports, cohesion and casualty logistics are active, and the internal kilometer planning lattice remains hidden.";
            _state.OpenEndedScenario = true;
            ConfigureV110JointSupport();
            _state.EnsurePrecisePositions();

            _entityAssignments = _package.EntityAssignments.ToDictionary(
                item => item.EntityKey, item => item.OrbatNodeId, StringComparer.Ordinal);
            ValidateBindings();
            ValidateScenarioPlacementCoherence();
            _descendantNodeIds = _orbat.Nodes.ToDictionary(
                node => node.Id,
                node => _orbat.DescendantsAndSelf(node.Id).Select(child => child.Id).ToHashSet(StringComparer.Ordinal),
                StringComparer.Ordinal);

            _running = false;
            _speed = 1;
            _stepAccumulator = 0;
            _runId = Guid.NewGuid().ToString("N");
            _runStartedUtc = DateTimeOffset.UtcNow;
            _queuedOrders.Clear();
            _appliedSupportMissionEffects.Clear();
            _nextCommandMessageId = 1;
            Touch();
        }
    }

    private void ValidateBindings()
    {
        var entityKeys = _state.Units.Select(unit => unit.EntityKey).ToHashSet(StringComparer.Ordinal);
        var missingEntities = _package.EntityAssignments
            .Where(binding => !entityKeys.Contains(binding.EntityKey))
            .Select(binding => binding.EntityKey)
            .ToArray();
        if (missingEntities.Length > 0)
            throw new InvalidDataException($"Scenario package references missing entities: {string.Join(", ", missingEntities)}");

        var missingNodes = _package.EntityAssignments
            .Where(binding => _orbat.Find(binding.OrbatNodeId) is null)
            .Select(binding => binding.OrbatNodeId)
            .Distinct(StringComparer.Ordinal)
            .ToArray();
        if (missingNodes.Length > 0)
            throw new InvalidDataException($"Scenario package references missing ORBAT nodes: {string.Join(", ", missingNodes)}");
    }


    private void ValidateScenarioPlacementCoherence()
    {
        var unitsByKey = _state.Units.ToDictionary(unit => unit.EntityKey, StringComparer.Ordinal);
        foreach (var assignment in _package.EntityAssignments)
        {
            if (assignment.InitialPlacement is null || !unitsByKey.TryGetValue(assignment.EntityKey, out var unit)) continue;
            var expected = _placements.Resolve(assignment.InitialPlacement);
            var actual = _state.GroundPositionOf(unit);
            var errorMeters = Math.Sqrt(Math.Pow(actual.X - expected.X, 2) + Math.Pow(actual.Y - expected.Y, 2));
            if (errorMeters > 0.75)
                throw new InvalidDataException($"Scenario entity '{assignment.EntityKey}' is {errorMeters:0.0} m away from its authored placement.");

            if (!string.IsNullOrWhiteSpace(assignment.InitialPlacement.ZoneId))
            {
                var zone = _placements.Zone(assignment.InitialPlacement.ZoneId);
                if (!string.IsNullOrWhiteSpace(zone.Faction) &&
                    !string.Equals(zone.Faction, unit.Faction.ToString(), StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException($"Scenario entity '{assignment.EntityKey}' ({unit.Faction}) is assigned to {zone.Faction} zone '{zone.Id}'.");
            }
        }

        var supportById = _state.JointSupport.Assets.ToDictionary(asset => asset.Id, StringComparer.Ordinal);
        foreach (var authored in _package.SupportPlacements)
        {
            if (!supportById.TryGetValue(authored.AssetId, out var asset))
                throw new InvalidDataException($"Authored support asset '{authored.AssetId}' was not created at runtime.");
            var expected = _placements.ResolveSupport(authored.AssetId);
            var errorMeters = Math.Sqrt(Math.Pow(asset.Position.X - expected.X, 2) + Math.Pow(asset.Position.Y - expected.Y, 2));
            if (errorMeters > 0.75)
                throw new InvalidDataException($"Support asset '{authored.AssetId}' is {errorMeters:0.0} m away from its authored placement.");

            var zone = _placements.Zone(authored.ZoneId);
            if (!string.IsNullOrWhiteSpace(zone.Faction) &&
                !string.Equals(zone.Faction, asset.Faction.ToString(), StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"Support asset '{authored.AssetId}' ({asset.Faction}) is assigned to {zone.Faction} zone '{zone.Id}'.");
        }

        var anchor = _placements.AnchorPoint(CountryScaleScenario.PrimaryAnchorId);
        if (!_placements.InsideTheater(anchor))
            throw new InvalidDataException("The Bint Jbeil scenario anchor resolved outside the theater.");
    }

    public void Play()
    {
        lock (_gate)
        {
            _running = true;
            Touch();
        }
    }

    public void Pause()
    {
        lock (_gate)
        {
            _running = false;
            Touch();
        }
    }

    public void SetSpeed(int speed)
    {
        lock (_gate)
        {
            _speed = speed;
            Touch();
        }
    }

    public object GetClock()
    {
        lock (_gate)
            return new { running = _running, speed = _speed, tick = _state.Tick, phase = _state.Phase.ToString() };
    }

    public IReadOnlyList<SimulationJournalEntry> GetJournalSince(long sequenceExclusive, int maximum = 500)
    {
        lock (_gate)
            return _state.Journal.Since(sequenceExclusive, maximum);
    }

    public SimulationPerformanceSnapshot GetPerformance()
    {
        lock (_gate)
            return _state.Performance.Snapshot();
    }

    public void AdvanceWallClockQuarterSecond()
    {
        lock (_gate)
        {
            if (!_running || _state.Result != BattleResult.Ongoing) return;

            _stepAccumulator += 0.25 * _speed;
            var steps = Math.Min(20, (int)Math.Floor(_stepAccumulator));
            if (steps <= 0) return;
            _stepAccumulator -= steps;

            for (var i = 0; i < steps && _state.Result == BattleResult.Ongoing; i++)
                AdvanceOneTick();
            Touch();
        }
    }

    public object Step(int seconds)
    {
        lock (_gate)
        {
            if (seconds is not (1 or 10))
                throw new ArgumentOutOfRangeException(nameof(seconds), "Supported manual steps are 1 and 10 seconds.");

            _running = false;
            for (var i = 0; i < seconds && _state.Result == BattleResult.Ongoing; i++)
                AdvanceOneTick();
            Touch();
            return new { running = _running, speed = _speed, tick = _state.Tick, phase = _state.Phase.ToString() };
        }
    }

    private void AdvanceOneTick()
    {
        TacticalEngine.Step(_state);
        DeliverQueuedOrders();
        ProcessV110JointSupport();
    }

    private void ConfigureV110JointSupport()
    {
        var support = _state.JointSupport;
        support.Assets.Clear();
        support.CounterBatteryCues.Clear();
        support.Missions.Clear();
        support.Impacts.Clear();

        Position3D SupportP(string assetId)
        {
            var placement = _placements.SupportPlacement(assetId);
            return _placements.Position(_state, _placements.ResolveSupport(assetId), placement.AltitudeMeters);
        }

        Position3D SupportZoneP(string assetId)
        {
            var placement = _placements.SupportPlacement(assetId);
            return _placements.Position(_state, _placements.ZoneCenter(placement.ZoneId), placement.AltitudeMeters);
        }

        string SupportZoneId(string assetId) => _placements.SupportPlacement(assetId).ZoneId;
        string SupportZoneLabel(string assetId) => _placements.Zone(SupportZoneId(assetId)).DisplayName;

        support.Assets.AddRange(new[]
        {
            // Blue ground support. Named sectors are deliberately coarse synthetic offsets, not exact real emplacements.
            new JointSupportAssetState
            {
                Id = "cb-radar-01", DisplayName = "Counter-Battery Radar", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.CounterBatteryRadar, Role = AirMissionRole.StaticSupport,
                OperatingZoneId = SupportZoneId("cb-radar-01"), OrbatNodeId = "blue-cb-radar",
                ZoneLabel = SupportZoneLabel("cb-radar-01"), PayloadClass = "sensor-only", MapSymbol = "RAD",
                Position = SupportP("cb-radar-01"), HomePosition = SupportP("cb-radar-01"), OrbitCenter = SupportZoneP("cb-radar-01"),
                MaxSpeedMetersPerSecond = 0, AccelerationMetersPerSecondSquared = 0, DecelerationMetersPerSecondSquared = 0,
                StoresRemaining = 0, FuelPercent = 100, StatusText = "ACTIVE · watching for launch signatures"
            },
            new JointSupportAssetState
            {
                Id = "m109-dishon", DisplayName = "M109 Doher · Dishon sector (synthetic offset)", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.TubeArtillery, Role = AirMissionRole.StaticSupport,
                OperatingZoneId = SupportZoneId("m109-dishon"), OrbatNodeId = "blue-m109-support",
                ZoneLabel = SupportZoneLabel("m109-dishon"), PayloadClass = "abstract 155 mm fire-mission packages", MapSymbol = "M109",
                Position = SupportP("m109-dishon"), HomePosition = SupportP("m109-dishon"), OrbitCenter = SupportZoneP("m109-dishon"),
                MaxSpeedMetersPerSecond = 12, AccelerationMetersPerSecondSquared = 1.0, DecelerationMetersPerSecondSquared = 1.6,
                StoresRemaining = 8, FuelPercent = 96, StatusText = "READY · fire support"
            },
            new JointSupportAssetState
            {
                Id = "m109-odeiseh", DisplayName = "M109 Doher · Odeiseh sector (synthetic offset)", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.TubeArtillery, Role = AirMissionRole.StaticSupport,
                OperatingZoneId = SupportZoneId("m109-odeiseh"), OrbatNodeId = "blue-m109-support",
                ZoneLabel = SupportZoneLabel("m109-odeiseh"), PayloadClass = "abstract 155 mm fire-mission packages", MapSymbol = "M109",
                Position = SupportP("m109-odeiseh"), HomePosition = SupportP("m109-odeiseh"), OrbitCenter = SupportZoneP("m109-odeiseh"),
                MaxSpeedMetersPerSecond = 12, AccelerationMetersPerSecondSquared = 1.0, DecelerationMetersPerSecondSquared = 1.6,
                StoresRemaining = 8, FuelPercent = 95, StatusText = "READY · fire support"
            },

            // Hermes 450 flight: two frontline ISR aircraft, one armed response orbit and two ground-ready aircraft.
            new JointSupportAssetState
            {
                Id = "h450-01", DisplayName = "Hermes 450-01", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.TacticalUas, Role = AirMissionRole.FrontlineIsr,
                OperatingZoneId = SupportZoneId("h450-01"), OrbatNodeId = "blue-hermes-flight", ZoneLabel = SupportZoneLabel("h450-01"),
                PayloadClass = "light guided payload · abstract", MapSymbol = "UAV", Position = SupportP("h450-01"),
                HomePosition = SupportP("h450-01"), OrbitCenter = SupportZoneP("h450-01"), OrbitRadiusMeters = 3_000,
                OrbitPhaseRadians = 0.0, CurrentSpeedMetersPerSecond = 42, MaxSpeedMetersPerSecond = 55,
                AccelerationMetersPerSecondSquared = 3.0, DecelerationMetersPerSecondSquared = 4.0,
                StoresRemaining = 4, FuelPercent = 78, StatusText = "AIRBORNE · frontline ISR"
            },
            new JointSupportAssetState
            {
                Id = "h450-02", DisplayName = "Hermes 450-02", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.TacticalUas, Role = AirMissionRole.FrontlineIsr,
                OperatingZoneId = SupportZoneId("h450-02"), OrbatNodeId = "blue-hermes-flight", ZoneLabel = SupportZoneLabel("h450-02"),
                PayloadClass = "light guided payload · abstract", MapSymbol = "UAV", Position = SupportP("h450-02"),
                HomePosition = SupportP("h450-02"), OrbitCenter = SupportZoneP("h450-02"), OrbitRadiusMeters = 3_000,
                OrbitPhaseRadians = Math.PI, CurrentSpeedMetersPerSecond = 40, MaxSpeedMetersPerSecond = 55,
                AccelerationMetersPerSecondSquared = 3.0, DecelerationMetersPerSecondSquared = 4.0,
                StoresRemaining = 4, FuelPercent = 74, StatusText = "AIRBORNE · frontline ISR"
            },
            new JointSupportAssetState
            {
                Id = "h450-03", DisplayName = "Hermes 450-03", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.TacticalUas, Role = AirMissionRole.BorderResponse,
                OperatingZoneId = SupportZoneId("h450-03"), OrbatNodeId = "blue-hermes-flight", ZoneLabel = SupportZoneLabel("h450-03"),
                PayloadClass = "light guided payload · abstract", MapSymbol = "UAV", Position = SupportP("h450-03"),
                HomePosition = SupportP("h450-03"), OrbitCenter = SupportZoneP("h450-03"), OrbitRadiusMeters = 2_500,
                OrbitPhaseRadians = Math.PI / 2, CurrentSpeedMetersPerSecond = 44, MaxSpeedMetersPerSecond = 58,
                AccelerationMetersPerSecondSquared = 3.2, DecelerationMetersPerSecondSquared = 4.2,
                StoresRemaining = 4, FuelPercent = 86, StatusText = "AIRBORNE · armed response orbit"
            },
            new JointSupportAssetState
            {
                Id = "h450-04", DisplayName = "Hermes 450-04", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.TacticalUas, Role = AirMissionRole.GroundReady,
                OperatingZoneId = SupportZoneId("h450-04"), OrbatNodeId = "blue-hermes-flight", ZoneLabel = SupportZoneLabel("h450-04"),
                PayloadClass = "light guided payload · abstract", MapSymbol = "UAV", Position = SupportP("h450-04"),
                HomePosition = SupportP("h450-04"), OrbitCenter = SupportZoneP("h450-04"), CurrentSpeedMetersPerSecond = 0,
                MaxSpeedMetersPerSecond = 58, AccelerationMetersPerSecondSquared = 3.2, DecelerationMetersPerSecondSquared = 4.2,
                StoresRemaining = 4, FuelPercent = 100, StatusText = "GROUND READY · armed"
            },
            new JointSupportAssetState
            {
                Id = "h450-05", DisplayName = "Hermes 450-05", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.TacticalUas, Role = AirMissionRole.GroundReady,
                OperatingZoneId = SupportZoneId("h450-05"), OrbatNodeId = "blue-hermes-flight", ZoneLabel = SupportZoneLabel("h450-05"),
                PayloadClass = "light guided payload · abstract", MapSymbol = "UAV", Position = SupportP("h450-05"),
                HomePosition = SupportP("h450-05"), OrbitCenter = SupportZoneP("h450-05"), CurrentSpeedMetersPerSecond = 0,
                MaxSpeedMetersPerSecond = 58, AccelerationMetersPerSecondSquared = 3.2, DecelerationMetersPerSecondSquared = 4.2,
                StoresRemaining = 4, FuelPercent = 100, StatusText = "GROUND READY · armed"
            },

            // Fixed wing assets. Speeds and acceleration are normalized simulation values rather than a public flight manual model.
            new JointSupportAssetState
            {
                Id = "f16i-cap-01", DisplayName = "F-16I CAP-01", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.FixedWingStrike, Role = AirMissionRole.CombatAirPatrol,
                OperatingZoneId = SupportZoneId("f16i-cap-01"), OrbatNodeId = "blue-f16i-support", ZoneLabel = SupportZoneLabel("f16i-cap-01"),
                PayloadClass = "GBU-31-class heavy guided store · abstract", MapSymbol = "F16", Position = SupportP("f16i-cap-01"),
                HomePosition = SupportP("f16i-cap-01"), OrbitCenter = SupportZoneP("f16i-cap-01"), OrbitRadiusMeters = 9_000,
                CurrentSpeedMetersPerSecond = 220, MaxSpeedMetersPerSecond = 310, AccelerationMetersPerSecondSquared = 18,
                DecelerationMetersPerSecondSquared = 24, StoresRemaining = 2, FuelPercent = 82, StatusText = "AIRBORNE · combat air patrol"
            },
            new JointSupportAssetState
            {
                Id = "f16i-cap-02", DisplayName = "F-16I CAP-02", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.FixedWingStrike, Role = AirMissionRole.CombatAirPatrol,
                OperatingZoneId = SupportZoneId("f16i-cap-02"), OrbatNodeId = "blue-f16i-support", ZoneLabel = SupportZoneLabel("f16i-cap-02"),
                PayloadClass = "GBU-31-class heavy guided store · abstract", MapSymbol = "F16", Position = SupportP("f16i-cap-02"),
                HomePosition = SupportP("f16i-cap-02"), OrbitCenter = SupportZoneP("f16i-cap-02"), OrbitRadiusMeters = 9_000,
                OrbitPhaseRadians = Math.PI, CurrentSpeedMetersPerSecond = 225, MaxSpeedMetersPerSecond = 310,
                AccelerationMetersPerSecondSquared = 18, DecelerationMetersPerSecondSquared = 24,
                StoresRemaining = 2, FuelPercent = 79, StatusText = "AIRBORNE · combat air patrol"
            },
            new JointSupportAssetState
            {
                Id = "f16i-ready-03", DisplayName = "F-16I Ready-03", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.FixedWingStrike, Role = AirMissionRole.GroundReady,
                OperatingZoneId = SupportZoneId("f16i-ready-03"), OrbatNodeId = "blue-f16i-support", ZoneLabel = SupportZoneLabel("f16i-ready-03"),
                PayloadClass = "GBU-31-class heavy guided store · abstract", MapSymbol = "F16", Position = SupportP("f16i-ready-03"),
                HomePosition = SupportP("f16i-ready-03"), OrbitCenter = SupportZoneP("f16i-ready-03"), MaxSpeedMetersPerSecond = 310,
                AccelerationMetersPerSecondSquared = 18, DecelerationMetersPerSecondSquared = 24,
                StoresRemaining = 2, FuelPercent = 100, StatusText = "GROUND READY"
            },
            new JointSupportAssetState
            {
                Id = "f16i-ready-04", DisplayName = "F-16I Ready-04", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.FixedWingStrike, Role = AirMissionRole.GroundReady,
                OperatingZoneId = SupportZoneId("f16i-ready-04"), OrbatNodeId = "blue-f16i-support", ZoneLabel = SupportZoneLabel("f16i-ready-04"),
                PayloadClass = "GBU-31-class heavy guided store · abstract", MapSymbol = "F16", Position = SupportP("f16i-ready-04"),
                HomePosition = SupportP("f16i-ready-04"), OrbitCenter = SupportZoneP("f16i-ready-04"), MaxSpeedMetersPerSecond = 310,
                AccelerationMetersPerSecondSquared = 18, DecelerationMetersPerSecondSquared = 24,
                StoresRemaining = 2, FuelPercent = 100, StatusText = "GROUND READY"
            },
            new JointSupportAssetState
            {
                Id = "f16i-ready-05", DisplayName = "F-16I Ready-05", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.FixedWingStrike, Role = AirMissionRole.GroundReady,
                OperatingZoneId = SupportZoneId("f16i-ready-05"), OrbatNodeId = "blue-f16i-support", ZoneLabel = SupportZoneLabel("f16i-ready-05"),
                PayloadClass = "GBU-31-class heavy guided store · abstract", MapSymbol = "F16", Position = SupportP("f16i-ready-05"),
                HomePosition = SupportP("f16i-ready-05"), OrbitCenter = SupportZoneP("f16i-ready-05"), MaxSpeedMetersPerSecond = 310,
                AccelerationMetersPerSecondSquared = 18, DecelerationMetersPerSecondSquared = 24,
                StoresRemaining = 2, FuelPercent = 100, StatusText = "GROUND READY"
            },
            new JointSupportAssetState
            {
                Id = "f16i-ready-06", DisplayName = "F-16I Ready-06", Faction = TacticalFaction.Blue,
                Kind = SupportAssetKind.FixedWingStrike, Role = AirMissionRole.GroundReady,
                OperatingZoneId = SupportZoneId("f16i-ready-06"), OrbatNodeId = "blue-f16i-support", ZoneLabel = SupportZoneLabel("f16i-ready-06"),
                PayloadClass = "GBU-31-class heavy guided store · abstract", MapSymbol = "F16", Position = SupportP("f16i-ready-06"),
                HomePosition = SupportP("f16i-ready-06"), OrbitCenter = SupportZoneP("f16i-ready-06"), MaxSpeedMetersPerSecond = 310,
                AccelerationMetersPerSecondSquared = 18, DecelerationMetersPerSecondSquared = 24,
                StoresRemaining = 2, FuelPercent = 100, StatusText = "GROUND READY"
            },

            // Red indirect-fire assets. Positions are synthetic sector placements and not real launcher sites.
            new JointSupportAssetState
            {
                Id = "red-mortar-01", DisplayName = "Hezbollah mortar section · synthetic", Faction = TacticalFaction.Red,
                Kind = SupportAssetKind.TubeArtillery, Role = AirMissionRole.StaticSupport,
                OperatingZoneId = SupportZoneId("red-mortar-01"), OrbatNodeId = "red-mortar", ZoneLabel = SupportZoneLabel("red-mortar-01"),
                PayloadClass = "mortar effect class · abstract", MapSymbol = "MTR", Position = SupportP("red-mortar-01"),
                HomePosition = SupportP("red-mortar-01"), OrbitCenter = SupportZoneP("red-mortar-01"), MaxSpeedMetersPerSecond = 0,
                AccelerationMetersPerSecondSquared = 0, DecelerationMetersPerSecondSquared = 0,
                StoresRemaining = 12, FuelPercent = 100, StatusText = "READY · mortar support"
            },
            new JointSupportAssetState
            {
                Id = "red-107-01", DisplayName = "107 mm rocket launcher · synthetic", Faction = TacticalFaction.Red,
                Kind = SupportAssetKind.RocketArtillery, Role = AirMissionRole.StaticSupport,
                OperatingZoneId = SupportZoneId("red-107-01"), OrbatNodeId = "red-rocket", ZoneLabel = SupportZoneLabel("red-107-01"),
                PayloadClass = "107 mm rocket effect class · abstract", MapSymbol = "107", Position = SupportP("red-107-01"),
                HomePosition = SupportP("red-107-01"), OrbitCenter = SupportZoneP("red-107-01"), MaxSpeedMetersPerSecond = 0,
                AccelerationMetersPerSecondSquared = 0, DecelerationMetersPerSecondSquared = 0,
                StoresRemaining = 10, FuelPercent = 100, StatusText = "READY · rocket support"
            },
            new JointSupportAssetState
            {
                Id = "red-bm21-01", DisplayName = "BM-21 / 9M22-class launcher · synthetic", Faction = TacticalFaction.Red,
                Kind = SupportAssetKind.RocketArtillery, Role = AirMissionRole.StaticSupport,
                OperatingZoneId = SupportZoneId("red-bm21-01"), OrbatNodeId = "red-rocket", ZoneLabel = SupportZoneLabel("red-bm21-01"),
                PayloadClass = "122 mm 9M22-class rocket effect · abstract", MapSymbol = "BM21", Position = SupportP("red-bm21-01"),
                HomePosition = SupportP("red-bm21-01"), OrbitCenter = SupportZoneP("red-bm21-01"), MaxSpeedMetersPerSecond = 18,
                AccelerationMetersPerSecondSquared = 1.4, DecelerationMetersPerSecondSquared = 2.0,
                StoresRemaining = 8, FuelPercent = 90, StatusText = "READY · 122 mm rocket support"
            }
        });

        _state.AddActivity(TacticalEventType.Scenario,
            "COUNTRY-SCALE WORLD: visible tactical grid removed; entity and support motion is continuous in meters.");
        _state.AddActivity(TacticalEventType.Scenario,
            "FIRES MAP: two synthetic-offset M109 support positions, forward mortar/107 mm sectors, and a deeper-south BM-21/9M22-class sector are visible.");
        _state.AddActivity(TacticalEventType.Scenario,
            "AIR PLAN: two F-16I aircraft patrol at high speed; Hermes ISR and response orbits move independently with their own speed/acceleration fields.", TacticalFaction.Blue);
    }

    private void ProcessV110JointSupport()
    {
        var support = _state.JointSupport;
        support.Tick(_state);
        foreach (var completed in support.Missions.Where(m => m.State == SupportMissionState.Completed && _appliedSupportMissionEffects.Add(m.Id)).ToArray())
            ApplyJointSupportOutcome(completed);

        // Periodic synthetic Red indirect fire. These source coordinates are scenario-only support
        // sectors and are not real launch sites or firing solutions.
        if (_state.Tick == 12 || (_state.Tick > 12 && _state.Tick % 75 == 12))
            TriggerRedIndirectFire("red-mortar-01", SupportImpactKind.Mortar, counterBatteryCue: false, "automatic mortar event");
        if (_state.Tick == 24 || (_state.Tick > 24 && _state.Tick % 90 == 24))
            TriggerRedIndirectFire("red-107-01", SupportImpactKind.Rocket, counterBatteryCue: true, "automatic 107 mm event");
        if (_state.Tick == 55 || (_state.Tick > 55 && _state.Tick % 180 == 55))
            TriggerRedIndirectFire("red-bm21-01", SupportImpactKind.Rocket, counterBatteryCue: true, "automatic 122 mm event");

        // Blue tube artillery periodically demonstrates the same friendly-position uncertainty gate.
        if (_state.Tick == 40 || (_state.Tick > 40 && _state.Tick % 110 == 40))
        {
            var defense = _placements.ZoneCenter("bint-jbeil-defense-center");
            var targetLocal = new ScenarioLocalPoint(defense.X + 260, defense.Y + 310);
            var target = _placements.GroundPosition(_state, targetLocal);
            var artilleryMission = support.CreateTubeArtilleryMission(_state, target, BuildFriendlyTrackEstimates());
            _state.AddActivity(TacticalEventType.Order,
                $"M109 SUPPORT: {artilleryMission.State} — {artilleryMission.Reason}", TacticalFaction.Blue);
        }
    }

    private void ApplyJointSupportOutcome(JointSupportMission mission)
    {
        var rocketNode = _orbat.Find("red-rocket");
        if (rocketNode is not null && mission.RequestingFaction == TacticalFaction.Blue)
        {
            rocketNode.ReadinessPercent = Math.Max(20, rocketNode.ReadinessPercent - 8);
            rocketNode.AmmoPercent = Math.Max(15, rocketNode.AmmoPercent - 6);
            rocketNode.Status = rocketNode.ReadinessPercent < 55 ? OrbatReadiness.Degraded : OrbatReadiness.Engaged;
            rocketNode.CurrentOrder = "Recover / displace after synthetic support strike";
        }
        _state.AddActivity(TacticalEventType.Outcome,
            $"SUPPORT EFFECT: {mission.AssignedAssetId ?? "support asset"} completed {mission.Kind}; impact marker added to the map.", mission.RequestingFaction);
    }

    private JointSupportMission TriggerRedIndirectFire(
        string assetId,
        SupportImpactKind impactKind,
        bool counterBatteryCue,
        string trigger)
    {
        var support = _state.JointSupport;
        var source = support.Assets.First(asset => asset.Id == assetId);
        if (source.StoresRemaining > 0) source.StoresRemaining--;

        // Synthetic impact around the authored Blue approach area. The offset is deterministic and
        // exists only to exercise the scenario event chain.
        var dx = _state.Random.NextInclusive(-140, 140);
        var dy = _state.Random.NextInclusive(-140, 140);
        var blueApproach = _placements.ZoneCenter("blue-southwest-approach");
        var impact = _placements.GroundPosition(_state,
            new ScenarioLocalPoint(blueApproach.X + dx, blueApproach.Y + dy));
        support.RecordImpact(_state, impactKind, TacticalFaction.Red, impact,
            impactKind == SupportImpactKind.Mortar ? "RED MORTAR IMPACT" : "RED ROCKET IMPACT", source.Id);
        _state.AddActivity(TacticalEventType.Contact,
            $"RED FIRES: {source.DisplayName} fired ({trigger}); impact marker recorded in the synthetic active area.", TacticalFaction.Red);

        if (!counterBatteryCue)
        {
            return new JointSupportMission
            {
                Id = $"red-fire-{_state.Tick}-{source.Id}",
                Kind = impactKind == SupportImpactKind.Mortar ? SupportMissionKind.MortarFire : SupportMissionKind.RocketFire,
                RequestingFaction = TacticalFaction.Red,
                EstimatedTarget = impact,
                CreatedTick = _state.Tick,
                State = SupportMissionState.Completed,
                AssignedAssetId = source.Id,
                Reason = "Synthetic Red indirect-fire event completed"
            };
        }

        var cue = support.AddCounterBatteryCue(_state, "cb-radar-01", source.Position,
            $"Synthetic launch signature from {source.DisplayName}");
        _state.AddActivity(TacticalEventType.Contact,
            $"COUNTER-BATTERY RADAR: imprecise launch-area cue generated (uncertainty radius {cue.UncertaintyRadiusMeters:0} m).", TacticalFaction.Blue);
        var mission = support.CreateCounterBatteryMission(_state, cue);
        support.ProcessCounterBatteryMission(_state, mission, BuildFriendlyTrackEstimates());
        _state.AddActivity(TacticalEventType.Order,
            $"JOINT SUPPORT: {mission.State} — {mission.Reason}", TacticalFaction.Blue);
        return mission;
    }

    public object SimulateCounterBatteryTest()
    {
        lock (_gate)
        {
            var mission = TriggerRedIndirectFire("red-107-01", SupportImpactKind.Rocket, counterBatteryCue: true, "manual test");
            Touch();
            return new
            {
                missionId = mission.Id,
                state = mission.State.ToString(),
                mission.AssignedAssetId,
                mission.Reason,
                risk = mission.FriendlyRiskScore
            };
        }
    }

    private IReadOnlyList<FriendlyTrackEstimate> BuildFriendlyTrackEstimates()
    {
        var estimates = new List<FriendlyTrackEstimate>();
        foreach (var unit in _state.Units.Where(unit => unit.Faction == TacticalFaction.Blue && unit.Alive))
        {
            var nodeId = _entityAssignments.GetValueOrDefault(unit.EntityKey);
            var node = nodeId is null ? null : _orbat.Find(nodeId);
            var connected = node is null || !node.Communications.Contains("disconnect", StringComparison.OrdinalIgnoreCase);
            var degraded = node?.Communications.Contains("degrad", StringComparison.OrdinalIgnoreCase) == true ||
                           node?.Communications.Contains("variable", StringComparison.OrdinalIgnoreCase) == true;
            estimates.Add(new FriendlyTrackEstimate
            {
                EntityKey = unit.EntityKey,
                LastKnownPosition = _state.GroundPositionOf(unit),
                LastUpdateTick = connected ? _state.Tick : Math.Max(0, _state.Tick - 35),
                BaseUncertaintyMeters = degraded ? 30 : 12,
                UncertaintyGrowthMetersPerSecond = degraded ? 2.0 : 3.5,
                CommunicationsConnected = connected
            });
        }
        return estimates;
    }

    public OrderResult IssueOrder(OrderRequest request)
    {
        lock (_gate)
        {
            if (string.IsNullOrWhiteSpace(request.OrbatNodeId))
                return new(false, "No ORBAT node selected.", 0);
            var node = _orbat.Find(request.OrbatNodeId);
            if (node is null)
                return new(false, "ORBAT node was not found.", 0);
            if (!Enum.TryParse<TacticalOrderType>(request.Order, true, out var order))
                return new(false, "Unknown order type.", 0);
            Position3D objectiveMeters;
            GridPoint objective;
            if (request.XMeters is { } xMeters && request.YMeters is { } yMeters)
            {
                var maxX = _state.Width * _state.World.CellSizeMeters;
                var maxY = _state.Height * _state.World.CellSizeMeters;
                if (!double.IsFinite(xMeters) || !double.IsFinite(yMeters) ||
                    xMeters < 0 || xMeters >= maxX || yMeters < 0 || yMeters >= maxY)
                    return new(false, "Order destination is outside the country-scale simulation theater.", 0);
                objective = _state.World.GridPointFromWorld(xMeters, yMeters);
                objectiveMeters = new Position3D(xMeters, yMeters, _state.World.GroundAltitudeAt(xMeters, yMeters));
            }
            else
            {
                if (!_state.InBounds(request.X, request.Y))
                    return new(false, "Order destination is outside the country-scale simulation theater.", 0);
                objective = new GridPoint(request.X, request.Y);
                objectiveMeters = _state.World.CellCenter(objective, 0);
            }

            var allowed = order is TacticalOrderType.Hold or TacticalOrderType.Advance or
                TacticalOrderType.DefendObjective or TacticalOrderType.Support or TacticalOrderType.Withdraw;
            if (!allowed)
                return new(false, "This interface exposes high-level Hold, Advance, Defend, Support, and Withdraw orders.", 0);

            var descendants = _descendantNodeIds[node.Id];
            var targetUnits = _state.Units.Where(unit => unit.Alive &&
                _entityAssignments.TryGetValue(unit.EntityKey, out var assignedNode) &&
                descendants.Contains(assignedNode)).ToArray();
            if (targetUnits.Length == 0)
                return new(false, "This ORBAT node currently has no live simulation entities attached.", 0);

            var delayTicks = CommandDelayTicks(node, targetUnits.Length);
            var message = new QueuedFormationOrder
            {
                Id = $"cmd-{_nextCommandMessageId++:D4}",
                OrbatNodeId = node.Id,
                NodeName = node.DisplayName,
                Faction = node.Affiliation == OrbatAffiliation.Blue ? TacticalFaction.Blue : TacticalFaction.Red,
                Order = order,
                Objective = objective,
                ObjectiveMeters = objectiveMeters,
                IssuedTick = _state.Tick,
                DeliverAtTick = _state.Tick + delayTicks,
                AffectedEntityIds = targetUnits.Select(unit => unit.Id).ToArray()
            };
            foreach (var older in _queuedOrders.Where(item => item.Status == CommandMessageStatus.Queued &&
                         string.Equals(item.OrbatNodeId, node.Id, StringComparison.Ordinal)))
                older.Status = CommandMessageStatus.Superseded;
            _queuedOrders.Add(message);

            _state.AddActivity(TacticalEventType.Order,
                $"COMMAND SENT: {node.DisplayName} — {order} to {FormatTheaterPoint(objectiveMeters)}; estimated delivery T+{message.DeliverAtTick}.",
                message.Faction);
            Touch();
            return new(true,
                $"{order} queued for {targetUnits.Length} entities; delivery expected at T+{message.DeliverAtTick}.",
                targetUnits.Length, message.Id, message.DeliverAtTick);
        }
    }

    private static string FormatTheaterPoint(Position3D position) =>
        $"X {position.X / 1000.0:0.0} km / Y {position.Y / 1000.0:0.0} km";

    private int CommandDelayTicks(OrbatNodeRecord node, int entityCount)
    {
        var depth = _orbat.AncestorIds(node.Id).Count;
        var communicationsPenalty = node.Communications.Contains("disconnect", StringComparison.OrdinalIgnoreCase) ? 8 :
            node.Communications.Contains("degrad", StringComparison.OrdinalIgnoreCase) ? 4 :
            node.Communications.Contains("variable", StringComparison.OrdinalIgnoreCase) ? 3 :
            node.Communications.Contains("local", StringComparison.OrdinalIgnoreCase) ? 2 : 0;
        return Math.Clamp(1 + depth / 2 + entityCount / 6 + communicationsPenalty, 1, 12);
    }

    private void DeliverQueuedOrders()
    {
        foreach (var message in _queuedOrders.Where(item => item.Status == CommandMessageStatus.Queued &&
                     item.DeliverAtTick <= _state.Tick).ToArray())
        {
            var targetUnits = message.AffectedEntityIds
                .Select(_state.UnitById)
                .Where(unit => unit is { Alive: true })
                .Select(unit => unit!)
                .ToArray();
            if (targetUnits.Length == 0)
            {
                message.Status = CommandMessageStatus.Failed;
                _state.AddActivity(TacticalEventType.Order,
                    $"COMMAND FAILED: {message.NodeName} had no effective recipients.", message.Faction);
                continue;
            }

            var objectiveCenter = message.ObjectiveMeters;
            var destinations = FormationDestinationAllocator.Allocate(_state, targetUnits, objectiveCenter);
            var parentIntentId = $"intent-{message.Id}";
            var intentType = message.Order switch
            {
                TacticalOrderType.Hold => AiIntentType.HoldArea,
                TacticalOrderType.Withdraw => AiIntentType.Withdraw,
                TacticalOrderType.Support => AiIntentType.Support,
                _ => AiIntentType.MoveToArea
            };
            _state.Intents.Upsert(new AiIntent
            {
                Id = parentIntentId,
                IssuerStableKey = $"orbat:{message.OrbatNodeId}",
                RecipientStableKey = $"orbat:{message.OrbatNodeId}",
                CommandLevel = AiCommandLevel.Formation,
                Type = intentType,
                Area = new SimulationAreaIntent(objectiveCenter, 80),
                Priority = 50,
                IssuedTick = message.IssuedTick,
                ReceivedTick = _state.Tick,
                Status = "Accepted"
            });
            foreach (var unit in targetUnits)
            {
                var destination = destinations.GetValueOrDefault(unit.Id, objectiveCenter);
                _state.Intents.Upsert(new AiIntent
                {
                    Id = $"{parentIntentId}-{unit.EntityKey}",
                    IssuerStableKey = $"orbat:{message.OrbatNodeId}",
                    RecipientStableKey = $"entity:{unit.EntityKey}",
                    CommandLevel = AiCommandLevel.Entity,
                    Type = intentType,
                    Area = new SimulationAreaIntent(destination, 18),
                    Priority = 50,
                    IssuedTick = message.IssuedTick,
                    ReceivedTick = _state.Tick,
                    ParentIntentId = parentIntentId,
                    Status = "Accepted by subordinate AI"
                });
                TacticalAiEngine.AssignOrder(_state, unit, message.Order, message.Objective, destination);
            }

            message.Status = CommandMessageStatus.Delivered;
            message.DeliveredTick = _state.Tick;
            _state.AddActivity(TacticalEventType.Order,
                $"COMMAND RECEIVED: {message.NodeName} acknowledged {message.Order} near {FormatTheaterPoint(message.ObjectiveMeters)} ({targetUnits.Length} entities).",
                message.Faction);
        }

        if (_queuedOrders.Count > 100)
            _queuedOrders.RemoveAll(item => item.Status != CommandMessageStatus.Queued && item.DeliveredTick < _state.Tick - 120);
    }

    public SimulationDiagnosticReport GetDiagnosticReport()
    {
        lock (_gate)
        {
            _state.RebuildSpatialIndex();
            var snapshot = GetSnapshot();
            var findings = BuildIntegrityFindings();
            var queuedReports = _state.CommandAndControl.ContactReports.Count(item => item.Status == ContactReportStatus.Queued);
            var deliveredReports = _state.CommandAndControl.ContactReports.Count(item => item.Status == ContactReportStatus.Delivered);
            var droppedReports = _state.CommandAndControl.ContactReports.Count(item => item.Status == ContactReportStatus.Dropped);
            var incapacitated = _state.Units.Count(unit => unit.Soldier?.Vitals.Condition.HasFlag(SoldierCondition.Incapacitated) == true ||
                unit.Soldier?.Vitals.Condition.HasFlag(SoldierCondition.Unconscious) == true);
            var evacuated = _state.Units.Count(unit => unit.Soldier?.IsEvacuated == true);
            var dead = _state.Units.Count(unit => !unit.Alive || unit.Soldier?.Vitals.Condition.HasFlag(SoldierCondition.Dead) == true);
            var commandMessages = _queuedOrders
                .OrderBy(item => item.IssuedTick)
                .ThenBy(item => item.Id, StringComparer.Ordinal)
                .Select(item => new WebCommandMessage
                {
                    Id = item.Id,
                    NodeName = item.NodeName,
                    Faction = item.Faction.ToString(),
                    Order = item.Order.ToString(),
                    GridX = item.Objective.X,
                    GridY = item.Objective.Y,
                    TargetXMeters = item.ObjectiveMeters.X,
                    TargetYMeters = item.ObjectiveMeters.Y,
                    IssuedTick = item.IssuedTick,
                    DeliverAtTick = item.DeliverAtTick,
                    DeliveredTick = item.DeliveredTick,
                    Status = item.Status.ToString(),
                    AffectedEntities = item.AffectedEntityIds.Length
                })
                .ToArray();
            var localContacts = _state.CommandAndControl.LocalKnowledge
                .OrderBy(pair => pair.Key)
                .SelectMany(pair => pair.Value.Contacts.Select(contact =>
                {
                    var observer = _state.UnitById(contact.ObserverUnitId);
                    var target = _state.UnitById(contact.TargetUnitId);
                    return new DiagnosticLocalContact
                    {
                        ObserverUnitId = contact.ObserverUnitId,
                        ObserverEntityKey = observer?.EntityKey ?? "",
                        TargetUnitId = contact.TargetUnitId,
                        TargetEntityKey = target?.EntityKey ?? "",
                        Faction = contact.ObserverFaction.ToString(),
                        Classification = contact.Classification.ToString(),
                        ConfidenceState = _state.CommandAndControl.ConfidenceState(contact, _state.Tick).ToString(),
                        LastDetectedTick = contact.LastDetectedTick,
                        AgeTicks = Math.Max(0, _state.Tick - contact.LastDetectedTick),
                        LastKnownPosition = contact.LastKnownPosition,
                        DetectionConfidence = contact.DetectionConfidence,
                        IdentificationConfidence = contact.IdentificationConfidence
                    };
                }))
                .ToArray();

            return new SimulationDiagnosticReport
            {
                ReportFormat = "fieldsim-diagnostic-v1",
                ApplicationVersion = "1.10.0-urban-c2-diagnostics",
                RunId = _runId,
                RunStartedUtc = _runStartedUtc,
                ScenarioPackageId = _package.Id,
                RandomSeed = _package.RandomSeed,
                GeneratedUtc = DateTimeOffset.UtcNow,
                QuickSummary = new DiagnosticQuickSummary
                {
                    Tick = _state.Tick,
                    Phase = _state.Phase.ToString(),
                    Result = _state.Result.ToString(),
                    Running = _running,
                    Speed = _speed,
                    BlueEntities = _state.Units.Count(unit => unit.Faction == TacticalFaction.Blue),
                    RedEntities = _state.Units.Count(unit => unit.Faction == TacticalFaction.Red),
                    BlueCombatEffective = _state.Units.Count(unit => unit.Faction == TacticalFaction.Blue && unit.Alive &&
                        (unit.Soldier is null || unit.Soldier.IsCombatEffective)),
                    RedCombatEffective = _state.Units.Count(unit => unit.Faction == TacticalFaction.Red && unit.Alive &&
                        (unit.Soldier is null || unit.Soldier.IsCombatEffective)),
                    Incapacitated = incapacitated,
                    Evacuated = evacuated,
                    Dead = dead,
                    ContactReportsQueued = queuedReports,
                    ContactReportsDelivered = deliveredReports,
                    ContactReportsDropped = droppedReports,
                    SharedContacts = _state.Knowledge.Values.Sum(item => item.Contacts.Count),
                    SyntheticStructures = _state.Structures.Count,
                    OperationalSupportRequests = _state.OperationalSupport.Requests.Count,
                    JointSupportMissions = _state.JointSupport.Missions.Count,
                    CommandMessagesQueued = _queuedOrders.Count(item => item.Status == CommandMessageStatus.Queued),
                    IntentCount = _state.Intents.Intents.Count,
                    IntegrityWarningCount = findings.Count(item => !string.Equals(item.Severity, "info", StringComparison.OrdinalIgnoreCase))
                },
                Snapshot = snapshot,
                Journal = _state.Journal.Entries.ToArray(),
                ContactReports = _state.CommandAndControl.ContactReports.ToArray(),
                OperationalSupportRequests = _state.OperationalSupport.Requests.ToArray(),
                Intents = _state.Intents.Intents.OrderBy(item => item.IssuedTick).ToArray(),
                ActivityEvents = _state.ActivityEvents.ToArray(),
                CombatEvents = _state.CombatEvents.ToArray(),
                CommandMessages = commandMessages,
                LocalContacts = localContacts,
                IntegrityFindings = findings,
                DataBoundary = "Diagnostic export contains only this synthetic/local simulation state plus public-map context. It is intended for FieldSim debugging and AAR, not real-world operational use."
            };
        }
    }

    private DiagnosticFinding[] BuildIntegrityFindings()
    {
        var findings = new List<DiagnosticFinding>();
        var maxX = _state.Width * _state.World.CellSizeMeters;
        var maxY = _state.Height * _state.World.CellSizeMeters;
        bool Inside(Position3D p) => double.IsFinite(p.X) && double.IsFinite(p.Y) && p.X >= 0 && p.X < maxX && p.Y >= 0 && p.Y < maxY;

        foreach (var group in _state.Units.GroupBy(unit => unit.Id).Where(group => group.Count() > 1))
            findings.Add(new DiagnosticFinding { Severity = "error", Code = "duplicate-unit-id", Message = $"Unit id {group.Key} appears {group.Count()} times." });
        foreach (var group in _state.Units.GroupBy(unit => unit.EntityKey, StringComparer.Ordinal).Where(group => group.Count() > 1))
            findings.Add(new DiagnosticFinding { Severity = "error", Code = "duplicate-entity-key", Message = $"Entity key {group.Key} appears {group.Count()} times.", EntityKey = group.Key });

        foreach (var unit in _state.Units)
        {
            var position = _state.GroundPositionOf(unit);
            if (!Inside(position))
                findings.Add(new DiagnosticFinding { Severity = "error", Code = "unit-outside-theater", Message = $"{unit.DisplayName} is outside the theater at X={position.X:0.0}, Y={position.Y:0.0}.", EntityKey = unit.EntityKey });
            if (unit.CurrentSpeedMetersPerSecond > unit.Mobility.MaxSpeedMetersPerSecond + 0.25)
                findings.Add(new DiagnosticFinding { Severity = "warning", Code = "speed-over-max", Message = $"{unit.DisplayName} speed {unit.CurrentSpeedMetersPerSecond:0.00} m/s exceeds max {unit.Mobility.MaxSpeedMetersPerSecond:0.00} m/s.", EntityKey = unit.EntityKey });
            var accelLimit = Math.Max(unit.Mobility.AccelerationMetersPerSecondSquared, unit.Mobility.DecelerationMetersPerSecondSquared);
            if (Math.Abs(unit.CurrentAccelerationMetersPerSecondSquared) > accelLimit + 0.25)
                findings.Add(new DiagnosticFinding { Severity = "warning", Code = "acceleration-over-cap", Message = $"{unit.DisplayName} acceleration {unit.CurrentAccelerationMetersPerSecondSquared:0.00} m/s² exceeds mobility cap {accelLimit:0.00} m/s².", EntityKey = unit.EntityKey });
            if (unit.MovementDestinationMeters is { } destination && !Inside(destination))
                findings.Add(new DiagnosticFinding { Severity = "error", Code = "move-target-outside-theater", Message = $"{unit.DisplayName} has an out-of-theater movement destination.", EntityKey = unit.EntityKey });
            if (UrbanSpatialQueries.PointInsideStructure(_state, position))
                findings.Add(new DiagnosticFinding { Severity = "error", Code = "unit-inside-structure", Message = $"{unit.DisplayName} is inside a synthetic building footprint at X={position.X:0.0}, Y={position.Y:0.0}.", EntityKey = unit.EntityKey });
            if (!_entityAssignments.ContainsKey(unit.EntityKey))
                findings.Add(new DiagnosticFinding { Severity = "warning", Code = "missing-orbat-binding", Message = $"{unit.DisplayName} has no entity-to-ORBAT binding.", EntityKey = unit.EntityKey });
        }

        foreach (var structure in _state.Structures)
        {
            if (!Inside(structure.Bounds.Minimum) || !Inside(structure.Bounds.Maximum))
                findings.Add(new DiagnosticFinding { Severity = "warning", Code = "structure-outside-theater", Message = $"Synthetic structure {structure.Id} crosses the theater boundary." });
        }
        foreach (var asset in _state.JointSupport.Assets)
        {
            if (!Inside(asset.Position))
                findings.Add(new DiagnosticFinding { Severity = "warning", Code = "support-outside-theater", Message = $"Support asset {asset.Id} is outside the theater X/Y bounds." });
        }

        foreach (var request in _state.OperationalSupport.Requests)
        {
            var age = Math.Max(0, _state.Tick - request.CreatedTick);
            if ((request.Status is SupportRequestStatus.Transmitting or SupportRequestStatus.Acknowledged) && age > 90)
                findings.Add(new DiagnosticFinding { Severity = "warning", Code = "support-request-stalled", Message = $"Support request {request.Id} has remained {request.Status} for {age} ticks." });
            if ((request.Status is SupportRequestStatus.Assigned or SupportRequestStatus.Executing) &&
                request.CompleteAtTick is { } completeAt && _state.Tick > completeAt + 10)
                findings.Add(new DiagnosticFinding { Severity = "error", Code = "support-request-overdue", Message = $"Support request {request.Id} is {request.Status} past its expected completion tick {completeAt}." });
        }

        foreach (var message in _queuedOrders.Where(item => item.Status == CommandMessageStatus.Queued && item.DeliverAtTick + 10 < _state.Tick))
            findings.Add(new DiagnosticFinding { Severity = "error", Code = "command-message-overdue", Message = $"Command message {message.Id} is still queued after delivery tick {message.DeliverAtTick}." });

        foreach (var contact in _state.CommandAndControl.LocalKnowledge.Values.SelectMany(item => item.Contacts))
        {
            if (_state.UnitById(contact.ObserverUnitId) is null || _state.UnitById(contact.TargetUnitId) is null)
                findings.Add(new DiagnosticFinding { Severity = "warning", Code = "orphan-local-contact", Message = $"Local contact observer={contact.ObserverUnitId} target={contact.TargetUnitId} references a missing unit." });
        }

        if (_state.Objectives.Count == 0)
            findings.Add(new DiagnosticFinding { Severity = "warning", Code = "no-objectives", Message = "No runtime objectives are loaded." });
        if (_state.Structures.Count == 0)
            findings.Add(new DiagnosticFinding { Severity = "warning", Code = "no-urban-structures", Message = "No synthetic urban structures are loaded." });
        var dropped = _state.CommandAndControl.ContactReports.Count(item => item.Status == ContactReportStatus.Dropped);
        if (dropped > 0)
            findings.Add(new DiagnosticFinding { Severity = "info", Code = "c2-dropped-reports", Message = $"{dropped} contact reports were intentionally dropped by the abstract C2 model." });
        var stale = _state.Knowledge.Values.SelectMany(item => item.Contacts)
            .Count(contact => _state.CommandAndControl.ConfidenceState(contact, _state.Tick) == ContactConfidenceState.Stale);
        if (stale > 0)
            findings.Add(new DiagnosticFinding { Severity = "info", Code = "stale-shared-contacts", Message = $"{stale} shared contacts are stale." });
        if (findings.Count == 0)
            findings.Add(new DiagnosticFinding { Severity = "info", Code = "integrity-ok", Message = "No diagnostic integrity anomalies were detected by the v1.10 report checks." });
        return findings.ToArray();
    }

    public WebSnapshot GetSnapshot()
    {
        lock (_gate)
        {
            if (_cachedSnapshot is not null && _cachedRevision == _revision)
                return _cachedSnapshot;

            _state.RebuildSpatialIndex();
            var units = _state.Units.Select(unit =>
            {
                var position = _state.GroundPositionOf(unit);
                var weapon = unit.Soldier?.PrimaryWeapon;
                return new WebUnit
                {
                    Id = unit.Id,
                    EntityKey = unit.EntityKey,
                    Name = unit.DisplayName,
                    Faction = unit.Faction.ToString(),
                    UnitClass = unit.UnitClass.ToString(),
                    X = position.X,
                    Y = position.Y,
                    Z = position.Z,
                    SpeedMetersPerSecond = unit.CurrentSpeedMetersPerSecond,
                    CurrentAccelerationMetersPerSecondSquared = unit.CurrentAccelerationMetersPerSecondSquared,
                    MaxSpeedMetersPerSecond = unit.Mobility.MaxSpeedMetersPerSecond,
                    AccelerationMetersPerSecondSquared = unit.Mobility.AccelerationMetersPerSecondSquared,
                    DecelerationMetersPerSecondSquared = unit.Mobility.DecelerationMetersPerSecondSquared,
                    GridX = unit.Position.X,
                    GridY = unit.Position.Y,
                    Alive = unit.Alive,
                    OrbatNodeId = _entityAssignments.GetValueOrDefault(unit.EntityKey),
                    Role = unit.Soldier?.Role.ToString(),
                    WeaponId = weapon?.Definition.Id,
                    WeaponName = weapon?.Definition.DisplayName,
                    Caliber = weapon?.Definition.AmmunitionClass,
                    HitPoints = unit.Soldier?.Vitals.HitPoints,
                    SuppressionPercent = unit.Soldier is null ? null : (int)Math.Round(unit.Soldier.Vitals.Suppression01 * 100),
                    MoralePercent = unit.Soldier is null ? null : (int)Math.Round(unit.Soldier.Vitals.Morale01 * 100),
                    CohesionPercent = unit.Soldier is null ? null : (int)Math.Round(unit.LocalCohesion01 * 100),
                    CohesionBand = unit.CohesionBand.ToString(),
                    CasualtyDisposition = unit.Soldier?.CasualtyDisposition.ToString() ?? "None",
                    SupplyPercent = unit.Soldier is null ? null : (int)Math.Round(unit.Soldier.SupplyReadiness01 * 100),
                    NeedsResupply = unit.Soldier?.NeedsResupply ?? false,
                    IsEvacuated = unit.Soldier?.IsEvacuated ?? false,
                    Condition = unit.Soldier?.Vitals.Condition.ToString() ?? (unit.Alive ? "Operational" : "Disabled"),
                    Ammo = weapon?.TotalRounds,
                    Action = _state.CommandFor(unit)?.Action.ToString() ?? "Unassigned",
                    CurrentOrder = _state.CommandFor(unit)?.Order.ToString() ?? "Hold",
                    ObjectiveX = _state.CommandFor(unit)?.Objective.X,
                    ObjectiveY = _state.CommandFor(unit)?.Objective.Y,
                    Route = BuildRoute(unit),
                    Capabilities = unit.CapabilityIds.ToArray()
                };
            }).ToArray();

            var linkedUnitsByNode = BuildLinkedUnitsByNode(units);
            var directLinkedUnitCounts = units
                .Where(unit => unit.OrbatNodeId is not null)
                .GroupBy(unit => unit.OrbatNodeId!, StringComparer.Ordinal)
                .ToDictionary(group => group.Key, group => group.Count(), StringComparer.Ordinal);
            var spatialByNode = FormationSpatialCalculator.CalculateAll(
                _orbat, _entityAssignments, _state.Units, _state);
            var nodeDtos = _orbat.Nodes.Select(node =>
                BuildOrbatNode(node, linkedUnitsByNode, directLinkedUnitCounts, spatialByNode)).ToArray();

            var activity = _state.ActivityEvents.Select(item => new WebEvent
            {
                Tick = item.Tick,
                Kind = item.Type.ToString(),
                Faction = item.Faction?.ToString(),
                UnitId = item.UnitId,
                Message = item.Message
            });
            var combat = _state.CombatEvents.Select(item => new WebEvent
            {
                Tick = item.Tick,
                Kind = item.Type.ToString(),
                Faction = null,
                UnitId = item.SourceUnitId,
                TargetUnitId = item.TargetUnitId,
                Message = item.Message
            });

            _cachedSnapshot = new WebSnapshot
            {
                Revision = _revision,
                Scenario = new WebScenario
                {
                    Name = _state.ScenarioName,
                    Briefing = _state.MissionBriefing,
                    DataBoundary = _package.DataBoundary,
                    MapMode = _package.DisplayMap.Mode,
                    MapNotice = _package.DisplayMap.Notice,
                    DisplayCenterLatitude = _package.DisplayMap.CenterLatitude,
                    DisplayCenterLongitude = _package.DisplayMap.CenterLongitude,
                    LocalCenterXMeters = _state.Width * _state.World.CellSizeMeters * 0.5,
                    LocalCenterYMeters = _state.Height * _state.World.CellSizeMeters * 0.5,
                    TheaterWidthMeters = _state.Width * _state.World.CellSizeMeters,
                    TheaterHeightMeters = _state.Height * _state.World.CellSizeMeters,
                    InitialZoom = _package.DisplayMap.InitialZoom,
                    TerrainCellSizeMeters = _state.World.CellSizeMeters,
                    PrimaryAnchorName = _package.GeoAnchors.FirstOrDefault(item => item.Id == CountryScaleScenario.PrimaryAnchorId)?.DisplayName ?? "Scenario anchor",
                    PrimaryAnchorXMeters = _placements.AnchorPoint(CountryScaleScenario.PrimaryAnchorId).X,
                    PrimaryAnchorYMeters = _placements.AnchorPoint(CountryScaleScenario.PrimaryAnchorId).Y,
                    CoordinateModel = "country-scale-continuous-xyz-meters"
                },
                Running = _running,
                Speed = _speed,
                Tick = _state.Tick,
                Phase = _state.Phase.ToString(),
                Result = _state.Result.ToString(),
                Width = _state.Width,
                Height = _state.Height,
                Tiles = [],
                Units = units,
                Orbat = new WebOrbat
                {
                    BlueRootId = _orbat.BlueRootId,
                    RedRootId = _orbat.RedRootId,
                    Nodes = nodeDtos
                },
                Events = activity.Concat(combat)
                    .OrderByDescending(item => item.Tick)
                    .Take(180)
                    .OrderBy(item => item.Tick)
                    .ToArray(),
                Performance = _state.Performance.Snapshot(),
                // v1.7's support overlays were static labels that looked like live assets.
                // Keep them out of the operational map until they have real runtime entities.
                Overlays = [],
                Objectives = _state.Objectives.Select(objective =>
                {
                    var point = objective.PrecisePositionMeters ?? _state.World.CellCenter(objective.Position, 0);
                    return new WebObjective
                    {
                        Id = objective.Id,
                        Name = objective.DisplayName,
                        X = point.X,
                        Y = point.Y,
                        CaptureRadiusMeters = objective.CaptureRadiusMeters ??
                            objective.CaptureRadiusCells * _state.World.CellSizeMeters,
                        RequiredControlSeconds = objective.RequiredControlSeconds,
                        BlueControlSeconds = objective.BlueControlSeconds,
                        RedControlSeconds = objective.RedControlSeconds,
                        BlueProgress = objective.BlueProgress.ToString(),
                        RedProgress = objective.RedProgress.ToString()
                    };
                }).ToArray(),
                Structures = BuildWebStructures(),
                ContactReports = BuildWebContactReports(),
                SharedContacts = BuildWebFactionContacts(),
                OperationalSupportRequests = BuildWebOperationalSupportRequests(),
                Intents = BuildWebIntents(),
                CommandMessages = _queuedOrders
                    .OrderByDescending(item => item.IssuedTick)
                    .Take(30)
                    .Select(item => new WebCommandMessage
                    {
                        Id = item.Id,
                        NodeName = item.NodeName,
                        Faction = item.Faction.ToString(),
                        Order = item.Order.ToString(),
                        GridX = item.Objective.X,
                        GridY = item.Objective.Y,
                        TargetXMeters = item.ObjectiveMeters.X,
                        TargetYMeters = item.ObjectiveMeters.Y,
                        IssuedTick = item.IssuedTick,
                        DeliverAtTick = item.DeliverAtTick,
                        DeliveredTick = item.DeliveredTick,
                        Status = item.Status.ToString(),
                        AffectedEntities = item.AffectedEntityIds.Length
                    }).ToArray(),
                JointSupportAssets = _state.JointSupport.Assets.Select(asset => new WebJointSupportAsset
                {
                    Id = asset.Id, Name = asset.DisplayName, Faction = asset.Faction.ToString(), Kind = asset.Kind.ToString(), Role = asset.Role.ToString(),
                    OperatingZoneId = asset.OperatingZoneId, OrbatNodeId = asset.OrbatNodeId, ZoneLabel = asset.ZoneLabel,
                    PayloadClass = asset.PayloadClass, FuelPercent = asset.FuelPercent,
                    StoresRemaining = asset.StoresRemaining, Available = asset.Available, Status = asset.StatusText,
                    X = asset.Position.X, Y = asset.Position.Y, Z = asset.Position.Z, HeadingDegrees = asset.HeadingDegrees,
                    SpeedMetersPerSecond = asset.CurrentSpeedMetersPerSecond, CurrentAccelerationMetersPerSecondSquared = asset.CurrentAccelerationMetersPerSecondSquared,
                    MaxSpeedMetersPerSecond = asset.MaxSpeedMetersPerSecond, AccelerationMetersPerSecondSquared = asset.AccelerationMetersPerSecondSquared, MapSymbol = asset.MapSymbol
                }).ToArray(),
                SupportImpacts = _state.JointSupport.Impacts.OrderByDescending(i => i.CreatedTick).Take(120).Select(i => new WebSupportImpact
                {
                    Id = i.Id, Kind = i.Kind.ToString(), Faction = i.Faction.ToString(), X = i.Position.X, Y = i.Position.Y,
                    CreatedTick = i.CreatedTick, Label = i.Label, SourceAssetId = i.SourceAssetId
                }).ToArray(),
                CounterBatteryCues = _state.JointSupport.CounterBatteryCues.OrderByDescending(c => c.CreatedTick).Take(20).Select(c => new WebCounterBatteryCue
                { Id = c.Id, SensorId = c.SensorId, X = c.EstimatedOrigin.X, Y = c.EstimatedOrigin.Y, UncertaintyRadiusMeters = c.UncertaintyRadiusMeters, CreatedTick = c.CreatedTick }).ToArray(),
                JointSupportMissions = _state.JointSupport.Missions.OrderByDescending(m => m.CreatedTick).Take(30).Select(m => new WebJointSupportMission
                { Id = m.Id, Kind = m.Kind.ToString(), State = m.State.ToString(), AssignedAssetId = m.AssignedAssetId, Reason = m.Reason, FriendlyRiskScore = m.FriendlyRiskScore, CreatedTick = m.CreatedTick }).ToArray(),
                SupportCatalog = _supportCatalog.Assets.Select(item => new WebSupportAsset
                {
                    Id = item.Id,
                    Name = item.DisplayName,
                    Kind = item.Kind.ToString(),
                    PublicPlatformId = item.PublicPlatformId,
                    ScenarioQuantity = item.ScenarioQuantity,
                    OperatingZoneId = item.OperatingZoneId,
                    DataBoundary = item.DataBoundary
                }).ToArray()
            };
            _cachedRevision = _revision;
            return _cachedSnapshot;
        }
    }

    private WebPoint[] BuildRoute(TacticalUnit unit)
    {
        var points = new List<WebPoint>();
        var current = _state.GroundPositionOf(unit);
        points.Add(new WebPoint(current.X, current.Y));
        foreach (var waypoint in unit.ContinuousWaypoints)
            points.Add(new WebPoint(waypoint.X, waypoint.Y));
        foreach (var cell in unit.Path)
        {
            var center = _state.World.CellCenter(cell, 0);
            points.Add(new WebPoint(center.X, center.Y));
        }
        if (unit.MovementDestinationMeters is { } destination &&
            (Math.Abs(points[^1].X - destination.X) > 0.05 || Math.Abs(points[^1].Y - destination.Y) > 0.05))
            points.Add(new WebPoint(destination.X, destination.Y));
        return points.ToArray();
    }

    private WebStructure[] BuildWebStructures() => _state.Structures.Select(structure => new WebStructure
    {
        Id = structure.Id,
        Name = structure.Name,
        Type = structure.Type.ToString(),
        MinimumX = structure.Bounds.Minimum.X,
        MinimumY = structure.Bounds.Minimum.Y,
        MaximumX = structure.Bounds.Maximum.X,
        MaximumY = structure.Bounds.Maximum.Y,
        MinimumZ = structure.Bounds.Minimum.Z,
        MaximumZ = structure.Bounds.Maximum.Z,
        Levels = structure.Compartments.Select(item => item.LevelIndex).Distinct().Count(),
        CompartmentCount = structure.Compartments.Count,
        PortalCount = structure.Portals.Count,
        Synthetic = structure.SyntheticScenarioElement
    }).ToArray();

    private WebContactReport[] BuildWebContactReports() => _state.CommandAndControl.ContactReports
        .OrderByDescending(item => item.CreatedTick)
        .Take(250)
        .Select(item => new WebContactReport
        {
            Id = item.Id,
            ObserverUnitId = item.ObserverUnitId,
            TargetUnitId = item.TargetUnitId,
            Faction = item.Faction.ToString(),
            Classification = item.Classification.ToString(),
            DetectionConfidencePercent = (int)Math.Round(item.DetectionConfidence * 100),
            IdentificationConfidencePercent = (int)Math.Round(item.IdentificationConfidence * 100),
            ObservedTick = item.ObservedTick,
            CreatedTick = item.CreatedTick,
            DeliverAtTick = item.DeliverAtTick,
            DeliveredTick = item.DeliveredTick,
            Channel = item.Channel,
            Status = item.Status.ToString(),
            StatusReason = item.StatusReason,
            X = item.LastKnownPosition.X,
            Y = item.LastKnownPosition.Y
        }).ToArray();

    private WebFactionContact[] BuildWebFactionContacts() => _state.Knowledge
        .SelectMany(pair => pair.Value.Contacts.Select(contact => new WebFactionContact
        {
            Faction = pair.Key.ToString(),
            TargetUnitId = contact.TargetUnitId,
            TargetName = _state.UnitById(contact.TargetUnitId)?.DisplayName ?? $"Unit {contact.TargetUnitId}",
            Classification = contact.Classification.ToString(),
            Confidence = _state.CommandAndControl.ConfidenceState(contact, _state.Tick).ToString(),
            DetectionConfidencePercent = (int)Math.Round(contact.DetectionConfidence * 100),
            IdentificationConfidencePercent = (int)Math.Round(contact.IdentificationConfidence * 100),
            LastDetectedTick = contact.LastDetectedTick,
            AgeTicks = Math.Max(0, _state.Tick - contact.LastDetectedTick),
            X = contact.LastKnownPosition.X,
            Y = contact.LastKnownPosition.Y
        }))
        .OrderBy(item => item.Faction, StringComparer.Ordinal)
        .ThenBy(item => item.TargetUnitId)
        .ToArray();

    private WebOperationalSupportRequest[] BuildWebOperationalSupportRequests() => _state.OperationalSupport.Requests
        .OrderByDescending(item => item.CreatedTick)
        .Take(120)
        .Select(item => new WebOperationalSupportRequest
        {
            Id = item.Id,
            RequesterEntityKey = item.RequesterEntityKey,
            Faction = item.Faction.ToString(),
            Kind = item.Kind.ToString(),
            Priority = item.Priority,
            CreatedTick = item.CreatedTick,
            EarliestExecutionTick = item.EarliestExecutionTick,
            AssignedTick = item.AssignedTick,
            ExecuteAtTick = item.ExecuteAtTick,
            CompleteAtTick = item.CompleteAtTick,
            Status = item.Status.ToString(),
            AssignedAssetId = item.AssignedAssetId,
            StatusReason = item.StatusReason,
            X = item.ObjectivePositionMeters?.X,
            Y = item.ObjectivePositionMeters?.Y
        }).ToArray();

    private WebIntent[] BuildWebIntents() => _state.Intents.Intents
        .OrderByDescending(item => item.IssuedTick)
        .Take(250)
        .Select(item => new WebIntent
        {
            Id = item.Id,
            IssuerStableKey = item.IssuerStableKey,
            RecipientStableKey = item.RecipientStableKey,
            CommandLevel = item.CommandLevel.ToString(),
            Type = item.Type.ToString(),
            Priority = item.Priority,
            IssuedTick = item.IssuedTick,
            ReceivedTick = item.ReceivedTick,
            ParentIntentId = item.ParentIntentId,
            Status = item.Status,
            CenterX = item.Area?.CenterMeters.X,
            CenterY = item.Area?.CenterMeters.Y,
            RadiusMeters = item.Area?.RadiusMeters
        }).ToArray();

    private Dictionary<string, List<WebUnit>> BuildLinkedUnitsByNode(IReadOnlyList<WebUnit> units)
    {
        var result = new Dictionary<string, List<WebUnit>>(StringComparer.Ordinal);
        foreach (var unit in units)
        {
            if (unit.OrbatNodeId is not { } assignedNodeId || _orbat.Find(assignedNodeId) is null) continue;
            Add(assignedNodeId, unit);
            foreach (var ancestorId in _orbat.AncestorIds(assignedNodeId)) Add(ancestorId, unit);
        }
        return result;

        void Add(string nodeId, WebUnit member)
        {
            if (!result.TryGetValue(nodeId, out var linked))
            {
                linked = [];
                result[nodeId] = linked;
            }
            linked.Add(member);
        }
    }

    private WebOrbatNode BuildOrbatNode(
        OrbatNodeRecord node,
        IReadOnlyDictionary<string, List<WebUnit>> linkedUnitsByNode,
        IReadOnlyDictionary<string, int> directLinkedUnitCounts,
        IReadOnlyDictionary<string, FormationSpatialState> spatialByNode)
    {
        WebUnit[] linked = linkedUnitsByNode.TryGetValue(node.Id, out var members) ? members.ToArray() : [];
        var effective = linked.Count(unit => unit.Alive && !string.Equals(unit.Condition, "Dead", StringComparison.OrdinalIgnoreCase));
        var avgHp = linked.Where(unit => unit.HitPoints.HasValue).Select(unit => unit.HitPoints!.Value).DefaultIfEmpty(100).Average();
        var avgSuppression = linked.Where(unit => unit.SuppressionPercent.HasValue).Select(unit => unit.SuppressionPercent!.Value).DefaultIfEmpty(0).Average();
        var avgMorale = linked.Where(unit => unit.MoralePercent.HasValue).Select(unit => unit.MoralePercent!.Value).DefaultIfEmpty(node.MoralePercent).Average();
        var avgCohesion = linked.Where(unit => unit.CohesionPercent.HasValue).Select(unit => unit.CohesionPercent!.Value).DefaultIfEmpty(100).Average();
        var ammoValues = linked.Where(unit => unit.Ammo.HasValue).Select(unit => unit.Ammo!.Value).ToArray();
        var spatial = spatialByNode.GetValueOrDefault(node.Id);

        return new WebOrbatNode
        {
            Id = node.Id,
            ParentId = node.ParentId,
            Name = node.Name,
            ShortName = node.ShortName,
            Affiliation = node.Affiliation.ToString(),
            Echelon = node.Echelon.ToString(),
            Role = node.Role.ToString(),
            Status = node.Status.ToString(),
            CurrentPersonnel = linked.Length > 0 ? effective : node.CurrentPersonnel,
            ReadinessPercent = linked.Length == 0 ? node.ReadinessPercent : (int)Math.Clamp(Math.Round(avgHp), 0, 100),
            MoralePercent = linked.Length == 0 ? node.MoralePercent : (int)Math.Clamp(Math.Round(avgMorale), 0, 100),
            CohesionPercent = linked.Length == 0 ? 100 : (int)Math.Clamp(Math.Round(avgCohesion), 0, 100),
            AmmoPercent = linked.Length == 0 || ammoValues.Length == 0 ? node.AmmoPercent : EstimateAmmoPercent(linked),
            Communications = node.Communications,
            CurrentOrder = linked.Length == 0 ? node.CurrentOrder : MostCommon(linked.Select(unit => unit.CurrentOrder)),
            LinkedUnitCount = linked.Length,
            DirectLinkedUnitCount = directLinkedUnitCounts.GetValueOrDefault(node.Id),
            EffectiveUnitCount = effective,
            AverageHitPoints = linked.Length == 0 ? null : (int)Math.Round(avgHp),
            AverageSuppressionPercent = linked.Length == 0 ? null : (int)Math.Round(avgSuppression),
            CentroidXMeters = spatial?.MedianPositionMeters.X,
            CentroidYMeters = spatial?.MedianPositionMeters.Y,
            MeanXMeters = spatial?.MeanPositionMeters.X,
            MeanYMeters = spatial?.MeanPositionMeters.Y,
            DispersionRadiusMeters = spatial?.DispersionRadiusMeters,
            FrontageMeters = spatial?.FrontageMeters,
            DepthMeters = spatial?.DepthMeters,
            OutlierCount = spatial?.OutlierCount ?? 0
        };
    }

    private static int EstimateAmmoPercent(IReadOnlyList<WebUnit> linked)
    {
        var armed = linked.Where(unit => unit.Ammo.HasValue).ToArray();
        if (armed.Length == 0) return 100;
        // The current runtime does not yet persist authored combat loads by weapon instance;
        // this is deliberately a coarse normalized UI metric, not a real loadout estimate.
        var normalized = armed.Average(unit => Math.Clamp(unit.Ammo!.Value / 180.0, 0, 1));
        return (int)Math.Round(normalized * 100);
    }

    private static string MostCommon(IEnumerable<string> values) => values
        .GroupBy(value => value, StringComparer.Ordinal)
        .OrderByDescending(group => group.Count())
        .ThenBy(group => group.Key, StringComparer.Ordinal)
        .Select(group => group.Key)
        .FirstOrDefault() ?? "Hold";

    private static string[] FlattenTiles(TacticalState state)
    {
        var result = new string[state.Width * state.Height];
        for (var y = 0; y < state.Height; y++)
        for (var x = 0; x < state.Width; x++)
            result[y * state.Width + x] = state.Tiles[x, y].ToString();
        return result;
    }

    private void Touch()
    {
        _revision++;
        _cachedSnapshot = null;
    }

    private static string ResolveDataRoot()
    {
        var outputData = Path.Combine(AppContext.BaseDirectory, "data");
        if (Directory.Exists(outputData)) return outputData;

        var current = new DirectoryInfo(AppContext.BaseDirectory);
        while (current is not null)
        {
            var candidate = Path.Combine(current.FullName, "data");
            if (Directory.Exists(candidate)) return candidate;
            current = current.Parent;
        }

        throw new DirectoryNotFoundException("Could not locate FieldSim data directory.");
    }
}

public sealed class OrderRequest
{
    public string OrbatNodeId { get; set; } = "";
    public string Order { get; set; } = "Hold";
    // v1.9.2 primary order coordinate path: exact continuous theater meters.
    public double? XMeters { get; set; }
    public double? YMeters { get; set; }
    // Compatibility fallback for older clients.
    public int X { get; set; }
    public int Y { get; set; }
}

public sealed record OrderResult(
    bool Success,
    string Message,
    int AffectedEntities,
    string? CommandMessageId = null,
    long? DeliverAtTick = null);

public sealed class WebSnapshot
{
    public long Revision { get; init; }
    public required WebScenario Scenario { get; init; }
    public bool Running { get; init; }
    public int Speed { get; init; }
    public long Tick { get; init; }
    public required string Phase { get; init; }
    public required string Result { get; init; }
    public int Width { get; init; }
    public int Height { get; init; }
    public required string[] Tiles { get; init; }
    public required WebUnit[] Units { get; init; }
    public required WebOrbat Orbat { get; init; }
    public required WebEvent[] Events { get; init; }
    public required SimulationPerformanceSnapshot Performance { get; init; }
    public required WebOverlay[] Overlays { get; init; }
    public required WebObjective[] Objectives { get; init; }
    public required WebStructure[] Structures { get; init; }
    public required WebContactReport[] ContactReports { get; init; }
    public required WebFactionContact[] SharedContacts { get; init; }
    public required WebOperationalSupportRequest[] OperationalSupportRequests { get; init; }
    public required WebIntent[] Intents { get; init; }
    public required WebCommandMessage[] CommandMessages { get; init; }
    public required WebSupportAsset[] SupportCatalog { get; init; }
    public required WebJointSupportAsset[] JointSupportAssets { get; init; }
    public required WebSupportImpact[] SupportImpacts { get; init; }
    public required WebCounterBatteryCue[] CounterBatteryCues { get; init; }
    public required WebJointSupportMission[] JointSupportMissions { get; init; }
}

public sealed class WebScenario
{
    public required string Name { get; init; }
    public required string Briefing { get; init; }
    public required string DataBoundary { get; init; }
    public required string MapMode { get; init; }
    public required string MapNotice { get; init; }
    public double DisplayCenterLatitude { get; init; }
    public double DisplayCenterLongitude { get; init; }
    public double LocalCenterXMeters { get; init; }
    public double LocalCenterYMeters { get; init; }
    public double TheaterWidthMeters { get; init; }
    public double TheaterHeightMeters { get; init; }
    public double InitialZoom { get; init; }
    public double TerrainCellSizeMeters { get; init; }
    public required string PrimaryAnchorName { get; init; }
    public double PrimaryAnchorXMeters { get; init; }
    public double PrimaryAnchorYMeters { get; init; }
    public required string CoordinateModel { get; init; }
}

public sealed class WebOrbat
{
    public required string BlueRootId { get; init; }
    public required string RedRootId { get; init; }
    public required WebOrbatNode[] Nodes { get; init; }
}

public sealed class WebOrbatNode
{
    public required string Id { get; init; }
    public string? ParentId { get; init; }
    public required string Name { get; init; }
    public string? ShortName { get; init; }
    public required string Affiliation { get; init; }
    public required string Echelon { get; init; }
    public required string Role { get; init; }
    public required string Status { get; init; }
    public int? CurrentPersonnel { get; init; }
    public int ReadinessPercent { get; init; }
    public int MoralePercent { get; init; }
    public int CohesionPercent { get; init; }
    public int AmmoPercent { get; init; }
    public required string Communications { get; init; }
    public required string CurrentOrder { get; init; }
    public int LinkedUnitCount { get; init; }
    public int DirectLinkedUnitCount { get; init; }
    public int EffectiveUnitCount { get; init; }
    public int? AverageHitPoints { get; init; }
    public int? AverageSuppressionPercent { get; init; }
    public double? CentroidXMeters { get; init; }
    public double? CentroidYMeters { get; init; }
    public double? MeanXMeters { get; init; }
    public double? MeanYMeters { get; init; }
    public double? DispersionRadiusMeters { get; init; }
    public double? FrontageMeters { get; init; }
    public double? DepthMeters { get; init; }
    public int OutlierCount { get; init; }
}

public sealed class WebUnit
{
    public int Id { get; init; }
    public required string EntityKey { get; init; }
    public required string Name { get; init; }
    public required string Faction { get; init; }
    public required string UnitClass { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
    public double Z { get; init; }
    public double SpeedMetersPerSecond { get; init; }
    public double CurrentAccelerationMetersPerSecondSquared { get; init; }
    public double MaxSpeedMetersPerSecond { get; init; }
    public double AccelerationMetersPerSecondSquared { get; init; }
    public double DecelerationMetersPerSecondSquared { get; init; }
    public int GridX { get; init; }
    public int GridY { get; init; }
    public bool Alive { get; init; }
    public string? OrbatNodeId { get; init; }
    public string? Role { get; init; }
    public string? WeaponId { get; init; }
    public string? WeaponName { get; init; }
    public string? Caliber { get; init; }
    public double? HitPoints { get; init; }
    public int? SuppressionPercent { get; init; }
    public int? MoralePercent { get; init; }
    public int? CohesionPercent { get; init; }
    public required string CohesionBand { get; init; }
    public required string CasualtyDisposition { get; init; }
    public int? SupplyPercent { get; init; }
    public bool NeedsResupply { get; init; }
    public bool IsEvacuated { get; init; }
    public required string Condition { get; init; }
    public int? Ammo { get; init; }
    public required string Action { get; init; }
    public required string CurrentOrder { get; init; }
    public int? ObjectiveX { get; init; }
    public int? ObjectiveY { get; init; }
    public required WebPoint[] Route { get; init; }
    public required string[] Capabilities { get; init; }
}

public sealed record WebPoint(double X, double Y);

public sealed class WebObjective
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
    public double CaptureRadiusMeters { get; init; }
    public int RequiredControlSeconds { get; init; }
    public int BlueControlSeconds { get; init; }
    public int RedControlSeconds { get; init; }
    public required string BlueProgress { get; init; }
    public required string RedProgress { get; init; }
}

public sealed class WebStructure
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Type { get; init; }
    public double MinimumX { get; init; }
    public double MinimumY { get; init; }
    public double MaximumX { get; init; }
    public double MaximumY { get; init; }
    public double MinimumZ { get; init; }
    public double MaximumZ { get; init; }
    public int Levels { get; init; }
    public int CompartmentCount { get; init; }
    public int PortalCount { get; init; }
    public bool Synthetic { get; init; }
}

public sealed class WebContactReport
{
    public required string Id { get; init; }
    public int ObserverUnitId { get; init; }
    public int TargetUnitId { get; init; }
    public required string Faction { get; init; }
    public required string Classification { get; init; }
    public int DetectionConfidencePercent { get; init; }
    public int IdentificationConfidencePercent { get; init; }
    public long ObservedTick { get; init; }
    public long CreatedTick { get; init; }
    public long DeliverAtTick { get; init; }
    public long? DeliveredTick { get; init; }
    public required string Channel { get; init; }
    public required string Status { get; init; }
    public required string StatusReason { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
}

public sealed class WebFactionContact
{
    public required string Faction { get; init; }
    public int TargetUnitId { get; init; }
    public required string TargetName { get; init; }
    public required string Classification { get; init; }
    public required string Confidence { get; init; }
    public int DetectionConfidencePercent { get; init; }
    public int IdentificationConfidencePercent { get; init; }
    public long LastDetectedTick { get; init; }
    public long AgeTicks { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
}

public sealed class WebOperationalSupportRequest
{
    public required string Id { get; init; }
    public required string RequesterEntityKey { get; init; }
    public required string Faction { get; init; }
    public required string Kind { get; init; }
    public int Priority { get; init; }
    public long CreatedTick { get; init; }
    public long EarliestExecutionTick { get; init; }
    public long? AssignedTick { get; init; }
    public long? ExecuteAtTick { get; init; }
    public long? CompleteAtTick { get; init; }
    public required string Status { get; init; }
    public string? AssignedAssetId { get; init; }
    public required string StatusReason { get; init; }
    public double? X { get; init; }
    public double? Y { get; init; }
}

public sealed class WebIntent
{
    public required string Id { get; init; }
    public required string IssuerStableKey { get; init; }
    public required string RecipientStableKey { get; init; }
    public required string CommandLevel { get; init; }
    public required string Type { get; init; }
    public int Priority { get; init; }
    public long IssuedTick { get; init; }
    public long? ReceivedTick { get; init; }
    public string? ParentIntentId { get; init; }
    public required string Status { get; init; }
    public double? CenterX { get; init; }
    public double? CenterY { get; init; }
    public double? RadiusMeters { get; init; }
}

public sealed class WebCommandMessage
{
    public required string Id { get; init; }
    public required string NodeName { get; init; }
    public required string Faction { get; init; }
    public required string Order { get; init; }
    public int GridX { get; init; }
    public int GridY { get; init; }
    public double TargetXMeters { get; init; }
    public double TargetYMeters { get; init; }
    public long IssuedTick { get; init; }
    public long DeliverAtTick { get; init; }
    public long? DeliveredTick { get; init; }
    public required string Status { get; init; }
    public int AffectedEntities { get; init; }
}

public sealed class WebSupportAsset
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Kind { get; init; }
    public string? PublicPlatformId { get; init; }
    public int? ScenarioQuantity { get; init; }
    public string? OperatingZoneId { get; init; }
    public required string DataBoundary { get; init; }
}


public sealed class WebJointSupportAsset
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Faction { get; init; }
    public required string Kind { get; init; }
    public required string Role { get; init; }
    public required string OperatingZoneId { get; init; }
    public string? OrbatNodeId { get; init; }
    public required string ZoneLabel { get; init; }
    public required string PayloadClass { get; init; }
    public int FuelPercent { get; init; }
    public int StoresRemaining { get; init; }
    public bool Available { get; init; }
    public required string Status { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
    public double Z { get; init; }
    public double HeadingDegrees { get; init; }
    public double SpeedMetersPerSecond { get; init; }
    public double CurrentAccelerationMetersPerSecondSquared { get; init; }
    public double MaxSpeedMetersPerSecond { get; init; }
    public double AccelerationMetersPerSecondSquared { get; init; }
    public required string MapSymbol { get; init; }
}

public sealed class WebSupportImpact
{
    public required string Id { get; init; }
    public required string Kind { get; init; }
    public required string Faction { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
    public long CreatedTick { get; init; }
    public required string Label { get; init; }
    public string? SourceAssetId { get; init; }
}

public sealed class WebCounterBatteryCue
{
    public required string Id { get; init; }
    public required string SensorId { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
    public double UncertaintyRadiusMeters { get; init; }
    public long CreatedTick { get; init; }
}

public sealed class WebJointSupportMission
{
    public required string Id { get; init; }
    public required string Kind { get; init; }
    public required string State { get; init; }
    public string? AssignedAssetId { get; init; }
    public required string Reason { get; init; }
    public double FriendlyRiskScore { get; init; }
    public long CreatedTick { get; init; }
}

internal enum CommandMessageStatus
{
    Queued,
    Delivered,
    Superseded,
    Failed
}

internal sealed class QueuedFormationOrder
{
    public required string Id { get; init; }
    public required string OrbatNodeId { get; init; }
    public required string NodeName { get; init; }
    public required TacticalFaction Faction { get; init; }
    public required TacticalOrderType Order { get; init; }
    public required GridPoint Objective { get; init; }
    public required Position3D ObjectiveMeters { get; init; }
    public required long IssuedTick { get; init; }
    public required long DeliverAtTick { get; init; }
    public long? DeliveredTick { get; set; }
    public required int[] AffectedEntityIds { get; init; }
    public CommandMessageStatus Status { get; set; } = CommandMessageStatus.Queued;
}

public sealed class WebEvent
{
    public long Tick { get; init; }
    public required string Kind { get; init; }
    public string? Faction { get; init; }
    public int? UnitId { get; init; }
    public int? TargetUnitId { get; init; }
    public required string Message { get; init; }
}

public sealed class WebOverlay
{
    public required string Id { get; init; }
    public required string OrbatNodeId { get; init; }
    public required string Label { get; init; }
    public double X { get; init; }
    public double Y { get; init; }
}
