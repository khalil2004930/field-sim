using FieldSim.Core;

public sealed class SimulationDiagnosticReport
{
    public required string ReportFormat { get; init; }
    public required string ApplicationVersion { get; init; }
    public required string RunId { get; init; }
    public DateTimeOffset RunStartedUtc { get; init; }
    public required string ScenarioPackageId { get; init; }
    public uint RandomSeed { get; init; }
    public DateTimeOffset GeneratedUtc { get; init; }
    public required DiagnosticQuickSummary QuickSummary { get; init; }
    public required WebSnapshot Snapshot { get; init; }
    public required SimulationJournalEntry[] Journal { get; init; }
    public required ContactReport[] ContactReports { get; init; }
    public required SupportRequest[] OperationalSupportRequests { get; init; }
    public required AiIntent[] Intents { get; init; }
    public required TacticalEvent[] ActivityEvents { get; init; }
    public required CombatEvent[] CombatEvents { get; init; }
    public required WebCommandMessage[] CommandMessages { get; init; }
    public required DiagnosticLocalContact[] LocalContacts { get; init; }
    public required DiagnosticFinding[] IntegrityFindings { get; init; }
    public required string DataBoundary { get; init; }
}

public sealed class DiagnosticQuickSummary
{
    public long Tick { get; init; }
    public required string Phase { get; init; }
    public required string Result { get; init; }
    public bool Running { get; init; }
    public int Speed { get; init; }
    public int BlueEntities { get; init; }
    public int RedEntities { get; init; }
    public int BlueCombatEffective { get; init; }
    public int RedCombatEffective { get; init; }
    public int Incapacitated { get; init; }
    public int Evacuated { get; init; }
    public int Dead { get; init; }
    public int ContactReportsQueued { get; init; }
    public int ContactReportsDelivered { get; init; }
    public int ContactReportsDropped { get; init; }
    public int SharedContacts { get; init; }
    public int SyntheticStructures { get; init; }
    public int OperationalSupportRequests { get; init; }
    public int JointSupportMissions { get; init; }
    public int CommandMessagesQueued { get; init; }
    public int IntentCount { get; init; }
    public int IntegrityWarningCount { get; init; }
}

public sealed class DiagnosticFinding
{
    public required string Severity { get; init; }
    public required string Code { get; init; }
    public required string Message { get; init; }
    public string? EntityKey { get; init; }
}

public sealed class DiagnosticLocalContact
{
    public int ObserverUnitId { get; init; }
    public string ObserverEntityKey { get; init; } = "";
    public int TargetUnitId { get; init; }
    public string TargetEntityKey { get; init; } = "";
    public required string Faction { get; init; }
    public required string Classification { get; init; }
    public required string ConfidenceState { get; init; }
    public long LastDetectedTick { get; init; }
    public long AgeTicks { get; init; }
    public Position3D LastKnownPosition { get; init; }
    public double DetectionConfidence { get; init; }
    public double IdentificationConfidence { get; init; }
}
