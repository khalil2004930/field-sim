import * as maplibregl from "https://unpkg.com/maplibre-gl@6.6.0/dist/maplibre-gl.mjs";

const state = {
  snapshot: null,
  selectedNodeId: null,
  selectedUnitId: null,
  expanded: new Set(),
  search: "",
  eventFilter: "all",
  eventSource: null,
  map: null,
  mapLoaded: false,
  pickingOrderTarget: false,
  mapMarkers: new Map(),
  supportMapMarkers: new Map(),
  orderTargetMeters: null,
  trailMarkers: [],
  previousPositions: new Map(),
  trails: new Map(),
  lastDiagnosticReport: null,
  clientDiagnostics: {
    startedAt: new Date().toISOString(),
    errors: [],
    apiRequests: [],
    connectionEvents: []
  },
  layerVisibility: {
    basemap: true, routes: true, objectives: true, impacts: true, urban: true,
    blue: true, red: true, support: true, labels: true, trails: true, individuals: true
  }
};

const $ = (id) => document.getElementById(id);

function pushBounded(list, value, maximum = 200) {
  list.push(value);
  if (list.length > maximum) list.splice(0, list.length - maximum);
}

function recordClientError(source, error) {
  const message = error?.message || String(error || "Unknown browser error");
  pushBounded(state.clientDiagnostics.errors, {
    at: new Date().toISOString(), source, message,
    stack: typeof error?.stack === "string" ? error.stack.slice(0, 5000) : null
  }, 250);
}

function recordConnectionEvent(kind, detail = null) {
  pushBounded(state.clientDiagnostics.connectionEvents, { at: new Date().toISOString(), kind, detail }, 250);
}

window.addEventListener("error", event => recordClientError("window.error", event.error || new Error(event.message || "Window error")));
window.addEventListener("unhandledrejection", event => recordClientError("window.unhandledrejection", event.reason));

const roleCode = {
  Headquarters: "HQ", Infantry: "INF", Armored: "AR", Mechanized: "MECH",
  Reconnaissance: "REC", AntiArmor: "AT", SniperMarksman: "SN", Engineer: "ENG",
  Fires: "FIRE", Uav: "UAV", Fpv: "FPV", Intelligence: "INT", Signals: "SIG",
  Logistics: "LOG", Medical: "MED", Mixed: "MIX", Reserve: "RES"
};

const echelonCode = {
  Side: "SIDE", Command: "CMD", Division: "DIV", Brigade: "BDE", Battalion: "BN",
  Company: "CO", Platoon: "PLT", Squad: "SQD", Team: "TM", Cell: "CELL", SupportElement: "SUP"
};

const supportRoles = new Set(["Fires", "Uav", "Fpv", "Signals", "Logistics", "Medical", "Intelligence"]);

function initMap() {
  try {
    state.map = new maplibregl.Map({
      container: "map",
      style: {
        version: 8,
        sources: {
          osm: {
            type: "raster",
            tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
            tileSize: 256,
            attribution: "© OpenStreetMap contributors"
          }
        },
        layers: [{ id: "osm", type: "raster", source: "osm", paint: { "raster-saturation": -0.72, "raster-brightness-min": 0.30, "raster-brightness-max": 0.95, "raster-contrast": 0.10 } }]
      },
      center: [35.85, 33.85],
      zoom: 7.7,
      attributionControl: true,
      pitchWithRotate: false
    });
    state.map.addControl(new maplibregl.NavigationControl({ showCompass: true, visualizePitch: false }), "top-left");
    state.map.addControl(new maplibregl.ScaleControl({ maxWidth: 100, unit: "metric" }), "bottom-left");
    state.map.on("load", () => {
      state.mapLoaded = true;
      $("mapFallback").classList.add("hidden");
      state.map.addSource("entity-trails", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "entity-trails", type: "line", source: "entity-trails", minzoom: 14.5,
        paint: { "line-color": ["match", ["get", "faction"], "Blue", "#2499bd", "Red", "#bb4a4a", "#999"], "line-width": 1.5, "line-opacity": 0.35 }
      });
      // v1.9.3: explicit public-place scenario anchor so placement errors are visually obvious.
      state.map.addSource("scenario-anchor", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "scenario-anchor-dot", type: "circle", source: "scenario-anchor",
        paint: { "circle-radius": 6, "circle-color": "#f2d05c", "circle-stroke-color": "#171717", "circle-stroke-width": 2 }
      });
      state.map.addLayer({
        id: "scenario-anchor-label", type: "symbol", source: "scenario-anchor",
        layout: { "text-field": ["get", "label"], "text-size": 11, "text-offset": [0, 1.2], "text-anchor": "top", "text-allow-overlap": true },
        paint: { "text-color": "#f2d05c", "text-halo-color": "#171717", "text-halo-width": 1.5 }
      });
      state.map.addSource("urban-structures", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "urban-structures-fill", type: "fill", source: "urban-structures", minzoom: 11.5,
        paint: { "fill-color": "#8f8472", "fill-opacity": 0.22 }
      });
      state.map.addLayer({
        id: "urban-structures-line", type: "line", source: "urban-structures", minzoom: 11.5,
        paint: { "line-color": "#c0b6a4", "line-width": ["interpolate", ["linear"], ["zoom"], 11.5, 0.8, 17, 1.8], "line-opacity": 0.68 }
      });
      // No visible tactical grid. The remaining coarse planning lattice is internal only.
      state.map.addSource("support-impacts", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "support-impact-symbols", type: "symbol", source: "support-impacts",
        layout: { "text-field": ["get", "symbol"], "text-size": ["interpolate", ["linear"], ["zoom"], 7, 18, 13, 28], "text-allow-overlap": true },
        paint: { "text-color": ["match", ["get", "faction"], "Blue", "#51c7ff", "Red", "#ff6767", "#f5d46d"], "text-halo-color": "#111", "text-halo-width": 2 }
      });
      state.map.addLayer({
        id: "support-impact-labels", type: "symbol", source: "support-impacts", minzoom: 9.5,
        layout: { "text-field": ["get", "label"], "text-size": 10, "text-offset": [0, 1.5], "text-anchor": "top" },
        paint: { "text-color": "#f0ece7", "text-halo-color": "#181818", "text-halo-width": 1.5 }
      });
      state.map.addSource("counter-battery-zones", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "counter-battery-zones-fill", type: "fill", source: "counter-battery-zones",
        paint: { "fill-color": "#d7ad4b", "fill-opacity": 0.12 }
      });
      state.map.addLayer({
        id: "counter-battery-zones-line", type: "line", source: "counter-battery-zones",
        paint: { "line-color": "#e6c867", "line-width": 1.5, "line-dasharray": [3, 2], "line-opacity": 0.8 }
      });
      state.map.addSource("unit-routes", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "unit-routes", type: "line", source: "unit-routes",
        paint: {
          "line-color": ["match", ["get", "faction"], "Blue", "#25b7e8", "Red", "#f15d5d", "#f0d56a"],
          "line-width": 2.3, "line-opacity": 0.88, "line-dasharray": [2, 1.4]
        }
      });
      state.map.addSource("battle-objectives", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "battle-objectives", type: "circle", source: "battle-objectives",
        paint: {
          "circle-radius": ["interpolate", ["linear"], ["zoom"], 12, 9, 17, 18],
          "circle-color": ["match", ["get", "controller"], "Blue", "#3bbde8", "Red", "#ef6666", "#f2d05c"],
          "circle-opacity": 0.42,
          "circle-stroke-color": "#2b2511", "circle-stroke-width": 2
        }
      });
      state.map.addSource("entity-dots", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
      state.map.addLayer({
        id: "entity-dots", type: "circle", source: "entity-dots", minzoom: 14.8,
        paint: {
          "circle-radius": ["interpolate", ["linear"], ["zoom"], 16.2, 3, 19, 6],
          "circle-color": ["match", ["get", "faction"], "Blue", "#2499bd", "Red", "#bb4a4a", "#999"],
          "circle-stroke-color": "#151515", "circle-stroke-width": 1.2, "circle-opacity": 0.9
        }
      });
      state.map.on("click", "entity-dots", event => {
        const feature = event.features?.[0];
        const unitId = Number(feature?.properties?.unitId);
        if (Number.isFinite(unitId)) selectUnit(unitId, false);
      });
      state.map.on("mouseenter", "entity-dots", () => { state.map.getCanvas().style.cursor = "pointer"; });
      state.map.on("mouseleave", "entity-dots", () => { state.map.getCanvas().style.cursor = ""; });
      state.map.on("zoomend", () => { if (state.snapshot) renderMapState(false); });
      state.map.on("click", event => {
        if (!state.pickingOrderTarget || !state.snapshot) return;
        const local = unprojectLngLat(event.lngLat.lng, event.lngLat.lat);
        if (!insideTheater(local.x, local.y)) return showOrderError(new Error("That point is outside the country-scale simulation theater."));
        state.orderTargetMeters = { x: Math.round(local.x * 2) / 2, y: Math.round(local.y * 2) / 2 };
        $("orderCell").value = formatTheaterCoordinate(state.orderTargetMeters.x, state.orderTargetMeters.y);
        state.pickingOrderTarget = false;
        $("pickTargetButton").classList.remove("active");
        $("pickTargetButton").textContent = "Pick target on map";
        state.map.getCanvas().style.cursor = "";
        const message = $("orderMessage");
        message.classList.remove("error");
        message.textContent = `Target set to ${formatTheaterCoordinate(state.orderTargetMeters.x, state.orderTargetMeters.y)}.`;
      });
      if (state.snapshot) renderMapState(true);
    });
    state.map.on("error", event => {
      console.warn("MapLibre error", event?.error || event);
      recordClientError("maplibre", event?.error || event);
      if (!state.mapLoaded) $("mapFallback").classList.remove("hidden");
    });
  } catch (error) {
    console.error("Map initialization failed", error);
    recordClientError("map-initialization", error);
    $("mapFallback").classList.remove("hidden");
  }
}

function connect() {
  if (state.eventSource) state.eventSource.close();
  recordConnectionEvent("sse-connect-attempt");
  const source = new EventSource("/api/stream");
  state.eventSource = source;
  source.onopen = () => recordConnectionEvent("sse-open");
  source.addEventListener("snapshot", event => {
    try {
      state.snapshot = JSON.parse(event.data);
      $("connectionChip").textContent = "LIVE";
      $("connectionChip").classList.add("online");
      render();
    } catch (error) {
      console.error("Snapshot parse failed", error);
      recordClientError("snapshot-parse", error);
    }
  });
  source.onerror = () => {
    $("connectionChip").textContent = "RECONNECTING";
    $("connectionChip").classList.remove("online");
    recordConnectionEvent("sse-error-or-reconnect");
  };
}

async function post(url, body) {
  const started = performance.now();
  let response;
  try {
    response = await fetch(url, {
      method: "POST",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined
    });
    const data = await response.json().catch(() => ({}));
    pushBounded(state.clientDiagnostics.apiRequests, {
      at: new Date().toISOString(), method: "POST", url, status: response.status,
      durationMs: Math.round(performance.now() - started), ok: response.ok
    }, 250);
    if (!response.ok) throw new Error(data.message || data.error || `Request failed (${response.status})`);
    return data;
  } catch (error) {
    if (!response) pushBounded(state.clientDiagnostics.apiRequests, {
      at: new Date().toISOString(), method: "POST", url, status: 0,
      durationMs: Math.round(performance.now() - started), ok: false, error: error?.message || String(error)
    }, 250);
    recordClientError(`api-post:${url}`, error);
    throw error;
  }
}


function render() {
  const snap = state.snapshot;
  if (!snap) return;
  $("scenarioName").textContent = snap.scenario.name;
  $("clockLabel").textContent = `T+${String(snap.tick).padStart(3, "0")}s`;
  $("timelineNow").textContent = `T+${String(snap.tick).padStart(3, "0")}`;
  $("phaseLabel").textContent = snap.phase.toUpperCase();
  $("resultLabel").textContent = snap.result.toUpperCase();
  $("runStateLabel").textContent = snap.running ? `RUNNING ${snap.speed}×` : "PAUSED";
  $("mapNotice").textContent = snap.scenario.mapNotice;
  $("dataBoundary").textContent = snap.scenario.dataBoundary;
  document.querySelectorAll(".speed").forEach(button => button.classList.toggle("active", Number(button.dataset.speed) === snap.speed));
  captureTrails();
  renderOrbat();
  renderMapState(false);
  renderInspector();
  renderEvents();
  renderTimeline();
  renderStatus();
  renderCommandQueue();
  renderSupportCatalog();
}

function childrenMap(nodes) {
  const map = new Map();
  for (const node of nodes) {
    const key = node.parentId || "__root__";
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(node);
  }
  return map;
}

function renderOrbat() {
  const snap = state.snapshot;
  const tree = $("orbatTree");
  const nodes = snap.orbat.nodes;
  const byId = new Map(nodes.map(node => [node.id, node]));
  const children = childrenMap(nodes);

  if (state.expanded.size === 0) {
    state.expanded.add(snap.orbat.blueRootId);
    state.expanded.add(snap.orbat.redRootId);
    for (const rootId of [snap.orbat.blueRootId, snap.orbat.redRootId]) {
      for (const child of children.get(rootId) || []) state.expanded.add(child.id);
    }
  }

  const query = state.search.trim().toLowerCase();
  const matches = new Set();
  if (query) {
    for (const node of nodes) {
      const haystack = `${node.name} ${node.shortName || ""} ${node.role} ${node.echelon}`.toLowerCase();
      if (!haystack.includes(query)) continue;
      let current = node;
      while (current) {
        matches.add(current.id);
        current = current.parentId ? byId.get(current.parentId) : null;
      }
    }
  }

  tree.replaceChildren();
  for (const rootId of [snap.orbat.blueRootId, snap.orbat.redRootId]) {
    const root = byId.get(rootId);
    if (root) appendNode(root, 0);
  }

  function appendNode(node, depth) {
    if (query && !matches.has(node.id)) return;
    const nodeChildren = children.get(node.id) || [];
    const row = document.createElement("div");
    row.className = `orbat-row${state.selectedNodeId === node.id ? " selected" : ""}`;
    row.style.paddingLeft = `${5 + depth * 13}px`;
    row.dataset.nodeId = node.id;
    row.setAttribute("role", "treeitem");
    row.setAttribute("aria-level", String(depth + 1));
    if (nodeChildren.length) row.setAttribute("aria-expanded", String(state.expanded.has(node.id)));

    const chevron = document.createElement("button");
    chevron.type = "button";
    chevron.className = `chevron${nodeChildren.length ? "" : " empty"}`;
    chevron.textContent = state.expanded.has(node.id) ? "▾" : "▸";
    chevron.setAttribute("aria-label", `${state.expanded.has(node.id) ? "Collapse" : "Expand"} ${node.name}`);
    chevron.addEventListener("click", event => {
      event.stopPropagation();
      if (state.expanded.has(node.id)) state.expanded.delete(node.id); else state.expanded.add(node.id);
      renderOrbat();
    });

    const symbol = makeMiniSymbol(node);
    const name = document.createElement("div");
    name.className = "orbat-name";
    const primary = document.createElement("span");
    primary.className = "primary";
    primary.textContent = node.shortName ? `${node.shortName} · ${node.name}` : node.name;
    const secondary = document.createElement("span");
    secondary.className = "secondary";
    secondary.textContent = `${echelonCode[node.echelon] || node.echelon} · ${node.currentOrder}`;
    name.append(primary, secondary);

    const strength = document.createElement("div");
    strength.className = "orbat-strength";
    const displayedStrength = node.linkedUnitCount > 0 ? Math.round(node.effectiveUnitCount / Math.max(1, node.linkedUnitCount) * 100) : node.readinessPercent;
    strength.textContent = node.linkedUnitCount > 0 ? `${node.effectiveUnitCount}/${node.linkedUnitCount}` : `${node.readinessPercent}%`;
    if (displayedStrength < 65) strength.classList.add("critical"); else if (displayedStrength < 82) strength.classList.add("degraded");

    row.append(chevron, symbol, name, strength);
    row.addEventListener("click", () => selectNode(node.id, true));
    tree.append(row);

    if (state.expanded.has(node.id) || query) {
      for (const child of nodeChildren) appendNode(child, depth + 1);
    }
  }
}

function makeMiniSymbol(node) {
  const symbol = document.createElement("div");
  const linkClass = node.directLinkedUnitCount > 0 ? " live" : node.linkedUnitCount > 0 ? " aggregate" : "";
  symbol.className = `mini-symbol ${node.affiliation.toLowerCase()}${linkClass}`;
  const inner = document.createElement("span");
  inner.textContent = roleCode[node.role] || "U";
  symbol.append(inner);
  symbol.title = `${node.role} ${node.echelon}`;
  return symbol;
}

function selectNode(nodeId, focusMap) {
  state.selectedNodeId = nodeId;
  state.selectedUnitId = null;
  const snap = state.snapshot;
  const byId = new Map(snap.orbat.nodes.map(node => [node.id, node]));
  let current = byId.get(nodeId);
  while (current?.parentId) {
    state.expanded.add(current.parentId);
    current = byId.get(current.parentId);
  }
  render();
  if (focusMap) focusSelectionOnMap();
}

function selectUnit(unitId, focusMap) {
  state.selectedUnitId = unitId;
  const unit = state.snapshot.units.find(item => item.id === unitId);
  state.selectedNodeId = unit?.orbatNodeId || null;
  if (state.selectedNodeId) revealNodeAncestors(state.selectedNodeId);
  render();
  if (focusMap) focusSelectionOnMap();
}

function revealNodeAncestors(nodeId) {
  const byId = new Map(state.snapshot.orbat.nodes.map(node => [node.id, node]));
  let id = nodeId;
  while (id) {
    state.expanded.add(id);
    id = byId.get(id)?.parentId || null;
  }
}

function projectLocalToLngLat(xMeters, yMeters) {
  const snap = state.snapshot;
  const centerLat = snap.scenario.displayCenterLatitude ?? 33.12083;
  const centerLon = snap.scenario.displayCenterLongitude ?? 35.43361;
  const localCenterX = snap.scenario.localCenterXMeters ?? 0;
  const localCenterY = snap.scenario.localCenterYMeters ?? 0;
  const eastMeters = xMeters - localCenterX;
  const northMeters = yMeters - localCenterY;
  const lat = centerLat + northMeters / 111320;
  const lon = centerLon + eastMeters / (111320 * Math.cos(centerLat * Math.PI / 180));
  return [lon, lat];
}

function unprojectLngLat(lon, lat) {
  const snap = state.snapshot;
  const centerLat = snap.scenario.displayCenterLatitude ?? 33.12083;
  const centerLon = snap.scenario.displayCenterLongitude ?? 35.43361;
  const localCenterX = snap.scenario.localCenterXMeters ?? 0;
  const localCenterY = snap.scenario.localCenterYMeters ?? 0;
  return {
    x: localCenterX + (lon - centerLon) * 111320 * Math.cos(centerLat * Math.PI / 180),
    y: localCenterY + (lat - centerLat) * 111320
  };
}

function insideTheater(xMeters, yMeters) {
  const snap = state.snapshot;
  if (!snap) return false;
  return xMeters >= 0 && yMeters >= 0 && xMeters < snap.scenario.theaterWidthMeters && yMeters < snap.scenario.theaterHeightMeters;
}

function formatTheaterCoordinate(xMeters, yMeters) {
  return `X ${(xMeters / 1000).toFixed(2)} km · Y ${(yMeters / 1000).toFixed(2)} km`;
}

function exactNodePosition(nodeId) {
  const node = state.snapshot.orbat.nodes.find(item => item.id === nodeId);
  if (node?.centroidXMeters != null && node?.centroidYMeters != null)
    return projectLocalToLngLat(node.centroidXMeters, node.centroidYMeters);
  const units = state.snapshot.units.filter(unit => unit.orbatNodeId === nodeId);
  if (!units.length) return null;
  const x = units.reduce((sum, unit) => sum + unit.x, 0) / units.length;
  const y = units.reduce((sum, unit) => sum + unit.y, 0) / units.length;
  return projectLocalToLngLat(x, y);
}

function selectedDescendantIds() {
  if (!state.selectedNodeId) return new Set();
  const byParent = childrenMap(state.snapshot.orbat.nodes);
  const result = new Set();
  const stack = [state.selectedNodeId];
  while (stack.length) {
    const id = stack.pop();
    result.add(id);
    for (const child of byParent.get(id) || []) stack.push(child.id);
  }
  return result;
}

function echelonVisibleAtZoom(node, selected) {
  if (selected) return true;
  const z = state.map?.getZoom?.() ?? 13;
  const windows = {
    Division: [0, 11.0], Brigade: [9.5, 13.0], Battalion: [11.5, 14.6],
    Company: [13.0, 15.9], Platoon: [14.5, 17.2], Squad: [16.0, 24], Team: [16.3, 24],
    Cell: [15.5, 24], Command: [10.0, 15.5], SupportElement: [11.0, 24]
  };
  const [min, max] = windows[node.echelon] || [0, 24];
  return z >= min && z <= max;
}

function renderEntityDots() {
  const source = state.map?.getSource("entity-dots");
  if (!source || !state.snapshot) return;
  const features = state.snapshot.units
    .filter(unit => unit.alive && !unit.isEvacuated)
    .filter(unit => unit.faction === "Blue" ? state.layerVisibility.blue : unit.faction === "Red" ? state.layerVisibility.red : true)
    .map(unit => ({
      type: "Feature",
      id: unit.id,
      geometry: { type: "Point", coordinates: projectLocalToLngLat(unit.x, unit.y) },
      properties: { unitId: unit.id, faction: unit.faction, name: unit.name, role: unit.role || unit.unitClass }
    }));
  source.setData({ type: "FeatureCollection", features: state.layerVisibility.individuals ? features : [] });
}

function renderMapState(forceFit) {
  if (!state.map || !state.mapLoaded || !state.snapshot) return;
  const snap = state.snapshot;
  const nodesById = new Map(snap.orbat.nodes.map(node => [node.id, node]));
  const desired = new Map();

  for (const node of snap.orbat.nodes) {
    // Only nodes with directly attached runtime entities receive operational markers.
    // Ancestor/reference nodes remain selectable in the ORBAT without stacking fake map symbols.
    if ((node.directLinkedUnitCount || 0) === 0) continue;
    const pos = exactNodePosition(node.id);
    if (!pos) continue;
    desired.set(`node:${node.id}`, { type: "node", node, pos });
  }
  for (const overlay of snap.overlays || []) {
    const node = nodesById.get(overlay.orbatNodeId);
    if (!node) continue;
    desired.set(`overlay:${overlay.id}`, { type: "overlay", node, overlay, pos: projectLocalToLngLat(overlay.x, overlay.y) });
  }

  for (const [key, marker] of state.mapMarkers) {
    if (desired.has(key)) continue;
    marker.remove();
    state.mapMarkers.delete(key);
  }

  const selectedDesc = selectedDescendantIds();
  for (const [key, item] of desired) {
    const affiliation = item.node.affiliation.toLowerCase();
    const isSupport = item.type === "overlay" || supportRoles.has(item.node.role);
    const visibleBySide = affiliation === "blue" ? state.layerVisibility.blue : state.layerVisibility.red;
    const visible = visibleBySide && (!isSupport || state.layerVisibility.support);
    let marker = state.mapMarkers.get(key);
    if (!marker) {
      const element = createMapMarkerElement(item.node, item.type === "overlay" ? item.overlay.label : null, isSupport);
      element.addEventListener("click", event => {
        event.stopPropagation();
        selectNode(item.node.id, false);
      });
      marker = new maplibregl.Marker({ element, anchor: "center" }).setLngLat(item.pos).addTo(state.map);
      state.mapMarkers.set(key, marker);
    } else {
      marker.setLngLat(item.pos);
    }
    const el = marker.getElement();
    el.style.display = visible ? "flex" : "none";
    const selected = state.selectedNodeId === item.node.id || selectedDesc.has(item.node.id);
    const lodVisible = item.type === "overlay" || echelonVisibleAtZoom(item.node, selected);
    el.style.display = visible && lodVisible ? "flex" : "none";
    el.classList.toggle("selected", selected);
    el.classList.toggle("dimmed", Boolean(state.selectedNodeId) && !selected);
    const label = el.querySelector(".marker-label");
    if (label) label.style.display = state.layerVisibility.labels ? "block" : "none";
  }

  renderScenarioAnchor();
  renderUrbanStructures();
  renderTrails();
  renderRoutes();
  renderObjectives();
  renderEntityDots();
  renderSupportAssetsOnMap();
  renderSupportImpacts();
  renderCounterBatteryZones();
  state.map.setLayoutProperty("osm", "visibility", state.layerVisibility.basemap ? "visible" : "none");
  if (forceFit) fitScenario();
}


function renderScenarioAnchor() {
  if (!state.map || !state.snapshot) return;
  const source = state.map.getSource("scenario-anchor");
  if (!source) return;
  const scenario = state.snapshot.scenario;
  source.setData({
    type: "FeatureCollection",
    features: [{
      type: "Feature",
      properties: { label: "BINT JBEIL · SCENARIO ANCHOR" },
      geometry: { type: "Point", coordinates: projectLocalToLngLat(scenario.primaryAnchorXMeters, scenario.primaryAnchorYMeters) }
    }]
  });
}

function renderUrbanStructures() {
  const source = state.map?.getSource("urban-structures");
  if (!source || !state.snapshot) return;
  const features = (state.snapshot.structures || []).map(structure => ({
    type: "Feature",
    properties: {
      id: structure.id, name: structure.name, levels: structure.levels,
      compartments: structure.compartmentCount, portals: structure.portalCount
    },
    geometry: {
      type: "Polygon",
      coordinates: [[
        projectLocalToLngLat(structure.minimumX, structure.minimumY),
        projectLocalToLngLat(structure.maximumX, structure.minimumY),
        projectLocalToLngLat(structure.maximumX, structure.maximumY),
        projectLocalToLngLat(structure.minimumX, structure.maximumY),
        projectLocalToLngLat(structure.minimumX, structure.minimumY)
      ]]
    }
  }));
  source.setData({ type: "FeatureCollection", features: state.layerVisibility.urban ? features : [] });
}

function renderSupportAssetsOnMap() {
  if (!state.map || !state.snapshot) return;
  const desired = new Map();
  for (const asset of state.snapshot.jointSupportAssets || []) desired.set(asset.id, asset);

  for (const [id, marker] of state.supportMapMarkers) {
    if (desired.has(id)) continue;
    marker.remove();
    state.supportMapMarkers.delete(id);
  }

  for (const [id, asset] of desired) {
    let marker = state.supportMapMarkers.get(id);
    if (!marker) {
      const element = document.createElement("div");
      element.className = `support-map-marker ${asset.faction.toLowerCase()} ${asset.kind.toLowerCase()}`;
      const symbol = document.createElement("div");
      symbol.className = "support-map-symbol";
      symbol.textContent = asset.mapSymbol || "SUP";
      const label = document.createElement("div");
      label.className = "support-map-label";
      label.textContent = asset.name;
      element.append(symbol, label);
      element.addEventListener("click", event => {
        event.stopPropagation();
        if (asset.orbatNodeId) selectNode(asset.orbatNodeId, false);
      });
      marker = new maplibregl.Marker({ element, anchor: "center" }).setLngLat(projectLocalToLngLat(asset.x, asset.y)).addTo(state.map);
      state.supportMapMarkers.set(id, marker);
    } else {
      marker.setLngLat(projectLocalToLngLat(asset.x, asset.y));
    }
    const el = marker.getElement();
    const sideVisible = asset.faction === "Blue" ? state.layerVisibility.blue : asset.faction === "Red" ? state.layerVisibility.red : true;
    el.style.display = state.layerVisibility.support && sideVisible ? "flex" : "none";
    const label = el.querySelector(".support-map-label");
    if (label) label.style.display = state.layerVisibility.labels ? "block" : "none";
    const symbol = el.querySelector(".support-map-symbol");
    if (symbol) symbol.dataset.heading = Math.round(asset.headingDegrees || 0);
    el.title = `${asset.name} | ${asset.status} | ${asset.speedMetersPerSecond.toFixed(0)} m/s | max ${asset.maxSpeedMetersPerSecond.toFixed(0)} m/s | accel ${asset.currentAccelerationMetersPerSecondSquared.toFixed(1)} m/s² | accel cap ${asset.accelerationMetersPerSecondSquared.toFixed(1)} m/s²`;
  }
}

function renderSupportImpacts() {
  const source = state.map?.getSource("support-impacts");
  if (!source || !state.snapshot) return;
  const symbolFor = kind => kind === "Airstrike" ? "✸" : kind === "DroneStrike" ? "◆" : kind === "Rocket" ? "▲" : kind === "Mortar" ? "●" : "✹";
  const features = (state.snapshot.supportImpacts || []).map(impact => ({
    type: "Feature",
    geometry: { type: "Point", coordinates: projectLocalToLngLat(impact.x, impact.y) },
    properties: { id: impact.id, kind: impact.kind, faction: impact.faction, label: impact.label, symbol: symbolFor(impact.kind) }
  }));
  source.setData({ type: "FeatureCollection", features: state.layerVisibility.impacts ? features : [] });
}

function renderCounterBatteryZones() {
  const source = state.map?.getSource("counter-battery-zones");
  if (!source || !state.snapshot) return;
  const features = (state.snapshot.counterBatteryCues || []).slice(0, 8).map(cue => {
    const ring = [];
    for (let i = 0; i <= 40; i++) {
      const a = i / 40 * Math.PI * 2;
      ring.push(projectLocalToLngLat(cue.x + Math.cos(a) * cue.uncertaintyRadiusMeters, cue.y + Math.sin(a) * cue.uncertaintyRadiusMeters));
    }
    return { type: "Feature", properties: { id: cue.id }, geometry: { type: "Polygon", coordinates: [ring] } };
  });
  source.setData({ type: "FeatureCollection", features: state.layerVisibility.support ? features : [] });
}

function renderRoutes() {
  const source = state.map?.getSource("unit-routes");
  if (!source || !state.snapshot) return;
  const features = state.snapshot.units
    .filter(unit => unit.alive && (unit.route?.length || 0) > 1)
    .filter(unit => unit.faction === "Blue" ? state.layerVisibility.blue : unit.faction === "Red" ? state.layerVisibility.red : true)
    .map(unit => ({
      type: "Feature",
      properties: { unitId: unit.id, faction: unit.faction },
      geometry: { type: "LineString", coordinates: unit.route.map(point => projectLocalToLngLat(point.x, point.y)) }
    }));
  source.setData({ type: "FeatureCollection", features: state.layerVisibility.routes ? features : [] });
}

function renderObjectives() {
  const source = state.map?.getSource("battle-objectives");
  if (!source || !state.snapshot) return;
  const features = (state.snapshot.objectives || []).map(objective => ({
    type: "Feature",
    properties: {
      id: objective.id, name: objective.name,
      controller: objective.blueControlSeconds > objective.redControlSeconds ? "Blue" :
        objective.redControlSeconds > objective.blueControlSeconds ? "Red" : "Contested"
    },
    geometry: { type: "Point", coordinates: projectLocalToLngLat(objective.x, objective.y) }
  }));
  source.setData({ type: "FeatureCollection", features: state.layerVisibility.objectives ? features : [] });
}

function createMapMarkerElement(node, overrideLabel, isSupport) {
  const el = document.createElement("div");
  el.className = `map-unit-marker ${node.affiliation.toLowerCase()}${isSupport ? " support" : ""}`;
  const dots = document.createElement("div");
  dots.className = "echelon-dots";
  dots.textContent = echelonDots(node.echelon);
  const frame = document.createElement("div");
  frame.className = "marker-frame";
  const role = document.createElement("span");
  role.className = "role-text";
  role.textContent = roleCode[node.role] || "U";
  frame.append(role);
  const label = document.createElement("div");
  label.className = "marker-label";
  label.textContent = overrideLabel || node.shortName || node.name;
  el.append(dots, frame, label);
  return el;
}

function echelonDots(echelon) {
  const mapping = { Division: "XXXX", Brigade: "XXX", Battalion: "II", Company: "I", Platoon: "•••", Squad: "••", Team: "•", Cell: "•", Command: "◇", SupportElement: "•" };
  return mapping[echelon] || "";
}

function captureTrails() {
  const snap = state.snapshot;
  for (const unit of snap.units) {
    const current = `${unit.x},${unit.y}`;
    if (state.previousPositions.get(unit.id) === current) continue;
    state.previousPositions.set(unit.id, current);
    const trail = state.trails.get(unit.id) || [];
    trail.push({ x: unit.x, y: unit.y, faction: unit.faction });
    if (trail.length > 10) trail.shift();
    state.trails.set(unit.id, trail);
  }
}

function renderTrails() {
  const source = state.map?.getSource("entity-trails");
  if (!source) return;
  if (!state.layerVisibility.trails) {
    source.setData({ type: "FeatureCollection", features: [] });
    return;
  }
  const features = [];
  for (const [unitId, trail] of state.trails.entries()) {
    if (trail.length < 2) continue;
    const faction = trail[trail.length - 1].faction;
    if (faction === "Blue" && !state.layerVisibility.blue) continue;
    if (faction === "Red" && !state.layerVisibility.red) continue;
    features.push({
      type: "Feature",
      properties: { unitId, faction },
      geometry: { type: "LineString", coordinates: trail.map(point => projectLocalToLngLat(point.x, point.y)) }
    });
  }
  source.setData({ type: "FeatureCollection", features });
}

function fitScenario() {
  if (!state.map || !state.snapshot) return;
  const snap = state.snapshot;
  const coords = [];
  for (const unit of snap.units || []) coords.push(projectLocalToLngLat(unit.x, unit.y));
  for (const asset of snap.jointSupportAssets || []) coords.push(projectLocalToLngLat(asset.x, asset.y));
  for (const objective of snap.objectives || []) coords.push(projectLocalToLngLat(objective.x, objective.y));
  coords.push(projectLocalToLngLat(snap.scenario.primaryAnchorXMeters, snap.scenario.primaryAnchorYMeters));
  if (coords.length > 1) fitCoordinates(coords, 70);
  else {
    const w = snap.scenario.theaterWidthMeters;
    const h = snap.scenario.theaterHeightMeters;
    fitCoordinates([projectLocalToLngLat(0, 0), projectLocalToLngLat(w, h)], 35);
  }
}

function focusSelectionOnMap() {
  if (!state.map || !state.snapshot) return;
  const coords = [];
  if (state.selectedUnitId) {
    const unit = state.snapshot.units.find(item => item.id === state.selectedUnitId);
    if (unit) coords.push(projectLocalToLngLat(unit.x, unit.y));
  } else if (state.selectedNodeId) {
    for (const unit of state.snapshot.units) if (isUnitUnderNode(unit, state.selectedNodeId)) coords.push(projectLocalToLngLat(unit.x, unit.y));
    const descendants = selectedDescendantIds();
    for (const asset of state.snapshot.jointSupportAssets || []) if (asset.orbatNodeId && descendants.has(asset.orbatNodeId)) coords.push(projectLocalToLngLat(asset.x, asset.y));
  }
  fitCoordinates(coords, 110);
}

function fitCoordinates(coords, padding) {
  if (!coords.length) return;
  if (coords.length === 1) {
    state.map.easeTo({ center: coords[0], zoom: Math.max(state.map.getZoom(), 15), duration: 550 });
    return;
  }
  const bounds = new maplibregl.LngLatBounds(coords[0], coords[0]);
  for (const coord of coords.slice(1)) bounds.extend(coord);
  state.map.fitBounds(bounds, { padding, maxZoom: 15.2, duration: 650 });
}

function renderInspector() {
  const snap = state.snapshot;
  const title = $("inspectorTitle");
  const body = $("inspectorBody");
  const unit = state.selectedUnitId ? snap.units.find(item => item.id === state.selectedUnitId) : null;
  const node = state.selectedNodeId ? snap.orbat.nodes.find(item => item.id === state.selectedNodeId) : null;

  if (unit) {
    title.textContent = unit.name;
    body.className = "";
    body.innerHTML = metricHtml([
      ["Faction", displayFaction(unit.faction)], ["Role", unit.role || unit.unitClass], ["State", unit.action], ["Position", formatTheaterCoordinate(unit.x, unit.y)],
      ["XYZ", `${unit.x.toFixed(1)}, ${unit.y.toFixed(1)}, ${unit.z.toFixed(1)} m`], ["Speed", `${unit.speedMetersPerSecond.toFixed(2)} / ${unit.maxSpeedMetersPerSecond.toFixed(2)} m/s`],
      ["Acceleration", `${unit.currentAccelerationMetersPerSecondSquared.toFixed(2)} m/s² (cap ${unit.accelerationMetersPerSecondSquared.toFixed(2)})`],
      ["Weapon", unit.weaponName || "—"],
      ["Caliber", unit.caliber || "—"], ["Ammo", unit.ammo == null ? "—" : String(unit.ammo)],
      ["HP", unit.hitPoints == null ? "—" : `${Math.round(unit.hitPoints)}%`], ["Suppression", unit.suppressionPercent == null ? "—" : `${unit.suppressionPercent}%`],
      ["Morale", unit.moralePercent == null ? "—" : `${unit.moralePercent}%`], ["Cohesion", unit.cohesionPercent == null ? "—" : `${unit.cohesionPercent}% · ${unit.cohesionBand}`],
      ["Casualty", unit.casualtyDisposition || "None"], ["Supply", unit.supplyPercent == null ? "—" : `${unit.supplyPercent}%${unit.needsResupply ? " · RESUPPLY" : ""}`],
      ["Evacuated", unit.isEvacuated ? "YES" : "NO"], ["Order", unit.currentOrder], ["Entity", unit.entityKey], ["Capabilities", unit.capabilities?.length ? unit.capabilities.join(", ") : "—"]
    ]);
    return;
  }

  if (node) {
    title.textContent = node.shortName ? `${node.shortName} · ${node.name}` : node.name;
    const linked = snap.units.filter(unitItem => isUnitUnderNode(unitItem, node.id));
    const supportAssets = (snap.jointSupportAssets || []).filter(asset => isSupportAssetUnderNode(asset, node.id));
    body.className = "";
    const linksHtml = linked.length
      ? `<div class="section-label">LINKED SIMULATION ENTITIES</div><div class="linked-list">${linked.map(unitItem => `<div class="linked-unit" data-unit-id="${unitItem.id}"><strong>${escapeHtml(unitItem.name)}</strong><span>${formatTheaterCoordinate(unitItem.x, unitItem.y)} · ${escapeHtml(unitItem.action)} · ${unitItem.hitPoints == null ? "operational" : `${Math.round(unitItem.hitPoints)} HP`}</span></div>`).join("")}</div>`
      : "";
    const supportHtml = supportAssets.length
      ? `<div class="section-label">LIVE SUPPORT ASSETS</div><div class="linked-list">${supportAssets.map(asset => `<div class="linked-unit"><strong>${escapeHtml(asset.name)}</strong><span>${escapeHtml(asset.status)} · ${escapeHtml(asset.zoneLabel || asset.operatingZoneId)} · fuel ${asset.fuelPercent}% · stores ${asset.storesRemaining}</span></div>`).join("")}</div>`
      : "";
    const emptyHtml = !linked.length && !supportAssets.length
      ? `<div class="section-label">SIMULATION LINK</div><div class="inspector-empty">This ORBAT element is currently structural/display support.</div>`
      : "";
    body.innerHTML = metricHtml([
      ["Echelon", node.echelon], ["Role", node.role], ["Readiness", `${node.readinessPercent}%`], ["Morale", `${node.moralePercent}%`],
      ["Cohesion", `${node.cohesionPercent ?? 100}%`], ["Ammo", `${node.ammoPercent}%`], ["Comms", node.communications], ["Effective", node.linkedUnitCount ? `${node.effectiveUnitCount}/${node.linkedUnitCount}` : supportAssets.length ? `${supportAssets.length} support assets` : "structure"], ["Order", node.currentOrder],
      ["Direct entities", String(node.directLinkedUnitCount || 0)], ["Inherited entities", String(Math.max(0, node.linkedUnitCount - (node.directLinkedUnitCount || 0)))],
      ["Dispersion", node.dispersionRadiusMeters == null ? "—" : `${Math.round(node.dispersionRadiusMeters)} m`], ["Frontage", node.frontageMeters == null ? "—" : `${Math.round(node.frontageMeters)} m`]
    ]) + linksHtml + supportHtml + emptyHtml;
    body.querySelectorAll(".linked-unit[data-unit-id]").forEach(element => element.addEventListener("click", () => selectUnit(Number(element.dataset.unitId), true)));
    return;
  }

  title.textContent = "No selection";
  body.className = "inspector-empty";
  body.textContent = "Select an ORBAT item or map symbol.";
}

function metricHtml(items) {
  return `<div class="metric-grid">${items.map(([label, value]) => `<div class="metric"><div class="label">${escapeHtml(label)}</div><div class="value${String(value).length > 14 ? " small" : ""}">${escapeHtml(value)}</div></div>`).join("")}</div>`;
}

function isUnitUnderNode(unit, nodeId) {
  if (!unit.orbatNodeId) return false;
  const byId = new Map(state.snapshot.orbat.nodes.map(node => [node.id, node]));
  let id = unit.orbatNodeId;
  while (id) {
    if (id === nodeId) return true;
    id = byId.get(id)?.parentId || null;
  }
  return false;
}

function isSupportAssetUnderNode(asset, nodeId) {
  if (!asset.orbatNodeId) return false;
  const byId = new Map(state.snapshot.orbat.nodes.map(node => [node.id, node]));
  let id = asset.orbatNodeId;
  while (id) {
    if (id === nodeId) return true;
    id = byId.get(id)?.parentId || null;
  }
  return false;
}

function renderEvents() {
  const container = $("eventStream");
  const events = state.snapshot.events.filter(event => eventMatchesFilter(event, state.eventFilter));
  container.innerHTML = events.slice(-80).reverse().map(event => {
    const kind = event.kind.toLowerCase();
    return `<div class="event-row" data-unit-id="${event.unitId ?? ""}"><div class="event-time">T+${String(event.tick).padStart(3, "0")}</div><div class="event-kind ${escapeHtml(kind)}">${escapeHtml(event.kind)}</div><div class="event-message">${escapeHtml(event.message)}</div></div>`;
  }).join("") || `<div class="inspector-empty">No events match this filter yet.</div>`;
  container.querySelectorAll(".event-row[data-unit-id]").forEach(row => {
    const unitId = Number(row.dataset.unitId);
    if (!Number.isFinite(unitId) || unitId <= 0) return;
    row.style.cursor = "pointer";
    row.addEventListener("click", () => selectUnit(unitId, true));
  });
}

function eventMatchesFilter(event, filter) {
  if (filter === "all") return true;
  const kind = event.kind.toLowerCase();
  if (filter === "fire") return ["fire", "hit", "casualty", "disabled", "suppressed"].some(value => kind.includes(value));
  return kind.includes(filter);
}

function renderTimeline() {
  const tick = Math.max(0, state.snapshot.tick);
  const horizon = Math.max(600, Math.ceil((tick + 30) / 150) * 150);
  const percent = Math.min(100, tick / horizon * 100);
  $("timelinePlayhead").style.left = `${percent}%`;
  const labels = document.querySelector(".timeline-labels");
  labels.innerHTML = [0, .25, .5, .75, 1].map(fraction => `<span>T+${Math.round(horizon * fraction)}</span>`).join("");
  const events = $("timelineEvents");
  events.innerHTML = state.snapshot.events.slice(-80).map(event => {
    const left = Math.min(100, Math.max(0, event.tick / horizon * 100));
    return `<span class="timeline-event ${escapeHtml(event.kind.toLowerCase())}" style="left:${left}%" title="T+${event.tick} ${escapeHtml(event.message)}"></span>`;
  }).join("");
}

function renderStatus() {
  const snap = state.snapshot;
  const blue = snap.units.filter(unit => unit.faction === "Blue");
  const red = snap.units.filter(unit => unit.faction === "Red");
  const effective = unit => unit.alive && !unit.isEvacuated && !String(unit.condition || "").toLowerCase().includes("dead") && !String(unit.condition || "").toLowerCase().includes("incapacitated");
  const objectives = snap.objectives || [];
  const blueControlled = objectives.filter(item => item.blueProgress === "Secured" || item.blueProgress === "Held").length;
  const redControlled = objectives.filter(item => item.redProgress === "Secured" || item.redProgress === "Held").length;
  const reports = snap.contactReports || [];
  const queuedReports = reports.filter(item => item.status === "Queued").length;
  const droppedReports = reports.filter(item => item.status === "Dropped").length;
  const deliveredReports = reports.filter(item => item.status === "Delivered").length;
  const sharedBlue = (snap.sharedContacts || []).filter(item => item.faction === "Blue").length;
  const sharedRed = (snap.sharedContacts || []).filter(item => item.faction === "Red").length;
  const evac = snap.units.filter(unit => unit.isEvacuated).length;
  const resupply = snap.units.filter(unit => unit.needsResupply).length;
  const supportOpen = (snap.operationalSupportRequests || []).filter(item => !["Completed", "Rejected", "Cancelled"].includes(item.status)).length;
  const cards = [
    ["IDF-SIDE EFFECTIVE", `${blue.filter(effective).length}/${blue.length}`],
    ["HEZB-SIDE EFFECTIVE", `${red.filter(effective).length}/${red.length}`],
    ["OBJECTIVE STATE", `B ${blueControlled} · R ${redControlled} / ${objectives.length}`],
    ["C2 REPORTS", `Q ${queuedReports} · D ${deliveredReports} · DROP ${droppedReports}`],
    ["SHARED CONTACTS", `B ${sharedBlue} · R ${sharedRed}`],
    ["CASUALTY / SUPPLY", `EVAC ${evac} · LOW ${resupply}`],
    ["SUPPORT REQUESTS", `${supportOpen} OPEN`],
    ["SYNTH BUILDINGS", String((snap.structures || []).length)],
    ["INTENTS", String((snap.intents || []).length)],
    ["SIM SPEED", `${snap.speed}×`],
    ["LOS / TICK", String(snap.performance?.lineOfSightEvaluations ?? 0)],
    ["DETECT PAIRS", String(snap.performance?.detectionCandidatePairs ?? 0)],
    ["PATH NODES", String(snap.performance?.pathNodesExpanded ?? 0)]
  ];
  $("statusCards").innerHTML = cards.map(([label, value]) => `<div class="status-card"><span>${label}</span><strong>${value}</strong></div>`).join("");
}


function renderCommandQueue() {
  const container = $("commandQueue");
  const messages = state.snapshot?.commandMessages || [];
  container.innerHTML = messages.slice(0, 8).map(message => {
    const status = message.status.toLowerCase();
    const timing = status === "queued" ? `due T+${message.deliverAtTick}` :
      message.deliveredTick == null ? status : `T+${message.deliveredTick}`;
    return `<div class="command-message ${escapeHtml(status)}"><div><strong>${escapeHtml(message.order)}</strong><span>${escapeHtml(formatTheaterCoordinate(message.targetXMeters, message.targetYMeters))}</span></div><small>${escapeHtml(message.nodeName)} · ${escapeHtml(timing)}</small></div>`;
  }).join("") || `<div class="inspector-empty compact">No commands in the channel.</div>`;
}

function renderSupportCatalog() {
  const container = $("supportCatalog");
  const assets = state.snapshot?.supportCatalog || [];
  container.innerHTML = assets.map(asset => {
    const quantity = asset.scenarioQuantity == null ? "NOT INSTANTIATED" : `${asset.scenarioQuantity} AUTHORED`;
    return `<div class="support-card"><div><strong>${escapeHtml(asset.name)}</strong><span>${escapeHtml(asset.kind)}</span></div><small class="${asset.scenarioQuantity == null ? "inactive" : "active"}">${quantity}</small><p>${escapeHtml(asset.dataBoundary)}</p></div>`;
  }).join("");

  const live = $("jointSupportAssets");
  const runtime = state.snapshot?.jointSupportAssets || [];
  live.innerHTML = runtime.map(asset => `<div class="support-card" ${asset.orbatNodeId ? `data-node-id="${escapeHtml(asset.orbatNodeId)}"` : ""}><div><strong>${escapeHtml(asset.name)}</strong><span>${escapeHtml(asset.role)} · ${escapeHtml(asset.zoneLabel || asset.operatingZoneId)}</span></div><small class="${asset.available ? "active" : "inactive"}">${escapeHtml(asset.status)} · ${escapeHtml(formatTheaterCoordinate(asset.x, asset.y))} · ${asset.speedMetersPerSecond.toFixed(0)}/${asset.maxSpeedMetersPerSecond.toFixed(0)} m/s · ACC ${asset.currentAccelerationMetersPerSecondSquared.toFixed(1)} (cap ${asset.accelerationMetersPerSecondSquared.toFixed(1)}) m/s² · FUEL ${asset.fuelPercent}% · STORES ${asset.storesRemaining}</small><p>${escapeHtml(asset.payloadClass)}</p></div>`).join("");
  live.querySelectorAll("[data-node-id]").forEach(card => card.addEventListener("click", () => selectNode(card.dataset.nodeId, false)));

  const cueContainer = $("counterBatteryCues");
  const cues = state.snapshot?.counterBatteryCues || [];
  cueContainer.innerHTML = cues.slice(0, 6).map(cue => `<div class="support-card"><div><strong>${escapeHtml(cue.id)}</strong><span>${escapeHtml(cue.sensorId)}</span></div><small class="active">T+${cue.createdTick} · UNCERTAINTY ±${Math.round(cue.uncertaintyRadiusMeters)} m</small><p>Broad synthetic launch-area estimate only; exact origin is intentionally unavailable.</p></div>`).join("") || `<div class="inspector-empty compact">Radar has not generated a cue yet.</div>`;

  const missions = $("jointSupportMissions");
  const tasks = state.snapshot?.jointSupportMissions || [];
  missions.innerHTML = tasks.slice(0, 8).map(m => `<div class="support-card"><div><strong>${escapeHtml(m.kind)}</strong><span>${escapeHtml(m.state)}</span></div><small>${m.assignedAssetId ? escapeHtml(m.assignedAssetId) : "UNASSIGNED"} · risk ${Math.round((m.friendlyRiskScore || 0) * 100)}%</small><p>${escapeHtml(m.reason)}</p></div>`).join("") || `<div class="inspector-empty compact">No joint-support task yet.</div>`;

  const operational = $("operationalSupportRequests");
  const requests = state.snapshot?.operationalSupportRequests || [];
  operational.innerHTML = requests.slice(0, 10).map(request => `<div class="support-card"><div><strong>${escapeHtml(request.kind)}</strong><span>${escapeHtml(request.status)}</span></div><small class="${request.status === "Completed" ? "active" : "inactive"}">${escapeHtml(request.requesterEntityKey)} · ${request.assignedAssetId ? escapeHtml(request.assignedAssetId) : "UNASSIGNED"} · T+${request.createdTick}</small><p>${escapeHtml(request.statusReason)}</p></div>`).join("") || `<div class="inspector-empty compact">No operational support requests yet.</div>`;
  renderTheaterSupportBoard(runtime, tasks, cues);
}

function renderTheaterSupportBoard(runtime, tasks, cues) {
  const board = $("theaterSupportBoard");
  if (!board) return;
  board.style.display = state.layerVisibility.support ? "block" : "none";
  const airborne = runtime.filter(asset => ["FrontlineIsr", "BorderResponse", "CombatAirPatrol"].includes(asset.role)).length;
  const busy = runtime.filter(asset => !asset.available).length;
  const radar = runtime.find(asset => asset.kind === "CounterBatteryRadar");
  $("supportBoardSummary").textContent = `${airborne} AIRBORNE · ${busy} TASKED · RADAR ${radar ? "ON" : "OFF"}`;

  const priority = runtime.filter(asset =>
    asset.kind === "CounterBatteryRadar" || asset.kind === "TubeArtillery" ||
    asset.role === "FrontlineIsr" || asset.role === "BorderResponse" || asset.role === "CombatAirPatrol");
  $("theaterSupportAssets").innerHTML = priority.map(asset => `<div class="theater-support-asset ${asset.available ? "" : "busy"}" ${asset.orbatNodeId ? `data-node-id="${escapeHtml(asset.orbatNodeId)}"` : ""} title="${escapeHtml(asset.payloadClass)}"><div class="tsa-top"><strong>${escapeHtml(asset.name)}</strong><em>${asset.available ? "READY" : "TASKED"}</em></div><span class="tsa-zone">${escapeHtml(asset.zoneLabel || asset.operatingZoneId)}</span><span class="tsa-state">${escapeHtml(asset.status)} · ${asset.speedMetersPerSecond.toFixed(0)}/${asset.maxSpeedMetersPerSecond.toFixed(0)} m/s · a ${asset.currentAccelerationMetersPerSecondSquared.toFixed(1)} · ${asset.fuelPercent}% fuel · ${asset.storesRemaining} stores</span></div>`).join("");
  $("theaterSupportAssets").querySelectorAll("[data-node-id]").forEach(card => card.addEventListener("click", () => selectNode(card.dataset.nodeId, false)));

  const latest = tasks[0];
  const latestCue = cues?.[0];
  $("theaterSupportLastTask").textContent = latest
    ? `LAST TASK · ${latest.kind} · ${latest.state} · ${latest.assignedAssetId || "unassigned"}${latestCue ? ` · radar uncertainty ±${Math.round(latestCue.uncertaintyRadiusMeters)} m` : ""} · ${latest.reason}`
    : "No counter-battery task yet. Run the simulation or use Support → Simulate rocket launch.";
}

async function generateDiagnosticReport() {
  const modal = $("diagnosticModal");
  const message = $("diagnosticMessage");
  modal.classList.remove("hidden");
  message.textContent = "Collecting server and browser diagnostic state…";
  $("diagnosticPreview").value = "";
  try {
    const started = performance.now();
    const response = await fetch("/api/diagnostics/report", { cache: "no-store" });
    const report = await response.json().catch(() => ({}));
    pushBounded(state.clientDiagnostics.apiRequests, {
      at: new Date().toISOString(), method: "GET", url: "/api/diagnostics/report", status: response.status,
      durationMs: Math.round(performance.now() - started), ok: response.ok
    }, 250);
    if (!response.ok) throw new Error(report?.message || report?.error || `Diagnostic request failed (${response.status})`);

    report.client = {
      generatedAt: new Date().toISOString(),
      userAgent: navigator.userAgent,
      pageUrl: location.href,
      mapLoaded: state.mapLoaded,
      mapZoom: state.map?.getZoom?.() ?? null,
      selectedNodeId: state.selectedNodeId,
      selectedUnitId: state.selectedUnitId,
      layerVisibility: { ...state.layerVisibility },
      eventFilter: state.eventFilter,
      errors: [...state.clientDiagnostics.errors],
      apiRequests: [...state.clientDiagnostics.apiRequests],
      connectionEvents: [...state.clientDiagnostics.connectionEvents]
    };
    state.lastDiagnosticReport = report;
    const summary = report.quickSummary || report.QuickSummary || {};
    $("diagnosticSummary").textContent = `T+${summary.tick ?? "?"} · ${summary.phase ?? "?"} · structures ${summary.syntheticStructures ?? "?"} · C2 queued ${summary.contactReportsQueued ?? "?"} / dropped ${summary.contactReportsDropped ?? "?"} · evac ${summary.evacuated ?? "?"} · integrity warnings ${summary.integrityWarningCount ?? "?"}`;
    $("diagnosticPreview").value = JSON.stringify(report, null, 2);
    message.textContent = "Report ready. Download the JSON and attach it in chat after a bad run.";
  } catch (error) {
    recordClientError("diagnostic-report", error);
    message.textContent = `Report failed: ${error?.message || String(error)}`;
  }
}

async function copyDiagnosticReport() {
  const text = $("diagnosticPreview").value;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    $("diagnosticMessage").textContent = "Full diagnostic report copied to clipboard.";
  } catch (error) {
    recordClientError("diagnostic-copy", error);
    $("diagnosticPreview").focus();
    $("diagnosticPreview").select();
    $("diagnosticMessage").textContent = "Clipboard access was blocked. The report text is selected; copy it manually.";
  }
}

function downloadDiagnosticReport() {
  const text = $("diagnosticPreview").value;
  if (!text) return;
  const summary = state.lastDiagnosticReport?.quickSummary || state.lastDiagnosticReport?.QuickSummary || {};
  const tick = summary.tick ?? state.snapshot?.tick ?? 0;
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `FieldSim_v1_10_report_T${tick}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  $("diagnosticMessage").textContent = `Downloaded FieldSim_v1_10_report_T${tick}.json.`;
}

function closeDiagnosticReport() { $("diagnosticModal").classList.add("hidden"); }

function displayFaction(faction) { return faction === "Blue" ? "IDF side" : faction === "Red" ? "Hezbollah side" : faction; }

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char]);
}

function showOrderError(error) {
  const message = $("orderMessage");
  message.classList.add("error");
  message.textContent = error.message || String(error);
}

$("orbatSearch").addEventListener("input", event => { state.search = event.target.value; renderOrbat(); });
$("expandButton").addEventListener("click", () => { if (state.snapshot) state.snapshot.orbat.nodes.forEach(node => state.expanded.add(node.id)); renderOrbat(); });
$("collapseButton").addEventListener("click", () => { state.expanded.clear(); if (state.snapshot) { state.expanded.add(state.snapshot.orbat.blueRootId); state.expanded.add(state.snapshot.orbat.redRootId); } renderOrbat(); });
$("playButton").addEventListener("click", () => post("/api/control/play").catch(showOrderError));
$("pauseButton").addEventListener("click", () => post("/api/control/pause").catch(showOrderError));
$("stepButton").addEventListener("click", () => post("/api/control/step/1").catch(showOrderError));
$("stepTenButton").addEventListener("click", () => post("/api/control/step/10").catch(showOrderError));
$("resetButton").addEventListener("click", async () => {
  try {
    state.selectedNodeId = null;
    state.selectedUnitId = null;
    state.trails.clear();
    state.previousPositions.clear();
    state.pickingOrderTarget = false;
    state.orderTargetMeters = null;
    $("orderCell").value = "";
    state.snapshot = await post("/api/control/reset");
    render();
    fitScenario();
  } catch (error) { showOrderError(error); }
});
document.querySelectorAll(".speed").forEach(button => button.addEventListener("click", () => post(`/api/control/speed/${button.dataset.speed}`).catch(showOrderError)));

document.querySelectorAll(".event-filter").forEach(button => button.addEventListener("click", () => {
  state.eventFilter = button.dataset.filter;
  document.querySelectorAll(".event-filter").forEach(item => item.classList.toggle("active", item === button));
  renderEvents();
}));

$("counterBatteryTestButton").addEventListener("click", async () => {
  const message = $("supportTestMessage");
  try {
    message.textContent = "Running synthetic launch / radar / support chain…";
    const result = await post("/api/support/test-counter-battery");
    message.textContent = `${result.state}: ${result.assignedAssetId || "no asset"} · ${result.reason}`;
  } catch (error) {
    message.textContent = error.message || String(error);
  }
});

document.querySelectorAll(".rail-tab").forEach(button => button.addEventListener("click", () => {
  document.querySelectorAll(".rail-tab").forEach(item => item.classList.toggle("active", item === button));
  const panel = button.dataset.panel;
  $("orbatPanel").classList.toggle("hidden", panel !== "orbat");
  $("layersPanel").classList.toggle("hidden", panel !== "layers");
  $("supportPanel").classList.toggle("hidden", panel !== "support");
  $("statusPanel").classList.toggle("hidden", panel !== "status");
}));

for (const [id, key] of [
  ["toggleBasemap", "basemap"], ["toggleRoutes", "routes"], ["toggleObjectives", "objectives"], ["toggleImpacts", "impacts"], ["toggleUrban", "urban"],
  ["toggleBlue", "blue"], ["toggleRed", "red"], ["toggleSupport", "support"], ["toggleLabels", "labels"],
  ["toggleTrails", "trails"], ["toggleIndividuals", "individuals"]
]) {
  $(id).addEventListener("change", event => {
    state.layerVisibility[key] = Boolean(event.target.checked);
    renderMapState(false);
    if (key === "support") renderSupportCatalog();
  });
}

$("diagnosticReportButton").addEventListener("click", generateDiagnosticReport);
$("copyDiagnosticButton").addEventListener("click", copyDiagnosticReport);
$("downloadDiagnosticButton").addEventListener("click", downloadDiagnosticReport);
$("closeDiagnosticButton").addEventListener("click", closeDiagnosticReport);
$("closeDiagnosticFooterButton").addEventListener("click", closeDiagnosticReport);
$("diagnosticModal").addEventListener("click", event => { if (event.target === $("diagnosticModal")) closeDiagnosticReport(); });

$("fitScenarioButton").addEventListener("click", fitScenario);
$("fitSelectionButton").addEventListener("click", focusSelectionOnMap);
$("clearSelectionButton").addEventListener("click", () => {
  state.selectedNodeId = null;
  state.selectedUnitId = null;
  render();
});

$("pickTargetButton").addEventListener("click", () => {
  state.pickingOrderTarget = !state.pickingOrderTarget;
  $("pickTargetButton").classList.toggle("active", state.pickingOrderTarget);
  $("pickTargetButton").textContent = state.pickingOrderTarget ? "Click anywhere in theater…" : "Pick target on map";
  if (state.map) state.map.getCanvas().style.cursor = state.pickingOrderTarget ? "crosshair" : "";
});

$("issueOrderButton").addEventListener("click", async () => {
  const nodeId = state.selectedNodeId;
  if (!nodeId) return showOrderError(new Error("Select an ORBAT node first."));
  const target = state.orderTargetMeters;
  if (!target) return showOrderError(new Error("Pick an exact target point on the map first."));
  try {
    const result = await post("/api/orders", { orbatNodeId: nodeId, order: $("orderType").value, xMeters: target.x, yMeters: target.y });
    const message = $("orderMessage");
    message.classList.remove("error");
    message.textContent = result.message;
  } catch (error) { showOrderError(error); }
});

initMap();
connect();
