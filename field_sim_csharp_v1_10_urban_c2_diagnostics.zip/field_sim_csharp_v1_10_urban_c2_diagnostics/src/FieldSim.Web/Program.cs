using System.Text.Json;
using System.Text.Json.Serialization;
using FieldSim.Core;
using FieldSim.Data;
using FieldSim.Domain;
using FieldSim.Scenarios;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<SimulationSession>();
builder.Services.AddHostedService<SimulationTicker>();

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/health", () => Results.Ok(new
{
    service = "FieldSim.Web",
    version = "1.10.0-urban-c2-diagnostics",
    status = "ok"
}));

app.MapGet("/api/snapshot", (SimulationSession session) => Results.Json(session.GetSnapshot()));
app.MapGet("/api/journal", (long? since, int? max, SimulationSession session) =>
    Results.Json(session.GetJournalSince(Math.Max(0, since ?? 0), Math.Clamp(max ?? 500, 1, 5000))));
app.MapGet("/api/diagnostics/performance", (SimulationSession session) => Results.Json(session.GetPerformance()));
app.MapGet("/api/diagnostics/report", (SimulationSession session) => Results.Json(session.GetDiagnosticReport()));

app.MapPost("/api/control/play", (SimulationSession session) =>
{
    session.Play();
    return Results.Ok(session.GetClock());
});

app.MapPost("/api/control/pause", (SimulationSession session) =>
{
    session.Pause();
    return Results.Ok(session.GetClock());
});

app.MapPost("/api/control/reset", (SimulationSession session) =>
{
    session.Reset();
    return Results.Ok(session.GetSnapshot());
});

app.MapPost("/api/control/step/{seconds:int}", (int seconds, SimulationSession session) =>
{
    if (seconds is not (1 or 10))
        return Results.BadRequest(new { error = "Supported manual steps are 1 and 10 seconds." });
    return Results.Ok(session.Step(seconds));
});

app.MapPost("/api/control/speed/{speed:int}", (int speed, SimulationSession session) =>
{
    if (speed is not (1 or 5 or 20))
        return Results.BadRequest(new { error = "Supported speeds are 1, 5, and 20." });
    session.SetSpeed(speed);
    return Results.Ok(session.GetClock());
});

app.MapPost("/api/orders", (OrderRequest request, SimulationSession session) =>
{
    var result = session.IssueOrder(request);
    return result.Success ? Results.Ok(result) : Results.BadRequest(result);
});

app.MapPost("/api/support/test-counter-battery", (SimulationSession session) =>
    Results.Ok(session.SimulateCounterBatteryTest()));

app.MapGet("/api/stream", async (HttpContext context, SimulationSession session) =>
{
    context.Response.Headers["Cache-Control"] = "no-cache";
    context.Response.Headers["Connection"] = "keep-alive";
    context.Response.ContentType = "text/event-stream";

    var options = new JsonSerializerOptions
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase) }
    };

    var lastRevision = -1L;
    var idleLoops = 0;
    while (!context.RequestAborted.IsCancellationRequested)
    {
        var snapshot = session.GetSnapshot();
        if (snapshot.Revision != lastRevision)
        {
            var json = JsonSerializer.Serialize(snapshot, options);
            await context.Response.WriteAsync($"event: snapshot\ndata: {json}\n\n", context.RequestAborted);
            await context.Response.Body.FlushAsync(context.RequestAborted);
            lastRevision = snapshot.Revision;
            idleLoops = 0;
        }
        else if (++idleLoops >= 40)
        {
            await context.Response.WriteAsync(": keepalive\n\n", context.RequestAborted);
            await context.Response.Body.FlushAsync(context.RequestAborted);
            idleLoops = 0;
        }

        try
        {
            await Task.Delay(250, context.RequestAborted);
        }
        catch (OperationCanceledException)
        {
            break;
        }
    }
});

app.MapFallbackToFile("index.html");
app.Run();

public sealed class SimulationTicker(SimulationSession session) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(250));
        try
        {
            while (await timer.WaitForNextTickAsync(stoppingToken))
                session.AdvanceWallClockQuarterSecond();
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Normal shutdown.
        }
    }
}
