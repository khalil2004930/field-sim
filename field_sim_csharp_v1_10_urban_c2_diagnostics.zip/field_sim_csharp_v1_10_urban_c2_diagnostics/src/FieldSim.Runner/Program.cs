using System.Globalization;
using FieldSim.Core;
using FieldSim.Data;
using FieldSim.Domain;
using FieldSim.Scenarios;

namespace FieldSim.Runner;

internal static class Program
{
    private static int Main(string[] args)
    {
        try
        {
            return args.Length == 0 ? PrintUsage() : args[0].ToLowerInvariant() switch
            {
                "forces" => RunForces(args),
                "weapons" => RunWeapons(args),
                "formations" => RunFormations(args),
                "vehicles" => RunVehicles(args),
                "spatial" => RunSpatialDemo(args),
                "engagement" => RunEngagementDemo(args),
                "theater" => RunTheater(args),
                "map" => RunMap(args),
                _ => PrintUsage()
            };
        }
        catch (Exception exception) when (exception is IOException or InvalidDataException or ArgumentException)
        {
            Console.Error.WriteLine(exception.Message);
            return 1;
        }
    }

    private static int RunWeapons(string[] args)
    {
        if (args.Length > 1 && !string.Equals(args[1], "hezbollah",
                StringComparison.OrdinalIgnoreCase))
        {
            return PrintUsage();
        }

        var mode = args.Length > 2 ? args[2].ToLowerInvariant() : "osint";
        var dataRoot = DataRootLocator.Find();
        var dataset = WeaponDataLoader.LoadHezbollahBaseline(dataRoot);
        if (mode == "manual")
        {
            var overridePath = args.Length > 3
                ? Path.GetFullPath(args[3])
                : Path.Combine(dataRoot, "manual", "hezbollah_weapon_overrides.json");
            WeaponDataLoader.ApplyOverrides(dataset, overridePath);
        }
        else if (mode != "osint")
        {
            return PrintUsage();
        }

        Console.WriteLine("Hezbollah weapon-system evidence catalog");
        Console.WriteLine($"Mode: {(mode == "manual" ? "OSINT + manual overrides" : "OSINT baseline")}");
        Console.WriteLine($"Sources: {dataset.Sources.Count} | Systems: {dataset.Weapons.Count} | " +
            $"Research queue: {dataset.ResearchQueue.Count} | Overrides: {dataset.TotalOverrides}");
        Console.WriteLine("Unknown fields remain —. Historical possession is not current availability.");
        foreach (var weapon in dataset.Weapons) PrintWeapon(dataset, weapon);
        Console.WriteLine("\nResearch queue (not active realistic-mode inventory)");
        foreach (var candidate in dataset.ResearchQueue)
        {
            Console.WriteLine($"  {candidate.Designation} [{candidate.Status}]: {candidate.Reason}");
            if (candidate.PublicSpecificationSummary is not null)
            {
                Console.WriteLine($"    {candidate.PublicSpecificationSummary}");
            }
        }
        return 0;
    }

    private static int RunForces(string[] args)
    {
        var mode = args.Length > 1 ? args[1].ToLowerInvariant() : "osint";
        var dataRoot = DataRootLocator.Find();
        var dataset = ForceDataLoader.LoadBaseline(dataRoot);
        if (mode == "manual")
        {
            var overridePath = args.Length > 2
                ? Path.GetFullPath(args[2])
                : Path.Combine(dataRoot, "manual", "overrides.json");
            ForceDataLoader.ApplyOverrides(dataset, overridePath);
        }
        else if (mode != "osint")
        {
            return PrintUsage();
        }

        Console.WriteLine($"Force data mode: {(mode == "manual" ? "OSINT + manual overrides" : "OSINT baseline")}");
        Console.WriteLine($"Sources: {dataset.Sources.Count} | Platforms: {dataset.Platforms.Count} | Overrides: {dataset.TotalOverrides}");
        Console.WriteLine("Unknown values are printed as — and are never silently guessed.");
        foreach (var platform in dataset.Platforms) PrintPlatform(dataset, platform);
        return 0;
    }


    private static int RunFormations(string[] args)
    {
        if (args.Length > 1 && !string.Equals(args[1], "idf", StringComparison.OrdinalIgnoreCase))
            return PrintUsage();
        var dataset = FormationDataLoader.LoadIdfPublicPeacetime(DataRootLocator.Find());
        Console.WriteLine($"{dataset.DatasetName} (as of {dataset.AsOf})");
        Console.WriteLine($"Formations: {dataset.Formations.Count} | Sources: {dataset.Sources.Count}");
        Console.WriteLine(dataset.DataBoundary);
        var root = dataset.Find(dataset.RootId)!;
        PrintFormationNode(dataset, root, 0);
        return 0;
    }

    private static void PrintFormationNode(FormationDataset dataset, FormationRecord formation, int depth)
    {
        Console.WriteLine($"{new string(' ', depth * 2)}- {formation.DisplayName} [{formation.Level}/{formation.Status}]");
        foreach (var child in dataset.ChildrenOf(formation.Id)
                     .OrderBy(item => item.Level)
                     .ThenBy(item => item.Number ?? int.MaxValue)
                     .ThenBy(item => item.Name, StringComparer.Ordinal))
        {
            PrintFormationNode(dataset, child, depth + 1);
        }
    }

    private static int RunVehicles(string[] args)
    {
        if (args.Length > 1 && !string.Equals(args[1], "idf", StringComparison.OrdinalIgnoreCase))
            return PrintUsage();
        var dataset = VehicleDataLoader.LoadIdfGroundVehicleBaseline(DataRootLocator.Find());
        Console.WriteLine(dataset.DatasetName);
        Console.WriteLine($"Vehicles: {dataset.Vehicles.Count} | Sources: {dataset.Sources.Count}");
        Console.WriteLine(dataset.DataBoundary);
        foreach (var vehicle in dataset.Vehicles)
        {
            Console.WriteLine($"\n{vehicle.DisplayName} [{vehicle.Id}] — {vehicle.Kind}");
            Console.WriteLine($"  Crew: {vehicle.Crew.Crew}" + (vehicle.Crew.Passengers > 0 ? $" + {vehicle.Crew.Passengers} passengers" : ""));
            Console.WriteLine($"  Public nominal dimensions: {vehicle.Dimensions.LengthMeters:0.##} x {vehicle.Dimensions.WidthMeters:0.##} x {vehicle.Dimensions.HeightMeters:0.##} m");
            Console.WriteLine($"  Public road speed: {vehicle.Mobility.PublicMaximumRoadSpeedKph?.ToString("0", CultureInfo.InvariantCulture) ?? "—"} km/h");
            Console.WriteLine($"  Protection: {vehicle.Protection.Mode}, {vehicle.Protection.Zones.Count} synthetic zones");
            Console.WriteLine($"  Signatures: normalized game-only visual/thermal/radar/acoustic values");
            Console.WriteLine($"  Boundary: {vehicle.DataBoundary}");
        }
        return 0;
    }

    private static int RunSpatialDemo(string[] args)
    {
        var village = VillageMapCatalog.CreateDefault()
            .SelectMany(sector => sector.Villages)
            .First(item => item.Name == "Aytaronn");
        var state = VillageTrainingScenario.Create(village);
        Console.WriteLine($"Spatial demo: {village.Name} — local synthetic XYZ, cell size {state.World.CellSizeMeters:0} m");
        foreach (var unit in state.Units)
        {
            var p = state.PositionOf(unit);
            var c = state.ContextOf(unit);
            Console.WriteLine($"  #{unit.Id} {unit.DisplayName}: ({p.X:0},{p.Y:0},{p.Z:0.0}) m • {c.Terrain}/{c.Area} • {state.TerritoryFor(unit.Faction, unit.Position)}");
        }
        var blue = state.Units.First(unit => unit.Faction == TacticalFaction.Blue);
        var red = state.Units.First(unit => unit.Faction == TacticalFaction.Red);
        var los = LineOfSightEngine.Evaluate(state, blue, red);
        Console.WriteLine($"LOS #{blue.Id}->#{red.Id}: {los.State}, {los.HorizontalDistanceMeters:0} m, obscuration {los.ObscurationFactor:P0}");
        Console.WriteLine($"Blue knowledge of #{red.Id}: {state.Knowledge[TacticalFaction.Blue].GetContact(red.Id)?.Classification.ToString() ?? "none"}");
        Console.WriteLine("This demo uses no real coordinates/elevations or real sensor equation.");
        return 0;
    }

    private static int RunEngagementDemo(string[] args)
    {
        var ticks = PositiveArgument(args, 1, 120);
        var village = VillageMapCatalog.CreateDefault()
            .SelectMany(sector => sector.Villages)
            .First(item => item.Name == "Aytaronn");
        var state = VillageTrainingScenario.Create(village);
        if (args.Length > 2 && Enum.TryParse<LightCondition>(args[2], true, out var light))
            state.Environment.ApplyPreset(light, WeatherVisibility.Clear);

        Console.WriteLine($"FieldSim v1.2 autonomous engagement: {state.ScenarioName}");
        Console.WriteLine(state.MissionBriefing);
        Console.WriteLine($"Environment: {state.Environment.Light}/{state.Environment.Visibility}");
        Console.WriteLine("All weapon/armor/detection relationships in this demo are synthetic game abstractions.");
        Console.WriteLine("\nInitial orders");
        foreach (var unit in state.Units)
        {
            var command = state.CommandFor(unit)!;
            Console.WriteLine($"  {unit.DisplayName,-18} {command.Order,-16} -> " +
                              $"{VillageGridReference.ShortCellLabel(command.Objective)}");
        }
        for (var i = 0; i < ticks && state.Result == BattleResult.Ongoing; i++)
            TacticalEngine.Step(state);

        Console.WriteLine("\nBattle timeline");
        var activity = state.ActivityEvents.Select(item =>
            (item.Tick, Kind: item.Type.ToString(), item.Message));
        var combat = state.CombatEvents.Select(item =>
            (item.Tick, Kind: item.Type.ToString(), item.Message));
        foreach (var item in activity.Concat(combat).OrderBy(item => item.Tick).TakeLast(120))
            Console.WriteLine($"T+{item.Tick:0000}  [{item.Kind.ToUpperInvariant()}] {item.Message}");

        Console.WriteLine($"\nFinal state: phase={state.Phase}, result={state.Result}, time={state.Tick}s");
        foreach (var objective in state.Objectives)
            Console.WriteLine($"  Objective {objective.DisplayName}: Blue {objective.BlueControlSeconds}s / " +
                              $"Red {objective.RedControlSeconds}s");
        foreach (var unit in state.Units.Where(unit => unit.Soldier is not null))
        {
            var soldier = unit.Soldier!;
            var command = state.CommandFor(unit)!;
            Console.WriteLine($"  {unit.DisplayName,-18} alive={unit.Alive,-5} HP={soldier.Vitals.HitPoints,5:0.0} " +
                $"blood={soldier.Vitals.BloodVolume01,5:P0} suppression={soldier.Vitals.Suppression01,5:P0} " +
                $"condition={soldier.Vitals.Condition} action={command.Action} " +
                $"ammo={soldier.PrimaryWeapon.RoundsLoaded}/{soldier.PrimaryWeapon.ReserveRounds}");
        }
        return 0;
    }

    private static int RunTheater(string[] args)
    {
        var hours = PositiveArgument(args, 1, 72);
        var seed = PositiveArgument(args, 2, 42);
        var runs = PositiveArgument(args, 3, 1);

        if (runs == 1)
        {
            var state = SouthLebanon2026Scenario.Create((uint)seed);
            TheaterEngine.Run(state, hours);
            Console.WriteLine(state.ScenarioName);
            Console.WriteLine($"Observer run: {hours} hours, seed {seed}\n");
            foreach (var item in state.Events)
            {
                Console.WriteLine($"H+{item.Hour:000}  {item.Message}");
            }
            Console.WriteLine("\nFinal abstract outcome");
            PrintOutcome(TheaterEngine.GetOutcome(state));
            return 0;
        }

        long idf = 0, hezbollah = 0, risk = 0, infrastructure = 0, displaced = 0, escalation = 0;
        for (var run = 0; run < runs; run++)
        {
            var state = SouthLebanon2026Scenario.Create((uint)(seed + run));
            TheaterEngine.Run(state, hours);
            var outcome = TheaterEngine.GetOutcome(state);
            idf += outcome.IdfCapacity;
            hezbollah += outcome.HezbollahCapacity;
            risk += outcome.CivilianRisk;
            infrastructure += outcome.Infrastructure;
            displaced += outcome.DisplacedPopulation;
            escalation += outcome.Escalation;
        }

        Console.WriteLine($"Observer batch: {runs} runs x {hours} hours, seeds {seed}..{seed + runs - 1}");
        Console.WriteLine($"Mean IDF aggregate capacity:       {idf / runs}");
        Console.WriteLine($"Mean Hezbollah aggregate capacity: {hezbollah / runs}");
        Console.WriteLine($"Mean civilian risk:                {risk / runs}/100");
        Console.WriteLine($"Mean infrastructure:               {infrastructure / runs}/100");
        Console.WriteLine($"Mean displaced population index:   {displaced / runs}");
        Console.WriteLine($"Mean escalation:                    {escalation / runs}/100");
        return 0;
    }

    private static int RunMap(string[] args)
    {
        if (args.Length > 1 && !string.Equals(args[1], "status", StringComparison.OrdinalIgnoreCase))
            return PrintUsage();
        var dataRoot = DataRootLocator.Find();
        var package = args.Length > 2
            ? TheaterMapLoader.Load(Path.GetFullPath(args[2]))
            : TheaterMapLoader.LoadDefault(dataRoot);
        Console.WriteLine($"{package.Manifest.Name} — package {package.Manifest.Version}, as of {package.Manifest.AsOf}");
        Console.WriteLine($"CRS: {package.Manifest.CoordinateReferenceSystem}");
        Console.WriteLine($"Bounds: {package.Manifest.Bounds.West:F4}, {package.Manifest.Bounds.South:F4} to " +
                          $"{package.Manifest.Bounds.East:F4}, {package.Manifest.Bounds.North:F4}");
        Console.WriteLine($"Loaded features: {package.FeatureCount}");
        foreach (var descriptor in package.Manifest.Layers)
        {
            var count = package.Layers.TryGetValue(descriptor.Id, out var features) ? features.Count : 0;
            var state = package.Layers.ContainsKey(descriptor.Id) ? $"loaded ({count})" : "optional / not built";
            Console.WriteLine($"  {descriptor.Id,-28} {state}");
        }
        Console.WriteLine("Boundary: " + package.Manifest.DataBoundary);
        return 0;
    }

    private static void PrintPlatform(ForceDataset dataset, PlatformRecord platform)
    {
        var source = dataset.FindSource(platform.SourceId)!;
        Console.WriteLine($"\n{platform.Name} [{platform.Id}]");
        Console.WriteLine($"  Domain/role: {platform.Domain} / {platform.Role}");
        Console.WriteLine($"  Public status: {platform.PublicStatus}");
        Console.WriteLine($"  Quantity: {FormatQuantity(platform.Quantity)}");
        Console.WriteLine($"  Quantity scope: {platform.Quantity.Scope}");
        Console.WriteLine($"  Readiness: {FormatPercent(platform.ReadinessPercent)}");
        Console.WriteLine($"  APS coverage: {FormatPercent(platform.ApsCoveragePercent)}");
        Console.WriteLine($"  Endurance/ceiling: {Format(platform.EnduranceHours)} h / {Format(platform.CeilingFeet)} ft");
        Console.WriteLine($"  Manual overrides: {platform.OverrideCount}");
        Console.WriteLine($"  Source: {source.Publisher}, {source.PublishedDate:yyyy-MM-dd}");
        Console.WriteLine($"  {source.Url}");
        Console.WriteLine($"  Boundary: {platform.DataBoundary}");
    }

    private static void PrintWeapon(WeaponDataset dataset, WeaponSystem weapon)
    {
        Console.WriteLine($"\n{weapon.Name} [{weapon.Id}]");
        Console.WriteLine($"  Category/role: {weapon.Category} / {weapon.Role}");
        Console.WriteLine($"  Evidence: {weapon.EvidenceStatus} ({weapon.EvidenceConfidencePercent}%)");
        Console.WriteLine($"  Public status: {weapon.PublicStatus}");
        Console.WriteLine($"  Current quantity: {FormatQuantity(weapon.Quantity)}");
        Console.WriteLine($"  Public range: {FormatRange(weapon.Range)}");
        Console.WriteLine($"  Accuracy model: {FormatAccuracy(weapon.Accuracy)}");
        Console.WriteLine($"  Guidance: {string.Join(", ", weapon.Guidance)}");
        Console.WriteLine($"  Operator burden: training {weapon.Operator.TrainingBurden}, " +
            $"setup {weapon.Operator.SetupBurden}, logistics {weapon.Operator.LogisticsBurden}");
        Console.WriteLine($"  Weather: wind {weapon.Weather.Wind}, rain {weapon.Weather.Precipitation}, " +
            $"visibility {weapon.Weather.Visibility}, temperature {weapon.Weather.Temperature}");
        Console.WriteLine($"  Sources: {string.Join(", ", weapon.SourceIds.Select(id => dataset.FindSource(id)!.Publisher))}");
        Console.WriteLine($"  Boundary: {weapon.DataBoundary}");
    }

    private static string FormatQuantity(QuantityRange quantity) => quantity.IsUnknown
        ? "—"
        : $"{quantity.Minimum}/{quantity.Likely}/{quantity.Maximum} (minimum/likely/maximum)";

    private static string FormatPercent(int? value) => value is null ? "—" : $"{value}%";
    private static string Format(int? value) => value?.ToString() ?? "—";

    private static string FormatRange(PublicRange range) => range.IsUnknown
        ? "—"
        : $"{range.MinimumKm:0.###}-{range.MaximumKm:0.###} km";

    private static string FormatAccuracy(AccuracyProfile accuracy) => accuracy.Measure switch
    {
        AccuracyMeasure.CircularErrorProbable => $"reported CEP {accuracy.CepMeters:0.###} m",
        AccuracyMeasure.ImpactArea =>
            $"reported impact area {accuracy.DispersionMajorMeters:0.###} x {accuracy.DispersionMinorMeters:0.###} m",
        AccuracyMeasure.OperatorDependent => "operator-dependent; CEP not applicable",
        AccuracyMeasure.NotApplicable => "not applicable",
        _ => "—"
    };

    private static void PrintOutcome(TheaterOutcome outcome)
    {
        Console.WriteLine($"IDF aggregate capacity:       {outcome.IdfCapacity}");
        Console.WriteLine($"Hezbollah aggregate capacity: {outcome.HezbollahCapacity}");
        Console.WriteLine($"Average civilian risk:        {outcome.CivilianRisk}/100");
        Console.WriteLine($"Average infrastructure:       {outcome.Infrastructure}/100");
        Console.WriteLine($"Displaced population index:   {outcome.DisplacedPopulation}");
        Console.WriteLine($"Escalation:                    {outcome.Escalation}/100");
    }

    private static int PositiveArgument(string[] args, int index, int fallback) =>
        args.Length > index && int.TryParse(args[index], out var value) && value > 0
            ? value
            : fallback;

    private static int PrintUsage()
    {
        Console.WriteLine("FieldSim commands:");
        Console.WriteLine("  forces osint");
        Console.WriteLine("  forces manual [override-file]");
        Console.WriteLine("  weapons hezbollah osint");
        Console.WriteLine("  weapons hezbollah manual [override-file]");
        Console.WriteLine("  formations idf");
        Console.WriteLine("  vehicles idf");
        Console.WriteLine("  spatial");
        Console.WriteLine("  engagement [ticks] [Day|Dusk|Night|MoonlitNight]");
        Console.WriteLine("  theater [hours] [seed] [runs]");
        Console.WriteLine("  map status [manifest-file]");
        return 2;
    }
}
