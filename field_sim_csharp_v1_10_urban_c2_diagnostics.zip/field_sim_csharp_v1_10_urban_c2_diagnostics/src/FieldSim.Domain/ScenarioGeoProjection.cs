namespace FieldSim.Domain;

/// <summary>
/// Lightweight local tangent-plane display projection used by the browser and scenario authoring.
/// It is intentionally a display/scenario reference, not a targeting-quality geodesy system.
/// </summary>
public static class ScenarioGeoProjection
{
    private const double MetersPerDegreeLatitude = 111_320.0;

    public static ScenarioLocalPoint ProjectToLocal(ScenarioDisplayMap map, double latitude, double longitude)
    {
        ArgumentNullException.ThrowIfNull(map);
        var localCenterX = map.TheaterWidthMeters * 0.5;
        var localCenterY = map.TheaterHeightMeters * 0.5;
        var cosLatitude = Math.Cos(map.CenterLatitude * Math.PI / 180.0);
        if (Math.Abs(cosLatitude) < 1e-9)
            throw new InvalidOperationException("Scenario display center is too close to a pole for the local projection.");

        var eastMeters = (longitude - map.CenterLongitude) * MetersPerDegreeLatitude * cosLatitude;
        var northMeters = (latitude - map.CenterLatitude) * MetersPerDegreeLatitude;
        return new ScenarioLocalPoint(localCenterX + eastMeters, localCenterY + northMeters);
    }

    public static ScenarioGeoPoint UnprojectToGeo(ScenarioDisplayMap map, double xMeters, double yMeters)
    {
        ArgumentNullException.ThrowIfNull(map);
        var localCenterX = map.TheaterWidthMeters * 0.5;
        var localCenterY = map.TheaterHeightMeters * 0.5;
        var cosLatitude = Math.Cos(map.CenterLatitude * Math.PI / 180.0);
        if (Math.Abs(cosLatitude) < 1e-9)
            throw new InvalidOperationException("Scenario display center is too close to a pole for the local projection.");

        var latitude = map.CenterLatitude + (yMeters - localCenterY) / MetersPerDegreeLatitude;
        var longitude = map.CenterLongitude + (xMeters - localCenterX) /
            (MetersPerDegreeLatitude * cosLatitude);
        return new ScenarioGeoPoint(latitude, longitude);
    }
}

public readonly record struct ScenarioLocalPoint(double X, double Y)
{
    public double DistanceTo(ScenarioLocalPoint other)
    {
        var dx = other.X - X;
        var dy = other.Y - Y;
        return Math.Sqrt(dx * dx + dy * dy);
    }
}

public readonly record struct ScenarioGeoPoint(double Latitude, double Longitude);
