namespace FieldSim.Domain;

public static class WeatherAssessmentEngine
{
    public static WeatherAssessment Assess(WeaponSystem weapon, WeatherCondition condition,
        double? manualRangeMultiplier = null)
    {
        if (manualRangeMultiplier is <= 0 or > 2)
        {
            throw new ArgumentOutOfRangeException(nameof(manualRangeMultiplier),
                "A manual range multiplier must be greater than 0 and no greater than 2.");
        }

        var active = new List<SensitivityLevel>();
        if (condition.WindMetersPerSecond >= 8) active.Add(weapon.Weather.Wind);
        if (condition.PrecipitationMillimetersPerHour >= 2)
            active.Add(weapon.Weather.Precipitation);
        if (condition.VisibilityKilometers <= 5) active.Add(weapon.Weather.Visibility);
        if (condition.TemperatureCelsius is <= 0 or >= 40)
            active.Add(weapon.Weather.Temperature);
        if (condition.NavigationInterference) active.Add(weapon.Weather.NavigationInterference);

        var overall = active.Count == 0 ? SensitivityLevel.Low : active.Max();
        if (manualRangeMultiplier is null || weapon.Range.IsUnknown)
        {
            return new WeatherAssessment(overall, false, null, null,
                "The realistic dataset has no sourced weapon-specific weather curve. " +
                "Sensitivity is qualitative; provide a manual multiplier to run a numeric what-if.");
        }

        return new WeatherAssessment(overall, true,
            weapon.Range.MinimumKm * manualRangeMultiplier,
            weapon.Range.MaximumKm * manualRangeMultiplier,
            "Numeric range is a manual scenario assumption, not an OSINT claim.");
    }
}
