namespace FieldSim.Domain;

public readonly record struct GeoCoordinate(double Latitude, double Longitude)
{
    public bool IsValid => Latitude is >= -90 and <= 90 && Longitude is >= -180 and <= 180;
}

public readonly record struct GeoBounds(double West, double South, double East, double North)
{
    public bool IsValid => West < East && South < North &&
                           West is >= -180 and <= 180 && East is >= -180 and <= 180 &&
                           South is >= -85 and <= 85 && North is >= -85 and <= 85;

    public GeoCoordinate Center => new((South + North) / 2.0, (West + East) / 2.0);
    public double LongitudeSpan => East - West;
    public double LatitudeSpan => North - South;
    public bool Contains(GeoCoordinate coordinate) =>
        coordinate.Longitude >= West && coordinate.Longitude <= East &&
        coordinate.Latitude >= South && coordinate.Latitude <= North;
}

public readonly record struct ProjectedPoint(double X, double Y);

public static class WebMercator
{
    private const double MaximumLatitude = 85.05112878;

    public static ProjectedPoint Project(GeoCoordinate coordinate)
    {
        var latitude = Math.Clamp(coordinate.Latitude, -MaximumLatitude, MaximumLatitude);
        var x = (coordinate.Longitude + 180.0) / 360.0;
        var sinLatitude = Math.Sin(latitude * Math.PI / 180.0);
        var y = 0.5 - Math.Log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * Math.PI);
        return new ProjectedPoint(x, y);
    }

    public static GeoCoordinate Unproject(ProjectedPoint point)
    {
        var longitude = point.X * 360.0 - 180.0;
        var n = Math.PI - 2.0 * Math.PI * point.Y;
        var latitude = 180.0 / Math.PI * Math.Atan(Math.Sinh(n));
        return new GeoCoordinate(latitude, longitude);
    }

    public static ProjectedPoint ToCanvas(GeoCoordinate coordinate, GeoBounds bounds,
        double width, double height)
    {
        var northWest = Project(new GeoCoordinate(bounds.North, bounds.West));
        var southEast = Project(new GeoCoordinate(bounds.South, bounds.East));
        var value = Project(coordinate);
        return new ProjectedPoint(
            (value.X - northWest.X) / (southEast.X - northWest.X) * width,
            (value.Y - northWest.Y) / (southEast.Y - northWest.Y) * height);
    }

    public static GeoCoordinate FromCanvas(ProjectedPoint point, GeoBounds bounds,
        double width, double height)
    {
        var northWest = Project(new GeoCoordinate(bounds.North, bounds.West));
        var southEast = Project(new GeoCoordinate(bounds.South, bounds.East));
        return Unproject(new ProjectedPoint(
            northWest.X + point.X / width * (southEast.X - northWest.X),
            northWest.Y + point.Y / height * (southEast.Y - northWest.Y)));
    }
}

public static class GeoMath
{
    public static double DistanceKilometers(GeoCoordinate first, GeoCoordinate second)
    {
        const double earthRadiusKilometers = 6371.0088;
        var latitude1 = first.Latitude * Math.PI / 180.0;
        var latitude2 = second.Latitude * Math.PI / 180.0;
        var latitudeDelta = (second.Latitude - first.Latitude) * Math.PI / 180.0;
        var longitudeDelta = (second.Longitude - first.Longitude) * Math.PI / 180.0;
        var a = Math.Sin(latitudeDelta / 2) * Math.Sin(latitudeDelta / 2) +
                Math.Cos(latitude1) * Math.Cos(latitude2) *
                Math.Sin(longitudeDelta / 2) * Math.Sin(longitudeDelta / 2);
        return earthRadiusKilometers * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }
}

public enum MapGeometryType
{
    Point,
    LineString,
    Polygon
}

public sealed class MapFeature
{
    public required MapGeometryType GeometryType { get; init; }
    public required IReadOnlyList<IReadOnlyList<GeoCoordinate>> Parts { get; init; }
    public IReadOnlyDictionary<string, string> Properties { get; init; } =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
}

public sealed class MapLayerDescriptor
{
    public required string Id { get; init; }
    public required string DisplayName { get; init; }
    public required string File { get; init; }
    public required string Format { get; init; }
    public required string Style { get; init; }
    public bool Required { get; init; }
    public required string AttributionId { get; init; }
}

public sealed class MapSourceAttribution
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Url { get; init; }
    public required string License { get; init; }
}

public sealed class MapManifest
{
    public required string Name { get; init; }
    public required string Version { get; init; }
    public required string AsOf { get; init; }
    public required string CoordinateReferenceSystem { get; init; }
    public required GeoBounds Bounds { get; init; }
    public required string DataBoundary { get; init; }
    public required List<MapSourceAttribution> Attributions { get; init; }
    public required List<MapLayerDescriptor> Layers { get; init; }
}

public sealed class TheaterMapPackage
{
    public required MapManifest Manifest { get; init; }
    public required IReadOnlyDictionary<string, IReadOnlyList<MapFeature>> Layers { get; init; }
    public required IReadOnlyList<string> MissingOptionalLayers { get; init; }
    public int FeatureCount => Layers.Values.Sum(layer => layer.Count);
}
