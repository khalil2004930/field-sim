using System.Text.Json.Serialization;
using FieldSim.Core;

namespace FieldSim.Domain;

public enum OrbatAffiliation
{
    Blue,
    Red,
    Neutral
}

public enum OrbatEchelon
{
    Side,
    Command,
    Division,
    Brigade,
    Battalion,
    Company,
    Platoon,
    Squad,
    Team,
    Cell,
    SupportElement
}

public enum OrbatRole
{
    Headquarters,
    Infantry,
    Armored,
    Mechanized,
    Reconnaissance,
    AntiArmor,
    SniperMarksman,
    Engineer,
    Fires,
    Uav,
    Fpv,
    Intelligence,
    Signals,
    Logistics,
    Medical,
    Mixed,
    Reserve
}

public enum OrbatReadiness
{
    Ready,
    Moving,
    Engaged,
    Suppressed,
    Degraded,
    Disconnected,
    Reserve,
    Destroyed
}

public sealed class OrbatNodeRecord
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public string? ShortName { get; init; }
    public required OrbatAffiliation Affiliation { get; init; }
    public required OrbatEchelon Echelon { get; init; }
    public required OrbatRole Role { get; init; }
    public string? ParentId { get; init; }
    public int? AuthorizedPersonnel { get; init; }
    public int? CurrentPersonnel { get; set; }
    public int ReadinessPercent { get; set; } = 100;
    public int MoralePercent { get; set; } = 80;
    public int AmmoPercent { get; set; } = 100;
    public string Communications { get; set; } = "Connected";
    public string CurrentOrder { get; set; } = "Hold";
    public OrbatReadiness Status { get; set; } = OrbatReadiness.Ready;
    public List<string> Notes { get; init; } = [];
    public bool SyntheticScenarioElement { get; init; } = true;

    [JsonIgnore]
    public string DisplayName => string.IsNullOrWhiteSpace(ShortName) ? Name : $"{ShortName} — {Name}";

    [JsonIgnore]
    public string EchelonLabel => Echelon switch
    {
        OrbatEchelon.Division => "DIV",
        OrbatEchelon.Brigade => "BDE",
        OrbatEchelon.Battalion => "BN",
        OrbatEchelon.Company => "CO",
        OrbatEchelon.Platoon => "PLT",
        OrbatEchelon.Squad => "SQD",
        OrbatEchelon.Team => "TM",
        OrbatEchelon.Cell => "CELL",
        OrbatEchelon.SupportElement => "SUP",
        OrbatEchelon.Command => "HQ",
        _ => "SIDE"
    };

    [JsonIgnore]
    public string RoleLabel => Role switch
    {
        OrbatRole.Headquarters => "HQ",
        OrbatRole.Infantry => "INF",
        OrbatRole.Armored => "AR",
        OrbatRole.Mechanized => "MECH",
        OrbatRole.Reconnaissance => "RECON",
        OrbatRole.AntiArmor => "AT",
        OrbatRole.SniperMarksman => "SNPR",
        OrbatRole.Engineer => "ENG",
        OrbatRole.Fires => "FIRE",
        OrbatRole.Uav => "UAV",
        OrbatRole.Fpv => "FPV",
        OrbatRole.Intelligence => "INTEL",
        OrbatRole.Signals => "SIG",
        OrbatRole.Logistics => "LOG",
        OrbatRole.Medical => "MED",
        OrbatRole.Reserve => "RES",
        _ => "MIX"
    };
}

public sealed class ScenarioOrbatDataset
{
    public required string ScenarioName { get; init; }
    public required string BlueRootId { get; init; }
    public required string RedRootId { get; init; }
    public required string DataBoundary { get; init; }
    public required List<OrbatNodeRecord> Nodes { get; init; }

    [JsonIgnore]
    private Dictionary<string, OrbatNodeRecord>? _nodesById;
    [JsonIgnore]
    private Dictionary<string, List<OrbatNodeRecord>>? _childrenByParentId;

    public void BuildIndexes()
    {
        _nodesById = Nodes.ToDictionary(node => node.Id, StringComparer.Ordinal);
        _childrenByParentId = Nodes
            .Where(node => node.ParentId is not null)
            .GroupBy(node => node.ParentId!, StringComparer.Ordinal)
            .ToDictionary(group => group.Key, group => group.ToList(), StringComparer.Ordinal);
    }

    private void EnsureIndexes()
    {
        if (_nodesById is null || _childrenByParentId is null || _nodesById.Count != Nodes.Count)
            BuildIndexes();
    }

    public OrbatNodeRecord? Find(string id)
    {
        EnsureIndexes();
        return _nodesById!.GetValueOrDefault(id);
    }

    public IReadOnlyList<OrbatNodeRecord> ChildrenOf(string parentId)
    {
        EnsureIndexes();
        return _childrenByParentId!.TryGetValue(parentId, out var children) ? children : [];
    }

    public IEnumerable<OrbatNodeRecord> DescendantsAndSelf(string id)
    {
        var root = Find(id);
        if (root is null) yield break;
        var queue = new Queue<OrbatNodeRecord>();
        queue.Enqueue(root);
        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            yield return current;
            foreach (var child in ChildrenOf(current.Id)) queue.Enqueue(child);
        }
    }

    public IReadOnlyList<string> AncestorIds(string id)
    {
        var result = new List<string>();
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var current = Find(id);
        while (current?.ParentId is { } parentId && seen.Add(parentId))
        {
            result.Add(parentId);
            current = Find(parentId);
        }
        return result;
    }

    public static IReadOnlyList<string> Validate(ScenarioOrbatDataset dataset)
    {
        var errors = new List<string>();
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var node in dataset.Nodes)
        {
            if (!ids.Add(node.Id)) errors.Add($"Duplicate ORBAT node '{node.Id}'.");
        }
        if (errors.Count > 0) return errors;

        dataset.BuildIndexes();
        if (dataset.Find(dataset.BlueRootId) is null) errors.Add("ORBAT blue root is missing.");
        if (dataset.Find(dataset.RedRootId) is null) errors.Add("ORBAT red root is missing.");

        foreach (var node in dataset.Nodes)
        {
            if (node.ParentId is not null && dataset.Find(node.ParentId) is null)
                errors.Add($"ORBAT node '{node.Id}' references missing parent '{node.ParentId}'.");
            if (node.ReadinessPercent is < 0 or > 100 || node.MoralePercent is < 0 or > 100 || node.AmmoPercent is < 0 or > 100)
                errors.Add($"ORBAT node '{node.Id}' has an out-of-range percentage.");
            if (node.AuthorizedPersonnel is { } authorized && node.CurrentPersonnel is { } current && current > authorized)
                errors.Add($"ORBAT node '{node.Id}' has current personnel above authorized personnel.");

            var seen = new HashSet<string>(StringComparer.Ordinal) { node.Id };
            var cursor = node;
            while (cursor.ParentId is { } parentId)
            {
                if (!seen.Add(parentId))
                {
                    errors.Add($"ORBAT cycle detected through '{node.Id}'.");
                    break;
                }
                var parent = dataset.Find(parentId);
                if (parent is null) break;
                if (parent.Affiliation != node.Affiliation)
                {
                    errors.Add($"ORBAT node '{node.Id}' changes affiliation under parent '{parent.Id}'.");
                    break;
                }
                cursor = parent;
            }
        }
        return errors.Distinct(StringComparer.Ordinal).ToArray();
    }
}

public sealed record FormationSpatialState(
    Position3D MeanPositionMeters,
    Position3D MedianPositionMeters,
    double DispersionRadiusMeters,
    double FrontageMeters,
    double DepthMeters,
    int EntityCount,
    int OutlierCount);

public static class FormationSpatialCalculator
{
    public static FormationSpatialState? Calculate(
        ScenarioOrbatDataset orbat,
        string nodeId,
        IReadOnlyDictionary<string, string> entityAssignments,
        IReadOnlyCollection<TacticalUnit> units,
        TacticalState state)
    {
        var all = CalculateAll(orbat, entityAssignments, units, state);
        return all.GetValueOrDefault(nodeId);
    }

    /// <summary>
    /// Aggregates every live entity into its assigned ORBAT node and all ancestors in one pass.
    /// This avoids rescanning all entities once for every visible ORBAT branch.
    /// </summary>
    public static IReadOnlyDictionary<string, FormationSpatialState> CalculateAll(
        ScenarioOrbatDataset orbat,
        IReadOnlyDictionary<string, string> entityAssignments,
        IReadOnlyCollection<TacticalUnit> units,
        TacticalState state)
    {
        ArgumentNullException.ThrowIfNull(orbat);
        ArgumentNullException.ThrowIfNull(entityAssignments);
        ArgumentNullException.ThrowIfNull(units);
        ArgumentNullException.ThrowIfNull(state);

        var positionsByNode = new Dictionary<string, List<Position3D>>(StringComparer.Ordinal);
        foreach (var unit in units)
        {
            if (!unit.Alive || string.IsNullOrWhiteSpace(unit.EntityKey) ||
                !entityAssignments.TryGetValue(unit.EntityKey, out var assignedNodeId) ||
                orbat.Find(assignedNodeId) is null)
                continue;

            Add(assignedNodeId, state.GroundPositionOf(unit));
            foreach (var ancestorId in orbat.AncestorIds(assignedNodeId))
                Add(ancestorId, state.GroundPositionOf(unit));
        }

        return positionsByNode.ToDictionary(
            pair => pair.Key,
            pair => BuildState(pair.Value),
            StringComparer.Ordinal);

        void Add(string nodeId, Position3D position)
        {
            if (!positionsByNode.TryGetValue(nodeId, out var positions))
            {
                positions = [];
                positionsByNode[nodeId] = positions;
            }
            positions.Add(position);
        }
    }

    private static FormationSpatialState BuildState(IReadOnlyList<Position3D> positions)
    {
        var meanX = positions.Average(position => position.X);
        var meanY = positions.Average(position => position.Y);
        var meanZ = positions.Average(position => position.Z);
        var xs = positions.Select(position => position.X).OrderBy(value => value).ToArray();
        var ys = positions.Select(position => position.Y).OrderBy(value => value).ToArray();
        var zs = positions.Select(position => position.Z).OrderBy(value => value).ToArray();
        var median = new Position3D(Median(xs), Median(ys), Median(zs));
        var distances = positions.Select(position => position.HorizontalDistanceTo(median)).OrderBy(value => value).ToArray();
        var radiusIndex = Math.Clamp((int)Math.Ceiling(distances.Length * 0.90) - 1, 0, distances.Length - 1);
        var radius = distances[radiusIndex];
        var outliers = distances.Count(value => value > Math.Max(radius * 1.75, radius + 20));

        return new FormationSpatialState(
            new Position3D(meanX, meanY, meanZ),
            median,
            radius,
            xs[^1] - xs[0],
            ys[^1] - ys[0],
            positions.Count,
            outliers);
    }

    private static double Median(IReadOnlyList<double> values)
    {
        if (values.Count == 0) return 0;
        var middle = values.Count / 2;
        return values.Count % 2 == 1
            ? values[middle]
            : (values[middle - 1] + values[middle]) * 0.5;
    }
}
