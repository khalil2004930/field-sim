using FieldSim.Core;

namespace FieldSim.Domain;

public enum VehicleKind
{
    MainBattleTank,
    HeavyApc,
    WheeledApc,
    InfantryFightingVehicle,
    EngineeringVehicle,
    SupportVehicle
}

public enum MobilityType
{
    Tracked,
    Wheeled4x4,
    Wheeled6x6,
    Wheeled8x8
}

public enum ProtectionDataMode
{
    SyntheticGameIndex
}

public enum ComponentStatus
{
    Operational,
    Degraded,
    Disabled,
    Destroyed
}

public sealed class VehicleSourceRecord
{
    public required string Id { get; init; }
    public required string Publisher { get; init; }
    public required string Title { get; init; }
    public required Uri Url { get; init; }
    public required string Boundary { get; init; }
}

public sealed class CrewDefinition
{
    public required int Crew { get; init; }
    public int Passengers { get; init; }
    public List<string> Roles { get; init; } = [];
}

public sealed class MobilityDefinition
{
    public required MobilityType Type { get; init; }
    public double? PublicMaximumRoadSpeedKph { get; init; }
    public double? PublicVehicleRangeKm { get; init; }
    public int? PublicEnginePowerHp { get; init; }
    public double? PublicFuelCapacityLiters { get; init; }
    public double GameCrossCountrySpeedFactor { get; init; } = 0.65;
}

public sealed class MainWeaponDefinition
{
    public required string Name { get; init; }
    public double? CaliberMm { get; init; }
    public int? PublicAmmunitionCapacity { get; init; }
    public int? PublicReadyRackCapacity { get; init; }
    public double? GameBaseReloadSeconds { get; init; }
    public required string ReloadBoundary { get; init; }
}

public sealed class OpticsChannelDefinition
{
    public required string Name { get; init; }
    public bool Day { get; init; }
    public bool Night { get; init; }
    public bool Thermal { get; init; }
    public bool Stabilized { get; init; }
    public double GameDetectionQuality { get; init; }
    public double GameIdentificationQuality { get; init; }
}

public sealed class OpticsSuiteDefinition
{
    public required OpticsChannelDefinition Commander { get; init; }
    public required OpticsChannelDefinition Gunner { get; init; }
    public required OpticsChannelDefinition Driver { get; init; }
    public bool LaserRangefinder { get; init; }
    public bool PanoramicAwareness { get; init; }
    public bool HelmetMountedSituationalAwareness { get; init; }
    public double GameSituationalAwareness { get; init; }
}

public sealed class ArmorZoneDefinition
{
    public required string Zone { get; init; }
    public required int SyntheticKineticIndex { get; init; }
    public required int SyntheticChemicalIndex { get; init; }
    public bool Composite { get; init; }
    public bool Reactive { get; init; }
}

public sealed class ProtectionProfile
{
    public required ProtectionDataMode Mode { get; init; }
    public required string ScaleDescription { get; init; }
    public required List<ArmorZoneDefinition> Zones { get; init; }
}

public sealed class ApsDefinition
{
    public required string Name { get; init; }
    public bool Installed { get; init; }
    public bool DefaultPoweredOn { get; init; }
    public required string PublicCoverageDescription { get; init; }
    public int GameCountermeasureBudget { get; init; }
    public required string CountermeasureBoundary { get; init; }
}

public sealed class ReliabilityProfile
{
    public double GameEngineReliability { get; init; }
    public double GameMobilityReliability { get; init; }
    public double GameSensorReliability { get; init; }
    public double GameElectronicsReliability { get; init; }
}

public sealed class VehicleSignatureDefinition
{
    public double Visual { get; init; }
    public double Thermal { get; init; }
    public double Radar { get; init; }
    public double Acoustic { get; init; }
    public required string Boundary { get; init; }

    public SignatureProfile ToCore() => new SignatureProfile(Visual, Thermal, Radar, Acoustic).Clamp();
}

public sealed class VehicleDefinition
{
    public required string Id { get; init; }
    public required string Family { get; init; }
    public required string Variant { get; init; }
    public required VehicleKind Kind { get; init; }
    public required string PublicStatus { get; init; }
    public required Bounds3D Dimensions { get; init; }
    public double? PublicMassTonnes { get; init; }
    public required CrewDefinition Crew { get; init; }
    public required MobilityDefinition Mobility { get; init; }
    public MainWeaponDefinition? MainWeapon { get; init; }
    public required OpticsSuiteDefinition Optics { get; init; }
    public required ProtectionProfile Protection { get; init; }
    public ApsDefinition? ActiveProtection { get; init; }
    public required ReliabilityProfile Reliability { get; init; }
    public required VehicleSignatureDefinition Signature { get; init; }
    public required List<string> DamageComponents { get; init; }
    public required List<string> SourceIds { get; init; }
    public required string DataBoundary { get; init; }

    public string DisplayName => $"{Family} {Variant}".Trim();
}

public sealed class VehicleDataset
{
    public required string DatasetName { get; init; }
    public required List<VehicleSourceRecord> Sources { get; init; }
    public required List<VehicleDefinition> Vehicles { get; init; }
    public required string DataBoundary { get; init; }

    public VehicleDefinition? Find(string id) => Vehicles.FirstOrDefault(vehicle =>
        string.Equals(vehicle.Id, id, StringComparison.Ordinal));
}

public sealed class ComponentHealth
{
    public required string Name { get; init; }
    public double Integrity { get; set; } = 1;
    public ComponentStatus Status => Integrity switch
    {
        <= 0 => ComponentStatus.Destroyed,
        < 0.25 => ComponentStatus.Disabled,
        < 0.70 => ComponentStatus.Degraded,
        _ => ComponentStatus.Operational
    };
}

public sealed class CrewMemberState
{
    public required string Role { get; init; }
    public double Vitality { get; set; } = 1;
    public double Fatigue { get; set; }
    public double Experience { get; set; } = 0.5;
    public bool AbleToOperate => Vitality > 0.25;
}

public sealed class FuelState
{
    public double? PublicCapacityLiters { get; init; }
    public double RemainingFraction { get; set; } = 1;
    public double GameIdleConsumptionFactor { get; set; } = 0.18;
    public double GameRoadConsumptionFactor { get; set; } = 1.0;
    public double GameCrossCountryConsumptionFactor { get; set; } = 1.35;
}

public sealed class AmmunitionState
{
    public int TotalCapacity { get; init; }
    public int Remaining { get; set; }
    public int ReadyRackCapacity { get; init; }
    public int ReadyRackRemaining { get; set; }
}

public sealed class ArmorZoneState
{
    public required ArmorZoneDefinition Definition { get; init; }
    public double Integrity { get; set; } = 1;
    public bool Breached { get; set; }
}

public sealed class ApsSectorState
{
    public required string Name { get; init; }
    public double Integrity { get; set; } = 1;
    public bool SensorOperational { get; set; } = true;
    public bool CountermeasureModuleOperational { get; set; } = true;
}

public sealed class VehicleOperationalState
{
    public bool EngineOn { get; set; }
    public bool OnFire { get; set; }
    public bool SmokeDeployed { get; set; }
    public double Suppression { get; set; }
    public double CrewMorale { get; set; } = 1;
}

public abstract class SimEntityState
{
    protected SimEntityState(string entityId, TacticalFaction faction, Position3D position)
    {
        EntityId = entityId;
        Faction = faction;
        Position = position;
    }

    public string EntityId { get; }
    public TacticalFaction Faction { get; }
    public Position3D Position { get; set; }
    public Orientation3D Orientation { get; set; } = Orientation3D.Zero;
}

public abstract class VehicleEntityState : SimEntityState
{
    protected VehicleEntityState(
        string entityId,
        TacticalFaction faction,
        Position3D position,
        VehicleDefinition definition)
        : base(entityId, faction, position)
    {
        Definition = definition;
        Components = definition.DamageComponents
            .Distinct(StringComparer.Ordinal)
            .ToDictionary(name => name, name => new ComponentHealth { Name = name }, StringComparer.Ordinal);
        Crew = definition.Crew.Roles
            .Take(definition.Crew.Crew)
            .Select(role => new CrewMemberState { Role = role })
            .ToList();
        while (Crew.Count < definition.Crew.Crew)
        {
            Crew.Add(new CrewMemberState { Role = $"crew-{Crew.Count + 1}" });
        }
        Fuel = new FuelState { PublicCapacityLiters = definition.Mobility.PublicFuelCapacityLiters };
        ArmorZones = definition.Protection.Zones.ToDictionary(
            zone => zone.Zone,
            zone => new ArmorZoneState { Definition = zone },
            StringComparer.Ordinal);
    }

    public VehicleDefinition Definition { get; }
    public FuelState Fuel { get; }
    public List<CrewMemberState> Crew { get; }
    public Dictionary<string, ArmorZoneState> ArmorZones { get; }
    public VehicleOperationalState Operational { get; } = new();
    public double FuelFraction
    {
        get => Fuel.RemainingFraction;
        set => Fuel.RemainingFraction = Math.Clamp(value, 0, 1);
    }
    public int MainGunAmmunition { get; set; }
    public bool EngineOn
    {
        get => Operational.EngineOn;
        set => Operational.EngineOn = value;
    }
    public Dictionary<string, ComponentHealth> Components { get; }
    public double OverallIntegrity => Components.Count == 0
        ? 1
        : Components.Values.Average(component => component.Integrity);
}

public abstract class GroundVehicleEntityState : VehicleEntityState
{
    protected GroundVehicleEntityState(
        string entityId,
        TacticalFaction faction,
        Position3D position,
        VehicleDefinition definition)
        : base(entityId, faction, position, definition) { }
}

public abstract class ArmoredVehicleEntityState : GroundVehicleEntityState
{
    protected ArmoredVehicleEntityState(
        string entityId,
        TacticalFaction faction,
        Position3D position,
        VehicleDefinition definition)
        : base(entityId, faction, position, definition) { }

    public bool ApsPoweredOn { get; set; }
    public int ApsGameBudgetRemaining { get; set; }
    public List<ApsSectorState> ApsSectors { get; } =
    [
        new() { Name = "front" },
        new() { Name = "right" },
        new() { Name = "rear" },
        new() { Name = "left" }
    ];
}

public sealed class TankEntityState : ArmoredVehicleEntityState
{
    public TankEntityState(
        string entityId,
        TacticalFaction faction,
        Position3D position,
        VehicleDefinition definition)
        : base(entityId, faction, position, definition)
    {
        if (definition.Kind != VehicleKind.MainBattleTank)
            throw new ArgumentException("TankEntityState requires a main battle tank definition.", nameof(definition));
        MainGunAmmunition = definition.MainWeapon?.PublicAmmunitionCapacity ?? 0;
        Ammunition = new AmmunitionState
        {
            TotalCapacity = MainGunAmmunition,
            Remaining = MainGunAmmunition,
            ReadyRackCapacity = definition.MainWeapon?.PublicReadyRackCapacity ?? 0,
            ReadyRackRemaining = definition.MainWeapon?.PublicReadyRackCapacity ?? 0
        };
        ApsPoweredOn = definition.ActiveProtection?.DefaultPoweredOn ?? false;
        ApsGameBudgetRemaining = definition.ActiveProtection?.GameCountermeasureBudget ?? 0;
    }

    public AmmunitionState Ammunition { get; }
}

public sealed class ApcEntityState : ArmoredVehicleEntityState
{
    public ApcEntityState(
        string entityId,
        TacticalFaction faction,
        Position3D position,
        VehicleDefinition definition)
        : base(entityId, faction, position, definition)
    {
        if (definition.Kind is not VehicleKind.HeavyApc and not VehicleKind.WheeledApc and not VehicleKind.InfantryFightingVehicle)
            throw new ArgumentException("ApcEntityState requires an APC/IFV definition.", nameof(definition));
        ApsPoweredOn = definition.ActiveProtection?.DefaultPoweredOn ?? false;
        ApsGameBudgetRemaining = definition.ActiveProtection?.GameCountermeasureBudget ?? 0;
    }
}

public static class VehicleDatasetValidator
{
    public static IReadOnlyList<string> Validate(VehicleDataset dataset)
    {
        var errors = new List<string>();
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var vehicle in dataset.Vehicles)
        {
            if (!ids.Add(vehicle.Id)) errors.Add($"Duplicate vehicle id '{vehicle.Id}'.");
            if (vehicle.Crew.Crew <= 0) errors.Add($"Vehicle '{vehicle.Id}' has invalid crew count.");
            if (vehicle.Dimensions.LengthMeters <= 0 || vehicle.Dimensions.WidthMeters <= 0 || vehicle.Dimensions.HeightMeters <= 0)
                errors.Add($"Vehicle '{vehicle.Id}' has invalid dimensions.");
            if (vehicle.Protection.Mode != ProtectionDataMode.SyntheticGameIndex)
                errors.Add($"Vehicle '{vehicle.Id}' uses an unsupported protection data mode.");
            foreach (var zone in vehicle.Protection.Zones)
            {
                if (zone.SyntheticKineticIndex is < 0 or > 1000 || zone.SyntheticChemicalIndex is < 0 or > 1000)
                    errors.Add($"Vehicle '{vehicle.Id}' has a protection index outside 0-1000.");
            }
            if (vehicle.Signature.Visual is < 0 or > 1 || vehicle.Signature.Thermal is < 0 or > 1 ||
                vehicle.Signature.Radar is < 0 or > 1 || vehicle.Signature.Acoustic is < 0 or > 1)
            {
                errors.Add($"Vehicle '{vehicle.Id}' has a signature outside 0-1.");
            }
            foreach (var sourceId in vehicle.SourceIds)
            {
                if (dataset.Sources.All(source => source.Id != sourceId))
                    errors.Add($"Vehicle '{vehicle.Id}' references missing source '{sourceId}'.");
            }
        }
        return errors;
    }
}
