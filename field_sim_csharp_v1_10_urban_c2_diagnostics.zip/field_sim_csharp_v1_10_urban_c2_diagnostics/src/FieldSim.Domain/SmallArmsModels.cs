using System.Text.Json.Serialization;

namespace FieldSim.Domain;

public sealed class SmallArmsOsintDatabase
{
    public required string DatabaseName { get; init; }
    public required string Version { get; init; }
    public string? Supersedes { get; init; }
    public required string Scope { get; init; }
    public required List<SmallArmOsintRecord> Weapons { get; init; }
    public List<string> RecommendedInitialCaliberFamilies { get; init; } = [];
}

public sealed class SmallArmOsintRecord
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string Family { get; init; }
    public required string OriginCountry { get; init; }
    public required string Manufacturer { get; init; }
    public required string WeaponClass { get; init; }
    public required string Caliber { get; init; }
    public required string Action { get; init; }
    public required string Feed { get; init; }
    public required string BroadSimulationRole { get; init; }
    public required string EvidenceGrade { get; init; }
    public required string Confidence { get; init; }
    public bool DirectWarNoirHezbollahEvidence { get; init; }
    public List<string> EvidenceContexts { get; init; } = [];
    public List<string> SourceIds { get; init; } = [];
    public string? AmbiguityOrAlternateId { get; init; }
    public required string DatasetStatus { get; init; }
    public required string FieldSimIntegrationNote { get; init; }
    public List<string> AttachmentsSeen { get; init; } = [];

    [JsonIgnore]
    public bool IsDirectEvidence => DirectWarNoirHezbollahEvidence;

    [JsonIgnore]
    public bool IsProvisional => string.Equals(DatasetStatus, "provisional", StringComparison.OrdinalIgnoreCase);
}

public enum EquipmentAvailabilityClass
{
    Common,
    Available,
    Uncommon,
    Specialist,
    Provisional
}

public sealed record FactionSmallArmAvailability(
    string FactionId,
    string WeaponId,
    EquipmentAvailabilityClass Availability,
    string EvidenceGrade,
    string Basis);
