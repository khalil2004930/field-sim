using System.Text.Json.Serialization;

namespace FieldSim.Domain;

public enum WeaponCategory
{
    Rocket,
    Missile,
    CruiseMissile,
    FixedWingDrone,
    FpvDrone,
    Mortar,
    AntiTankGuidedMissile,
    Gun
}

public enum GuidanceType
{
    None,
    Unknown,
    Inertial,
    SatelliteAided,
    RadioCommand,
    FiberOpticCommand,
    WireCommand,
    LaserBeamRiding,
    ElectroOptical,
    RadarHoming
}

public enum AccuracyMeasure
{
    Unknown,
    CircularErrorProbable,
    ImpactArea,
    OperatorDependent,
    NotApplicable
}

public enum BurdenLevel
{
    Unknown,
    Low,
    Moderate,
    High,
    VeryHigh
}

public enum SensitivityLevel
{
    Unknown,
    Low,
    Moderate,
    High,
    VeryHigh
}

public enum EvidenceStatus
{
    ConfirmedHistoricalUse,
    CorroboratedReporting,
    SingleSourceReporting,
    BroadCategoryOnly,
    Unconfirmed
}

public enum WeaponSourceKind
{
    Government,
    Intergovernmental,
    ResearchInstitution,
    NewsOrganization,
    AdvocacyOrganization,
    BelligerentStatement,
    SocialMedia,
    ProductCatalog
}

public enum CandidateReviewStatus
{
    AmbiguousDesignation,
    NeedsCorroboration,
    ProductOnlyNoFactionEvidence,
    VariantNotResolved
}

public sealed class WeaponSourceRecord
{
    public required string Id { get; init; }
    public required string Publisher { get; init; }
    public required DateOnly PublishedDate { get; init; }
    public required string Title { get; init; }
    public required Uri Url { get; init; }
    public required WeaponSourceKind Kind { get; init; }
    public required int ReliabilityPercent { get; init; }
    public required string Caveat { get; init; }
}

public sealed class PublicRange
{
    public double? MinimumKm { get; set; }
    public double? MaximumKm { get; set; }
    public required string Basis { get; init; }

    [JsonIgnore]
    public bool IsUnknown => MinimumKm is null && MaximumKm is null;
}

public sealed class AccuracyProfile
{
    public required AccuracyMeasure Measure { get; set; }
    public double? CepMeters { get; set; }
    public double? DispersionMajorMeters { get; set; }
    public double? DispersionMinorMeters { get; set; }
    public required int ConfidencePercent { get; set; }
    public required string Basis { get; set; }
}

public sealed class OperatorProfile
{
    public int? CrewMinimum { get; set; }
    public int? CrewMaximum { get; set; }
    public required BurdenLevel TrainingBurden { get; set; }
    public required BurdenLevel SetupBurden { get; set; }
    public required BurdenLevel LogisticsBurden { get; set; }
    public bool? RequiresLineOfSight { get; set; }
    public bool? RequiresContinuousGuidance { get; set; }
    public required string Basis { get; set; }
}

public sealed class WeatherSensitivityProfile
{
    public required SensitivityLevel Wind { get; set; }
    public required SensitivityLevel Precipitation { get; set; }
    public required SensitivityLevel Visibility { get; set; }
    public required SensitivityLevel Temperature { get; set; }
    public required SensitivityLevel NavigationInterference { get; set; }
    public required string Basis { get; set; }
}

[JsonPolymorphic(TypeDiscriminatorPropertyName = "$type")]
[JsonDerivedType(typeof(RocketSystem), "rocket")]
[JsonDerivedType(typeof(MissileSystem), "missile")]
[JsonDerivedType(typeof(CruiseMissileSystem), "cruiseMissile")]
[JsonDerivedType(typeof(FixedWingDroneSystem), "fixedWingDrone")]
[JsonDerivedType(typeof(FpvDroneSystem), "fpvDrone")]
[JsonDerivedType(typeof(MortarSystem), "mortar")]
[JsonDerivedType(typeof(AtgmSystem), "atgm")]
[JsonDerivedType(typeof(GunSystem), "gun")]
public abstract class WeaponSystem
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public List<string> Aliases { get; init; } = [];
    public string? Family { get; init; }
    public abstract WeaponCategory Category { get; }
    public required string Role { get; init; }
    public required string PublicStatus { get; init; }
    public required EvidenceStatus EvidenceStatus { get; init; }
    public required int EvidenceConfidencePercent { get; init; }
    public required List<string> SourceIds { get; init; }
    public required QuantityRange Quantity { get; init; }
    public required PublicRange Range { get; init; }
    public required List<GuidanceType> Guidance { get; init; }
    public required AccuracyProfile Accuracy { get; init; }
    public required OperatorProfile Operator { get; init; }
    public required WeatherSensitivityProfile Weather { get; init; }
    public double? PayloadKg { get; set; }
    public int? BaselineReliabilityPercent { get; set; }
    public required List<string> PublicNotes { get; init; }
    public required string DataBoundary { get; init; }

    [JsonIgnore]
    public int OverrideCount { get; set; }
}

public sealed class RocketSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.Rocket;
    public required string LauncherClass { get; init; }
}

public sealed class MissileSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.Missile;
    public required string MobilityClass { get; init; }
}

public sealed class CruiseMissileSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.CruiseMissile;
    public required string LaunchDomain { get; init; }
}

public sealed class FixedWingDroneSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.FixedWingDrone;
    public double? PublicEnduranceHours { get; set; }
    public double? PublicCeilingFeet { get; set; }
    public required string MissionProfile { get; init; }
}

public sealed class FpvDroneSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.FpvDrone;
    public required string ControlLink { get; init; }
}

public sealed class MortarSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.Mortar;
    public int? CaliberMm { get; set; }
}

public sealed class AtgmSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.AntiTankGuidedMissile;
    public required string WarheadClass { get; init; }
}

public sealed class GunSystem : WeaponSystem
{
    [JsonIgnore]
    public override WeaponCategory Category => WeaponCategory.Gun;
    public double? CaliberMm { get; set; }
    public required string GunClass { get; init; }
}

public sealed class WeaponCandidateRecord
{
    public required string Id { get; init; }
    public required string Designation { get; init; }
    public required WeaponCategory ProposedCategory { get; init; }
    public required CandidateReviewStatus Status { get; init; }
    public required string Reason { get; init; }
    public string? PublicSpecificationSummary { get; init; }
    public List<string> Aliases { get; init; } = [];
    public List<string> SourceIds { get; init; } = [];
}

public sealed class WeaponDataset
{
    public required List<WeaponSourceRecord> Sources { get; init; }
    public required List<WeaponSystem> Weapons { get; init; }
    public required List<WeaponCandidateRecord> ResearchQueue { get; init; }
    public int TotalOverrides { get; set; }

    public WeaponSystem? FindWeapon(string id) => Weapons.FirstOrDefault(weapon =>
        string.Equals(weapon.Id, id, StringComparison.Ordinal));

    public WeaponSourceRecord? FindSource(string id) => Sources.FirstOrDefault(source =>
        string.Equals(source.Id, id, StringComparison.Ordinal));
}

public sealed class WeaponManualOverride
{
    public required string WeaponId { get; init; }
    public double? MinimumRangeKm { get; init; }
    public double? MaximumRangeKm { get; init; }
    public double? CepMeters { get; init; }
    public int? BaselineReliabilityPercent { get; init; }
    public BurdenLevel? TrainingBurden { get; init; }
    public BurdenLevel? SetupBurden { get; init; }
    public BurdenLevel? LogisticsBurden { get; init; }
    public SensitivityLevel? WindSensitivity { get; init; }
    public SensitivityLevel? PrecipitationSensitivity { get; init; }
    public SensitivityLevel? VisibilitySensitivity { get; init; }
    public SensitivityLevel? TemperatureSensitivity { get; init; }
    public SensitivityLevel? NavigationInterferenceSensitivity { get; init; }
}

public sealed record WeatherCondition(
    double WindMetersPerSecond,
    double PrecipitationMillimetersPerHour,
    double VisibilityKilometers,
    double TemperatureCelsius,
    bool NavigationInterference);

public sealed record WeatherAssessment(
    SensitivityLevel OverallSensitivity,
    bool NumericRangeAdjustmentAvailable,
    double? AdjustedMinimumRangeKm,
    double? AdjustedMaximumRangeKm,
    string Explanation);
