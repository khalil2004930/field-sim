namespace FieldSim.Domain;

public enum UnitLevel
{
    ArmedForces,
    Headquarters,
    RegionalCommand,
    Corps,
    Division,
    Brigade,
    Battalion,
    Company,
    Platoon,
    Section
}

public enum FormationType
{
    Headquarters,
    GroundForces,
    RegionalCommand,
    Infantry,
    Armored,
    Paratrooper,
    Commando,
    Artillery,
    CombatEngineer,
    Territorial,
    Reconnaissance,
    Intelligence,
    Logistics,
    Signals,
    Training,
    Mixed
}

public enum ServiceStatus
{
    Active,
    Reserve,
    Territorial,
    Training,
    Administrative
}

public sealed class FormationSourceRecord
{
    public required string Id { get; init; }
    public required string Publisher { get; init; }
    public required string Title { get; init; }
    public required Uri Url { get; init; }
    public DateOnly? PublishedDate { get; init; }
    public required string Boundary { get; init; }
}

public sealed class FormationRecord
{
    public required string Id { get; init; }
    public int? Number { get; init; }
    public required string Name { get; init; }
    public string? Nickname { get; init; }
    public required UnitLevel Level { get; init; }
    public required FormationType Type { get; init; }
    public required ServiceStatus Status { get; init; }
    public string? ParentId { get; init; }
    public List<string> SourceIds { get; init; } = [];
    public List<string> Notes { get; init; } = [];

    public string DisplayName => Number is null
        ? Name
        : $"{Number}{OrdinalSuffix(Number.Value)} {Name}";

    private static string OrdinalSuffix(int number)
    {
        var absolute = Math.Abs(number);
        if (absolute % 100 is >= 11 and <= 13) return "th";
        return (absolute % 10) switch
        {
            1 => "st",
            2 => "nd",
            3 => "rd",
            _ => "th"
        };
    }
}

public sealed class FormationDataset
{
    public required string DatasetName { get; init; }
    public required string AsOf { get; init; }
    public required string RootId { get; init; }
    public required List<FormationSourceRecord> Sources { get; init; }
    public required List<FormationRecord> Formations { get; init; }
    public required string DataBoundary { get; init; }

    public FormationRecord? Find(string id) => Formations.FirstOrDefault(item =>
        string.Equals(item.Id, id, StringComparison.Ordinal));

    public IEnumerable<FormationRecord> ChildrenOf(string parentId) =>
        Formations.Where(item => string.Equals(item.ParentId, parentId, StringComparison.Ordinal));

    public int DescendantCount(string id)
    {
        var total = 0;
        var queue = new Queue<string>();
        queue.Enqueue(id);
        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            foreach (var child in ChildrenOf(current))
            {
                total++;
                queue.Enqueue(child.Id);
            }
        }
        return total;
    }
}

public static class FormationDatasetValidator
{
    public static IReadOnlyList<string> Validate(FormationDataset dataset)
    {
        var errors = new List<string>();
        if (dataset.Formations.Count == 0) errors.Add("Formation dataset is empty.");
        if (dataset.Find(dataset.RootId) is null) errors.Add("Formation root does not exist.");

        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var formation in dataset.Formations)
        {
            if (!ids.Add(formation.Id)) errors.Add($"Duplicate formation id '{formation.Id}'.");
            if (formation.ParentId is not null && dataset.Find(formation.ParentId) is null)
                errors.Add($"Formation '{formation.Id}' references missing parent '{formation.ParentId}'.");
            foreach (var sourceId in formation.SourceIds)
            {
                if (dataset.Sources.All(source => source.Id != sourceId))
                    errors.Add($"Formation '{formation.Id}' references missing source '{sourceId}'.");
            }
        }

        foreach (var formation in dataset.Formations)
        {
            var visited = new HashSet<string>(StringComparer.Ordinal) { formation.Id };
            var current = formation;
            while (current.ParentId is not null)
            {
                if (!visited.Add(current.ParentId))
                {
                    errors.Add($"Formation cycle detected from '{formation.Id}'.");
                    break;
                }
                var parent = dataset.Find(current.ParentId);
                if (parent is null) break;
                current = parent;
            }
        }

        return errors;
    }
}
