namespace FieldSim.Domain;

public sealed class ScenarioPackage
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required string OrbatFile { get; init; }
    public required string VillageId { get; init; }
    public required string DataBoundary { get; init; }
    public required uint RandomSeed { get; init; }
    public required ScenarioDisplayMap DisplayMap { get; init; }
    public required List<ScenarioEntityAssignment> EntityAssignments { get; init; }

    // v1.9.3: optional country-scale scenario authoring data. Older packages do not need these.
    public string ScenarioMode { get; init; } = "sandbox";
    public List<ScenarioGeoAnchor> GeoAnchors { get; init; } = [];
    public List<ScenarioPlacementZone> PlacementZones { get; init; } = [];
    public List<ScenarioObjectiveDefinition> Objectives { get; init; } = [];
    public List<ScenarioSupportPlacement> SupportPlacements { get; init; } = [];
}

public sealed class ScenarioDisplayMap
{
    public string Mode { get; init; } = "public-basemap-display-projection";
    public double CenterLatitude { get; init; }
    public double CenterLongitude { get; init; }
    public double TheaterWidthMeters { get; init; }
    public double TheaterHeightMeters { get; init; }
    public double InitialZoom { get; init; } = 8.0;
    public string Notice { get; init; } = "Display-only geographic reference; continuous synthetic XYZ is authoritative for simulation.";
}

/// <summary>
/// A public geographic reference used only to anchor a fictionalized/synthetic scenario layout.
/// It is not an operational deployment record.
/// </summary>
public sealed class ScenarioGeoAnchor
{
    public required string Id { get; init; }
    public required string DisplayName { get; init; }
    public double Latitude { get; init; }
    public double Longitude { get; init; }
    public string DataBoundary { get; init; } = "Public place-name anchor only; subordinate placements are synthetic.";
}

/// <summary>
/// A synthetic scenario-authoring zone positioned by an offset from a public geo anchor.
/// Radius is a validation/authoring envelope, not a tactical weapon or sensor radius.
/// </summary>
public sealed class ScenarioPlacementZone
{
    public required string Id { get; init; }
    public required string DisplayName { get; init; }
    public required string AnchorId { get; init; }
    public double OffsetEastMeters { get; init; }
    public double OffsetNorthMeters { get; init; }
    public double RadiusMeters { get; init; } = 500;
    public string? Faction { get; init; }
    public string Purpose { get; init; } = "scenario placement";
}

public sealed class ScenarioEntityAssignment
{
    public required string EntityKey { get; init; }
    public required string OrbatNodeId { get; init; }
    public string? WeaponId { get; init; }
    public ScenarioInitialPlacement? InitialPlacement { get; init; }
    public string? Notes { get; init; }
}

public sealed class ScenarioInitialPlacement
{
    // Legacy absolute local-meter placement. Still supported for older scenario packages.
    public double XMeters { get; init; }
    public double YMeters { get; init; }

    // v1.9.3 preferred authoring path: resolve the named synthetic zone, then apply these offsets.
    public string? ZoneId { get; init; }
    public double OffsetEastMeters { get; init; }
    public double OffsetNorthMeters { get; init; }
    public double HeadingDegrees { get; init; }
}

public sealed class ScenarioObjectiveDefinition
{
    public required string Id { get; init; }
    public required string DisplayName { get; init; }
    public required string ZoneId { get; init; }
    public double OffsetEastMeters { get; init; }
    public double OffsetNorthMeters { get; init; }
    public double CaptureRadiusMeters { get; init; } = 100;
    public int RequiredControlSeconds { get; init; } = 60;
}

public sealed class ScenarioSupportPlacement
{
    public required string AssetId { get; init; }
    public required string ZoneId { get; init; }
    public double OffsetEastMeters { get; init; }
    public double OffsetNorthMeters { get; init; }
    public double AltitudeMeters { get; init; }
    public double HeadingDegrees { get; init; }
}

public enum FormationRelationshipType
{
    Organic,
    Attached,
    Detached,
    OperationalControl,
    Support,
    Reserve
}

public sealed record FormationRelationship(
    string SourceFormationId,
    string TargetFormationId,
    FormationRelationshipType Type,
    string Basis);
