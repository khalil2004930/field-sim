namespace FieldSim.Domain;

public static class ForceDatasetValidator
{
    public static IReadOnlyList<string> Validate(ForceDataset dataset)
    {
        var errors = new List<string>();
        CheckDuplicates(dataset.Sources.Select(source => source.Id), "source", errors);
        CheckDuplicates(dataset.Platforms.Select(platform => platform.Id), "platform", errors);

        foreach (var platform in dataset.Platforms)
        {
            if (dataset.FindSource(platform.SourceId) is null)
            {
                errors.Add($"{platform.Id}: missing source '{platform.SourceId}'.");
            }

            ValidateQuantity(platform, errors);
            ValidatePercent(platform.Id, nameof(platform.ConfidencePercent), platform.ConfidencePercent, false, errors);
            ValidatePercent(platform.Id, nameof(platform.ReadinessPercent), platform.ReadinessPercent, true, errors);
            ValidatePercent(platform.Id, nameof(platform.SustainmentIndex), platform.SustainmentIndex, true, errors);
            ValidatePercent(platform.Id, nameof(platform.ProtectionIndex), platform.ProtectionIndex, true, errors);
            ValidatePercent(platform.Id, nameof(platform.MobilityIndex), platform.MobilityIndex, true, errors);
            ValidatePercent(platform.Id, nameof(platform.ApsCoveragePercent), platform.ApsCoveragePercent, true, errors);

            if (platform.EnduranceHours is < 0)
            {
                errors.Add($"{platform.Id}: endurance cannot be negative.");
            }
            if (platform.CeilingFeet is < 0)
            {
                errors.Add($"{platform.Id}: ceiling cannot be negative.");
            }
        }
        return errors;
    }

    private static void ValidateQuantity(PlatformRecord platform, List<string> errors)
    {
        var quantity = platform.Quantity;
        if (quantity.IsUnknown) return;
        if (quantity is not { Minimum: int minimum, Likely: int likely, Maximum: int maximum })
        {
            errors.Add($"{platform.Id}: quantity must be completely unknown or contain all three values.");
            return;
        }
        if (minimum < 0 || minimum > likely || likely > maximum)
        {
            errors.Add($"{platform.Id}: quantity must satisfy 0 <= minimum <= likely <= maximum.");
        }
    }

    private static void ValidatePercent(string id, string field, int? value,
        bool nullable, List<string> errors)
    {
        if (value is null)
        {
            if (!nullable) errors.Add($"{id}: {field} is required.");
            return;
        }
        if (value is < 0 or > 100)
        {
            errors.Add($"{id}: {field} must be between 0 and 100.");
        }
    }

    private static void CheckDuplicates(IEnumerable<string> ids, string kind,
        List<string> errors)
    {
        foreach (var group in ids.GroupBy(id => id, StringComparer.Ordinal).Where(group => group.Count() > 1))
        {
            errors.Add($"Duplicate {kind} id '{group.Key}'.");
        }
    }
}
