using System.Text.Json.Serialization;

namespace FieldSim.Domain;

public enum PlatformDomain
{
    Ground,
    Air,
    UncrewedAir,
    Naval,
    Other
}

public sealed class SourceRecord
{
    public required string Id { get; init; }
    public required string Publisher { get; init; }
    public required DateOnly PublishedDate { get; init; }
    public required string Title { get; init; }
    public required Uri Url { get; init; }
}

public sealed class QuantityRange
{
    public int? Minimum { get; set; }
    public int? Likely { get; set; }
    public int? Maximum { get; set; }
    public required string Basis { get; init; }
    public required string Scope { get; init; }

    [JsonIgnore]
    public bool IsUnknown => Minimum is null && Likely is null && Maximum is null;
}

public sealed class PlatformRecord
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public required PlatformDomain Domain { get; init; }
    public required string Role { get; init; }
    public required string PublicStatus { get; init; }
    public required QuantityRange Quantity { get; init; }
    public required int ConfidencePercent { get; init; }
    public required string SourceId { get; init; }

    public int? ReadinessPercent { get; set; }
    public int? SustainmentIndex { get; set; }
    public int? ProtectionIndex { get; set; }
    public int? MobilityIndex { get; set; }
    public int? ApsCoveragePercent { get; set; }
    public int? EnduranceHours { get; set; }
    public int? CeilingFeet { get; set; }

    public required List<string> PublicNotes { get; init; }
    public required string DataBoundary { get; init; }

    [JsonIgnore]
    public int OverrideCount { get; set; }
}

public sealed class ForceDataset
{
    public required List<SourceRecord> Sources { get; init; }
    public required List<PlatformRecord> Platforms { get; init; }
    public int TotalOverrides { get; set; }

    public PlatformRecord? FindPlatform(string id) =>
        Platforms.FirstOrDefault(platform =>
            string.Equals(platform.Id, id, StringComparison.Ordinal));

    public SourceRecord? FindSource(string id) =>
        Sources.FirstOrDefault(source =>
            string.Equals(source.Id, id, StringComparison.Ordinal));
}

public sealed class ManualOverride
{
    public required string PlatformId { get; init; }
    public required string Field { get; init; }
    public int? Value { get; init; }
}
