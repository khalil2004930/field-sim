namespace FieldSim.Domain;

public static class WeaponDatasetValidator
{
    public static IReadOnlyList<string> Validate(WeaponDataset dataset)
    {
        var errors = new List<string>();
        CheckDuplicates(dataset.Sources.Select(source => source.Id), "weapon source", errors);
        CheckDuplicates(dataset.Weapons.Select(weapon => weapon.Id), "weapon", errors);
        CheckDuplicates(dataset.ResearchQueue.Select(candidate => candidate.Id),
            "weapon research candidate", errors);

        foreach (var source in dataset.Sources)
        {
            Percent(source.Id, nameof(source.ReliabilityPercent), source.ReliabilityPercent, errors);
        }

        foreach (var weapon in dataset.Weapons)
        {
            Percent(weapon.Id, nameof(weapon.EvidenceConfidencePercent),
                weapon.EvidenceConfidencePercent, errors);
            Percent(weapon.Id, nameof(weapon.Accuracy.ConfidencePercent),
                weapon.Accuracy.ConfidencePercent, errors);
            if (weapon.BaselineReliabilityPercent is int reliability)
            {
                Percent(weapon.Id, nameof(weapon.BaselineReliabilityPercent), reliability, errors);
            }

            if (weapon.SourceIds.Count == 0)
            {
                errors.Add($"{weapon.Id}: at least one source is required.");
            }
            foreach (var sourceId in weapon.SourceIds.Distinct(StringComparer.Ordinal))
            {
                if (dataset.FindSource(sourceId) is null)
                {
                    errors.Add($"{weapon.Id}: missing weapon source '{sourceId}'.");
                }
            }

            ValidateQuantity(weapon, errors);
            ValidateRange(weapon, errors);
            ValidateAccuracy(weapon, errors);
            ValidateOperator(weapon, errors);
            if (weapon.PayloadKg is < 0)
            {
                errors.Add($"{weapon.Id}: payload cannot be negative.");
            }
            if (weapon is MortarSystem { CaliberMm: < 0 })
            {
                errors.Add($"{weapon.Id}: mortar caliber cannot be negative.");
            }
            if (weapon is GunSystem { CaliberMm: < 0 })
            {
                errors.Add($"{weapon.Id}: gun caliber cannot be negative.");
            }
        }

        var weaponIds = dataset.Weapons.Select(weapon => weapon.Id)
            .ToHashSet(StringComparer.Ordinal);
        foreach (var candidate in dataset.ResearchQueue)
        {
            if (weaponIds.Contains(candidate.Id))
            {
                errors.Add($"{candidate.Id}: a research candidate cannot also be a baseline weapon.");
            }
            foreach (var sourceId in candidate.SourceIds.Distinct(StringComparer.Ordinal))
            {
                if (dataset.FindSource(sourceId) is null)
                {
                    errors.Add($"{candidate.Id}: missing candidate source '{sourceId}'.");
                }
            }
        }
        return errors;
    }

    private static void ValidateRange(WeaponSystem weapon, List<string> errors)
    {
        var range = weapon.Range;
        if (range.IsUnknown) return;
        if (range is not { MinimumKm: double minimum, MaximumKm: double maximum })
        {
            errors.Add($"{weapon.Id}: range must be completely unknown or include minimum and maximum.");
            return;
        }
        if (minimum < 0 || minimum > maximum)
        {
            errors.Add($"{weapon.Id}: range must satisfy 0 <= minimum <= maximum.");
        }
    }

    private static void ValidateAccuracy(WeaponSystem weapon, List<string> errors)
    {
        var accuracy = weapon.Accuracy;
        if (accuracy.CepMeters is < 0 || accuracy.DispersionMajorMeters is < 0 ||
            accuracy.DispersionMinorMeters is < 0)
        {
            errors.Add($"{weapon.Id}: accuracy dimensions cannot be negative.");
        }

        if (accuracy.Measure == AccuracyMeasure.CircularErrorProbable &&
            accuracy.CepMeters is null)
        {
            errors.Add($"{weapon.Id}: CEP measure requires cepMeters.");
        }
        if (accuracy.Measure == AccuracyMeasure.ImpactArea &&
            (accuracy.DispersionMajorMeters is null || accuracy.DispersionMinorMeters is null))
        {
            errors.Add($"{weapon.Id}: impact-area measure requires both dispersion dimensions.");
        }
    }

    private static void ValidateOperator(WeaponSystem weapon, List<string> errors)
    {
        var profile = weapon.Operator;
        if (profile.CrewMinimum is < 0 || profile.CrewMaximum is < 0)
        {
            errors.Add($"{weapon.Id}: crew size cannot be negative.");
        }
        if (profile.CrewMinimum is int minimum && profile.CrewMaximum is int maximum &&
            minimum > maximum)
        {
            errors.Add($"{weapon.Id}: crew minimum cannot exceed maximum.");
        }
    }

    private static void ValidateQuantity(WeaponSystem weapon, List<string> errors)
    {
        var quantity = weapon.Quantity;
        if (quantity.IsUnknown) return;
        if (quantity is not { Minimum: int minimum, Likely: int likely, Maximum: int maximum })
        {
            errors.Add($"{weapon.Id}: quantity must be completely unknown or contain all values.");
            return;
        }
        if (minimum < 0 || minimum > likely || likely > maximum)
        {
            errors.Add($"{weapon.Id}: quantity must satisfy 0 <= minimum <= likely <= maximum.");
        }
    }

    private static void Percent(string id, string field, int value, List<string> errors)
    {
        if (value is < 0 or > 100) errors.Add($"{id}: {field} must be between 0 and 100.");
    }

    private static void CheckDuplicates(IEnumerable<string> ids, string kind,
        List<string> errors)
    {
        foreach (var group in ids.GroupBy(id => id, StringComparer.Ordinal)
                     .Where(group => group.Count() > 1))
        {
            errors.Add($"Duplicate {kind} id '{group.Key}'.");
        }
    }
}
