using FieldSim.Core;
using FieldSim.Domain;

namespace FieldSim.Scenarios;

/// <summary>
/// Country-scale continuous scenario. v1.10 resolves all initial entity placement from the
/// scenario package's public geo anchors + synthetic authoring zones instead of translating the
/// old 325 m village pattern onto a magic country-scale center.
/// </summary>
public static class CountryScaleScenario
{
    public const int TheaterWidthCells = 160;
    public const int TheaterHeightCells = 210;
    public const double PlanningCellSizeMeters = 1000.0;
    public const double TheaterWidthMeters = TheaterWidthCells * PlanningCellSizeMeters;
    public const double TheaterHeightMeters = TheaterHeightCells * PlanningCellSizeMeters;
    public const string PrimaryAnchorId = "bint-jbeil";

    public static TacticalState Create(
        ScenarioPackage package,
        SmallArmsOsintDatabase? smallArms = null,
        IReadOnlyDictionary<string, string>? weaponAssignments = null)
    {
        ArgumentNullException.ThrowIfNull(package);
        var resolver = new ScenarioPlacementResolver(package);
        var state = new TacticalState(
            TheaterWidthCells,
            TheaterHeightCells,
            package.RandomSeed,
            PlanningCellSizeMeters)
        {
            ScenarioName = package.Name,
            MissionBriefing =
                "Bint Jbeil-centered country-scale sandbox. Public geography provides the map anchor only; " +
                "all lower-level defensive, approach and support positions are synthetic scenario placements. " +
                "Entities occupy continuous XYZ meters; the internal kilometer lattice is not a tactical movement grid. " +
                "Synthetic urban structures, delayed contact reporting, cohesion and casualty logistics are enabled.",
            // v1.10 keeps this integration sandbox non-terminal so long-run C2/cohesion/diagnostic behavior can be observed.
            OpenEndedScenario = true
        };

        BuildSyntheticCountryContext(state, package.RandomSeed);
        state.Infrastructure.SeedFromTiles(state.Tiles);
        state.Environment.ApplyPreset(LightCondition.Day, WeatherVisibility.Clear);

        Position3D Placement(string key)
        {
            var local = resolver.ResolveEntity(key);
            if (!resolver.InsideTheater(local))
                throw new InvalidDataException($"Scenario entity '{key}' resolves outside the simulation theater.");
            return resolver.GroundPosition(state, local);
        }

        var blueLeader = Placement("blue-leader-01");
        var blueRifle = Placement("blue-rifle-01");
        var blueAuto = Placement("blue-auto-01");
        var blueMarksman = Placement("blue-marksman-01");
        var blueMedic = Placement("blue-medic-01");
        var blueApc = Placement("blue-apc-01");

        var redLeader = Placement("red-leader-01");
        var redRifle = Placement("red-rifle-01");
        var redAuto = Placement("red-auto-01");
        var redMarksman = Placement("red-marksman-01");
        var redMedic = Placement("red-medic-01");
        var redVehicle = Placement("red-support-vehicle-01");
        var redAtgm = Placement("red-atgm-operator-01");
        var redAtgmAssistant = Placement("red-atgm-assistant-01");

        AddSoldier(state, "blue-leader-01", TacticalFaction.Blue, blueLeader, "Blue Leader", SoldierRole.Leader,
            InfantryWeaponDefinition.GenericRifle(OpticProfile.NightOptic), radio: true, medkit: false);
        AddSoldier(state, "blue-rifle-01", TacticalFaction.Blue, blueRifle, "Blue Rifleman", SoldierRole.Rifleman,
            InfantryWeaponDefinition.GenericRifle(), radio: false, medkit: false);
        AddSoldier(state, "blue-auto-01", TacticalFaction.Blue, blueAuto, "Blue Automatic", SoldierRole.AutomaticRifleman,
            InfantryWeaponDefinition.GenericMachineGun(), radio: false, medkit: false);
        AddSoldier(state, "blue-marksman-01", TacticalFaction.Blue, blueMarksman, "Blue Marksman", SoldierRole.Marksman,
            InfantryWeaponDefinition.GenericMarksmanRifle(), radio: false, medkit: false);
        AddSoldier(state, "blue-medic-01", TacticalFaction.Blue, blueMedic, "Blue Medic", SoldierRole.Medic,
            InfantryWeaponDefinition.GenericRifle(), radio: false, medkit: true);

        var redLeaderWeapon = ResolveScenarioWeapon(smallArms, weaponAssignments, "red-leader-01", "hez-ak104",
            InfantryWeaponDefinition.GenericRifle(OpticProfile.ThermalOptic));
        var redRifleWeapon = ResolveScenarioWeapon(smallArms, weaponAssignments, "red-rifle-01", "hez-ak74m",
            InfantryWeaponDefinition.GenericRifle());
        var redAutomaticWeapon = ResolveScenarioWeapon(smallArms, weaponAssignments, "red-auto-01", "hez-pkm",
            InfantryWeaponDefinition.GenericMachineGun());
        var redMarksmanWeapon = ResolveScenarioWeapon(smallArms, weaponAssignments, "red-marksman-01", "hez-hoshdar-m",
            InfantryWeaponDefinition.GenericMarksmanRifle());
        var redMedicWeapon = ResolveScenarioWeapon(smallArms, weaponAssignments, "red-medic-01", "hez-aks74",
            InfantryWeaponDefinition.GenericRifle());

        AddSoldier(state, "red-leader-01", TacticalFaction.Red, redLeader, "Red Leader", SoldierRole.Leader,
            redLeaderWeapon, radio: true, medkit: false);
        AddSoldier(state, "red-rifle-01", TacticalFaction.Red, redRifle, "Red Rifleman", SoldierRole.Rifleman,
            redRifleWeapon, radio: false, medkit: false);
        AddSoldier(state, "red-auto-01", TacticalFaction.Red, redAuto, "Red Machine Gunner", SoldierRole.MachineGunner,
            redAutomaticWeapon, radio: false, medkit: false);
        AddSoldier(state, "red-marksman-01", TacticalFaction.Red, redMarksman, "Red Marksman", SoldierRole.Marksman,
            redMarksmanWeapon, radio: false, medkit: false);
        AddSoldier(state, "red-medic-01", TacticalFaction.Red, redMedic, "Red Medic", SoldierRole.Medic,
            redMedicWeapon, radio: false, medkit: true);
        AddSoldier(state, "red-atgm-operator-01", TacticalFaction.Red, redAtgm,
            "Hezbollah ATGM Operator · synthetic", SoldierRole.Rifleman, redRifleWeapon,
            radio: true, medkit: false, capabilities: ["weapon:kornet_e", "solver:atgm-pending"]);
        AddSoldier(state, "red-atgm-assistant-01", TacticalFaction.Red, redAtgmAssistant,
            "Hezbollah ATGM Assistant · synthetic", SoldierRole.Rifleman, redMedicWeapon,
            radio: false, medkit: false, capabilities: ["support:atgm-team", "solver:atgm-pending"]);

        AddVehicle(state, "blue-apc-01", TacticalFaction.Blue, blueApc, "Blue APC",
            TacticalUnitClass.ArmoredVehicle, new Bounds3D(7.5, 3.2, 2.7));
        AddVehicle(state, "red-support-vehicle-01", TacticalFaction.Red, redVehicle, "Red Light Support Vehicle",
            TacticalUnitClass.Vehicle, new Bounds3D(5.1, 2.0, 1.9));

        // v1.10: deterministic fictional urban geometry around the public-place anchor. The pattern
        // does not reproduce real building footprints. LOS/cover and meter-native detours use these
        // structures; compartment/portal data is a foundation for later room-level navigation.
        var primaryAnchor = resolver.AnchorPoint(PrimaryAnchorId);
        BuildSyntheticUrbanDistrict(state, new Position3D(
            primaryAnchor.X, primaryAnchor.Y, state.World.GroundAltitudeAt(primaryAnchor.X, primaryAnchor.Y)), package.RandomSeed);
        ConfigureSyntheticMedicalSupport(state);

        // v1.10: objectives remain meter-native and gain explicit approach/entry/hold/secure states.
        state.Objectives.Clear();
        foreach (var authoredObjective in package.Objectives)
        {
            var local = resolver.ResolveObjective(authoredObjective);
            var precise = resolver.GroundPosition(state, local);
            state.Objectives.Add(new BattleObjective
            {
                Id = authoredObjective.Id,
                DisplayName = authoredObjective.DisplayName,
                Position = state.World.GridPointFromWorld(local.X, local.Y),
                PrecisePositionMeters = precise,
                CaptureRadiusMeters = authoredObjective.CaptureRadiusMeters,
                CaptureRadiusCells = 0,
                RequiredControlSeconds = authoredObjective.RequiredControlSeconds
            });
        }

        // v1.10 baseline orders: Blue approaches the southern synthetic objective while Red holds the
        // central synthetic defense area. Higher-level formation AI remains intentionally conservative.
        var blueObjective = state.Objectives.FirstOrDefault(item => item.Id == "bint-jbeil-south-entry")?.PrecisePositionMeters
            ?? resolver.GroundPosition(state, resolver.ZoneCenter("bint-jbeil-south-entry"));
        var redObjective = state.Objectives.FirstOrDefault(item => item.Id == "bint-jbeil-center")?.PrecisePositionMeters
            ?? resolver.GroundPosition(state, resolver.ZoneCenter("bint-jbeil-defense-center"));

        foreach (var unit in state.Units.Where(u => u.Faction == TacticalFaction.Blue))
            TacticalAiEngine.AssignOrder(state, unit, TacticalOrderType.Advance,
                state.World.GridPointFromWorld(blueObjective.X, blueObjective.Y), blueObjective);
        foreach (var unit in state.Units.Where(u => u.Faction == TacticalFaction.Red))
            TacticalAiEngine.AssignOrder(state, unit, TacticalOrderType.DefendObjective,
                state.World.GridPointFromWorld(redObjective.X, redObjective.Y), redObjective);

        DetectionEngine.Update(state);
        TacticalAiEngine.Initialize(state);
        state.EnsurePrecisePositions();
        return state;
    }

    private static void BuildSyntheticCountryContext(TacticalState state, uint seed)
    {
        for (var y = 0; y < state.Height; y++)
        for (var x = 0; x < state.Width; x++)
        {
            var selector = (x * 17 + y * 31 + (int)seed) % 100;
            var tile = selector switch
            {
                < 8 => TacticalTile.Rocky,
                < 18 => TacticalTile.Scrub,
                < 28 => TacticalTile.Agricultural,
                _ => TacticalTile.Open
            };
            state.Tiles[x, y] = tile;

            // Coarse synthetic terrain only. It deliberately does not reproduce a real elevation model.
            var altitude = 120 + 35 * Math.Sin(x * 0.08) + 55 * Math.Sin(y * 0.035);
            var terrain = tile switch
            {
                TacticalTile.Rocky => TerrainType.Rocky,
                TacticalTile.Scrub => TerrainType.Scrub,
                TacticalTile.Agricultural => TerrainType.Agricultural,
                _ => TerrainType.Open
            };
            // Grid-row Y increases downward while local-world Y increases northward. Mark the
            // southern ~55 km band as the synthetic battlefield context; Bint Jbeil projects
            // into this band.
            var territory = y >= state.Height - 55
                ? TerritoryState.Battlefield
                : TerritoryState.Neutral;
            state.World.SetCell(new GridPoint(x, y), altitude, new SpatialContext(
                terrain,
                AreaType.OpenTerrain,
                territory,
                altitude,
                terrain == TerrainType.Scrub ? 0.28 : 0.08,
                0,
                terrain == TerrainType.Rocky ? 0.25 : 0.08,
                terrain == TerrainType.Scrub ? 0.30 : 0.08,
                0,
                null));
        }
    }

    private static void ConfigureSyntheticMedicalSupport(TacticalState state)
    {
        state.OperationalSupport.Assets.Clear();
        state.OperationalSupport.Requests.Clear();
        foreach (var faction in new[] { TacticalFaction.Blue, TacticalFaction.Red })
        {
            var prefix = faction == TacticalFaction.Blue ? "blue" : "red";
            state.OperationalSupport.Assets.Add(new SupportAssetRuntime
            {
                Id = $"{prefix}-medical-support",
                Definition = new SupportAssetDefinition
                {
                    Id = $"{prefix}-medical-team",
                    DisplayName = $"{faction} synthetic medical support",
                    Kind = SupportAssetKind.MedicalTeam,
                    DataBoundary = "Synthetic scenario medical support with normalized game timing; no real procedure or location."
                },
                Availability = new AssetState
                {
                    AssetId = $"{prefix}-medical-support",
                    PlatformId = "synthetic-medical-team"
                },
                Faction = faction,
                OperatingZoneId = "abstract-medical-network"
            });
        }
    }

    private static void BuildSyntheticUrbanDistrict(TacticalState state, Position3D anchor, uint seed)
    {
        state.Structures.Clear();
        var rng = new DeterministicRng(seed ^ 0xA17B3C29u);
        var occupied = state.Units.Select(state.GroundPositionOf).ToArray();
        var candidates = new List<(double X, double Y)>();

        // Fictional block pattern spanning the synthetic defense area. Offsets are deliberately
        // generated and irregular rather than copied from any real street/building geometry.
        for (var row = -4; row <= 4; row++)
        for (var column = -5; column <= 5; column++)
        {
            if ((row + column) % 3 == 0) continue;
            var x = anchor.X + column * 135 + rng.NextInclusive(-24, 24);
            var y = anchor.Y + row * 125 + rng.NextInclusive(-22, 22);
            candidates.Add((x, y));
        }

        var buildingIndex = 1;
        foreach (var candidate in candidates.OrderBy(_ => rng.NextUInt32()))
        {
            if (buildingIndex > 30) break;
            var width = rng.NextInclusive(12, 25);
            var depth = rng.NextInclusive(11, 23);
            var halfW = width * 0.5;
            var halfD = depth * 0.5;
            if (occupied.Any(point => Math.Abs(point.X - candidate.X) <= halfW + 12 &&
                                      Math.Abs(point.Y - candidate.Y) <= halfD + 12))
                continue;

            var groundZ = state.World.GroundAltitudeAt(candidate.X, candidate.Y);
            var floors = rng.NextInclusive(1, 3);
            const double floorHeight = 3.1;
            var id = $"synthetic-block-{buildingIndex:D2}";
            var structure = new StructureVolume
            {
                Id = id,
                Name = $"Synthetic Block {buildingIndex:D2}",
                Type = StructureVolumeType.Building,
                Bounds = new AxisAlignedBounds3D(
                    new Position3D(candidate.X - halfW, candidate.Y - halfD, groundZ),
                    new Position3D(candidate.X + halfW, candidate.Y + halfD, groundZ + floors * floorHeight)),
                SyntheticScenarioElement = true
            };

            for (var level = 0; level < floors; level++)
            {
                var z0 = groundZ + level * floorHeight;
                var z1 = z0 + floorHeight;
                var roomIds = new string[4];
                for (var room = 0; room < 4; room++)
                {
                    var west = room % 2 == 0;
                    var south = room < 2;
                    var roomId = $"{id}-L{level}-R{room + 1}";
                    roomIds[room] = roomId;
                    var minX = west ? candidate.X - halfW : candidate.X;
                    var maxX = west ? candidate.X : candidate.X + halfW;
                    var minY = south ? candidate.Y - halfD : candidate.Y;
                    var maxY = south ? candidate.Y : candidate.Y + halfD;
                    structure.Compartments.Add(new StructureCompartment
                    {
                        Id = roomId,
                        Name = $"Level {level + 1} room {room + 1}",
                        LevelIndex = level,
                        Bounds = new AxisAlignedBounds3D(
                            new Position3D(minX, minY, z0), new Position3D(maxX, maxY, z1)),
                        DominantMaterial = level == 0 ? StructureMaterialClass.Masonry : StructureMaterialClass.Mixed
                    });
                }

                structure.Portals.Add(new NavigationPortal($"{id}-L{level}-D1", roomIds[0], roomIds[1],
                    NavigationPortalType.Opening, new Position3D(candidate.X, candidate.Y - depth * 0.25, z0 + 1.0)));
                structure.Portals.Add(new NavigationPortal($"{id}-L{level}-D2", roomIds[2], roomIds[3],
                    NavigationPortalType.Opening, new Position3D(candidate.X, candidate.Y + depth * 0.25, z0 + 1.0)));
                structure.Portals.Add(new NavigationPortal($"{id}-L{level}-D3", roomIds[0], roomIds[2],
                    NavigationPortalType.Door, new Position3D(candidate.X - width * 0.25, candidate.Y, z0 + 1.0)));
                structure.Portals.Add(new NavigationPortal($"{id}-L{level}-D4", roomIds[1], roomIds[3],
                    NavigationPortalType.Door, new Position3D(candidate.X + width * 0.25, candidate.Y, z0 + 1.0)));
                if (level > 0)
                {
                    structure.Portals.Add(new NavigationPortal($"{id}-STAIR-{level}",
                        $"{id}-L{level - 1}-R4", roomIds[3], NavigationPortalType.Stair,
                        new Position3D(candidate.X + width * 0.20, candidate.Y + depth * 0.20, z0)));
                }
            }

            state.Structures.Add(structure);
            buildingIndex++;
        }

        state.AddActivity(TacticalEventType.Scenario,
            $"URBAN LAYER: {state.Structures.Count} fictional structures loaded; LOS/cover is active and full room-by-room navigation remains a future layer.");
    }

    private static Position3D Ground(TacticalState state, double x, double y) =>
        new(x, y, state.World.GroundAltitudeAt(x, y));

    private static InfantryWeaponDefinition ResolveScenarioWeapon(
        SmallArmsOsintDatabase? smallArms,
        IReadOnlyDictionary<string, string>? weaponAssignments,
        string entityKey,
        string defaultWeaponId,
        InfantryWeaponDefinition fallback)
    {
        if (smallArms is null) return fallback;
        var weaponId = weaponAssignments is not null && weaponAssignments.TryGetValue(entityKey, out var authored)
            ? authored
            : defaultWeaponId;
        return SmallArmsRuntimeAdapter.FindRequired(smallArms, weaponId);
    }

    private static void AddSoldier(
        TacticalState state,
        string entityKey,
        TacticalFaction faction,
        Position3D exactPosition,
        string name,
        SoldierRole role,
        InfantryWeaponDefinition weaponDefinition,
        bool radio,
        bool medkit,
        IReadOnlyList<string>? capabilities = null)
    {
        var weapon = new WeaponRuntime
        {
            Definition = weaponDefinition,
            Optic = weaponDefinition.DefaultOptic,
            SelectedFireMode = weaponDefinition.Class is InfantryWeaponClass.LightMachineGun or InfantryWeaponClass.GeneralPurposeMachineGun
                ? FireMode.Automatic
                : FireMode.SemiAutomatic
        };
        weapon.InitializeAmmo(weaponDefinition.Class is InfantryWeaponClass.LightMachineGun or InfantryWeaponClass.GeneralPurposeMachineGun ? 300 : 150);

        var soldier = new SoldierRuntime
        {
            Role = role,
            PrimaryWeapon = weapon,
            BaseBodyMassKg = 78
        };
        soldier.Equipment.Radio = radio;
        soldier.Equipment.Medkit = medkit;
        soldier.Skills.Marksmanship01 = role switch
        {
            SoldierRole.Marksman => 0.76,
            SoldierRole.Leader => 0.66,
            SoldierRole.AutomaticRifleman or SoldierRole.MachineGunner => 0.60,
            _ => 0.57
        };
        soldier.Skills.Observation01 = role is SoldierRole.Leader or SoldierRole.Marksman ? 0.70 : 0.56;
        soldier.Skills.Medical01 = role == SoldierRole.Medic ? 0.82 : 0.20;
        soldier.Skills.Discipline01 = role == SoldierRole.Leader ? 0.74 : 0.61;

        var cell = state.World.GridPointFromWorld(exactPosition.X, exactPosition.Y);
        var unit = new TacticalUnit
        {
            Id = state.Units.Count + 1,
            EntityKey = entityKey,
            Faction = faction,
            Position = cell,
            DisplayName = name,
            UnitClass = TacticalUnitClass.Person,
            Bounds = Bounds3D.Human,
            Signature = SignatureProfile.Human,
            EyeHeightMeters = 1.7,
            SightRange = 6,
            Soldier = soldier
        };
        unit.SetGroundPosition(state, exactPosition);
        if (capabilities is not null) unit.CapabilityIds.AddRange(capabilities);
        unit.Sensors.Add(new SensorDefinition(
            $"visual-{unit.Id}", "Human visual/optic", SensorType.Visual,
            1.7, 1200, 0.58 + soldier.Skills.Observation01 * 0.20, 0.42, 160));
        if (weapon.Optic.Thermal)
            unit.Sensors.Add(new SensorDefinition(
                $"thermal-{unit.Id}", "Weapon thermal optic", SensorType.Thermal,
                1.7, 1300, 0.70, 0.48, weapon.Optic.FieldOfViewDegrees));
        state.Units.Add(unit);
    }

    private static void AddVehicle(
        TacticalState state,
        string entityKey,
        TacticalFaction faction,
        Position3D exactPosition,
        string name,
        TacticalUnitClass unitClass,
        Bounds3D bounds)
    {
        var cell = state.World.GridPointFromWorld(exactPosition.X, exactPosition.Y);
        var unit = new TacticalUnit
        {
            Id = state.Units.Count + 1,
            EntityKey = entityKey,
            Faction = faction,
            Position = cell,
            DisplayName = name,
            UnitClass = unitClass,
            Bounds = bounds,
            Signature = unitClass == TacticalUnitClass.Vehicle
                ? new SignatureProfile(0.58, 0.62, 0.42, 0.58)
                : new SignatureProfile(0.78, 0.82, 0.70, 0.72),
            EyeHeightMeters = unitClass == TacticalUnitClass.Vehicle ? 1.9 : 2.45,
            SightRange = 8
        };
        unit.SetGroundPosition(state, exactPosition);
        unit.Sensors.Add(new SensorDefinition(
            $"vehicle-optical-{unit.Id}", "Vehicle optical channel", SensorType.Visual,
            unit.EyeHeightMeters, 1900, 0.70, 0.58, 360));
        state.Units.Add(unit);
    }
}
