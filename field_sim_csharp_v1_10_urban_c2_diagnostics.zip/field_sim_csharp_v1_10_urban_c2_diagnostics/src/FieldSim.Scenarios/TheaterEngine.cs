using FieldSim.Core;

namespace FieldSim.Scenarios;

public static class TheaterEngine
{
    public static void Run(TheaterState state, int hours)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(hours);
        for (var index = 0; index < hours; index++) Step(state);
    }

    public static void Step(TheaterState state)
    {
        foreach (var order in state.Orders.Where(order =>
                     !order.Executed && state.Hour >= order.EarliestHour && ConditionMet(state, order)))
        {
            ExecuteOrder(state, order);
        }
        ResolveZones(state);
        ApplyBackgroundSystems(state);
        state.Hour++;
    }

    public static TheaterOutcome GetOutcome(TheaterState state)
    {
        var idf = state.Formations.Where(item => item.Actor == TheaterActor.Idf).Sum(item => item.Capacity);
        var hezbollah = state.Formations.Where(item => item.Actor == TheaterActor.Hezbollah).Sum(item => item.Capacity);
        var risk = state.Zones.Count == 0 ? 0 : (int)state.Zones.Average(item => item.CivilianRisk);
        var infrastructure = state.Zones.Count == 0 ? 0 : (int)state.Zones.Average(item => item.Infrastructure);
        return new TheaterOutcome(idf, hezbollah, risk, infrastructure,
            state.TotalDisplaced, state.Escalation);
    }

    private static bool ConditionMet(TheaterState state, ScheduledOrder order)
    {
        var formation = state.Formations[order.Formation];
        var zone = order.ConditionZone >= 0 ? order.ConditionZone : formation.Zone;
        if (zone < 0 || zone >= state.Zones.Count) return false;

        return order.Condition switch
        {
            TheaterConditionKind.Always => true,
            TheaterConditionKind.CapacityBelow => formation.Capacity < order.Threshold,
            TheaterConditionKind.SupplyBelow => formation.Supply < order.Threshold,
            TheaterConditionKind.CivilianRiskAbove => state.Zones[zone].CivilianRisk > order.Threshold,
            TheaterConditionKind.ZoneContested => ZoneContested(state, zone),
            TheaterConditionKind.OpposingPresence => OpposingPresence(state, formation, zone),
            _ => false
        };
    }

    private static void ExecuteOrder(TheaterState state, ScheduledOrder order)
    {
        var formation = state.Formations[order.Formation];
        var beforeZone = formation.Zone;
        var zone = state.Zones[formation.Zone];

        switch (order.Kind)
        {
            case TheaterOrderKind.Hold:
                formation.Cohesion = Clamp(formation.Cohesion + 4);
                formation.Supply = Clamp(formation.Supply - 1);
                break;
            case TheaterOrderKind.Move:
                if (order.TargetZone < 0 || order.TargetZone >= state.Zones.Count ||
                    !state.Zones[beforeZone].AdjacentZones.Contains(order.TargetZone) ||
                    state.Zones[order.TargetZone].Access < 20 || formation.Mobility < 20)
                {
                    AddEvent(state, $"{formation.Name} could not complete a planned move");
                    order.Executed = true;
                    return;
                }
                formation.Zone = order.TargetZone;
                formation.Supply = Clamp(formation.Supply - 5);
                formation.Cohesion = Clamp(formation.Cohesion - 2);
                break;
            case TheaterOrderKind.Recon:
                formation.Awareness = Clamp(formation.Awareness + 12);
                formation.Supply = Clamp(formation.Supply - 2);
                break;
            case TheaterOrderKind.Reorganize:
                formation.Cohesion = Clamp(formation.Cohesion + 10);
                formation.Capacity = Clamp(formation.Capacity + 3);
                formation.Supply = Clamp(formation.Supply - 4);
                break;
            case TheaterOrderKind.HumanitarianSupport:
                zone.CivilianRisk = Clamp(zone.CivilianRisk - 9);
                zone.Access = Clamp(zone.Access + 4);
                break;
            case TheaterOrderKind.Repair:
                zone.Infrastructure = Clamp(zone.Infrastructure + 8);
                zone.Access = Clamp(zone.Access + 5);
                break;
            case TheaterOrderKind.Deescalate:
                state.Escalation = Clamp(state.Escalation - 10);
                state.DiplomaticPressure = Clamp(state.DiplomaticPressure + 5);
                break;
        }

        order.Executed = true;
        var location = formation.Zone == beforeZone
            ? $"in {state.Zones[formation.Zone].Name}"
            : $"from {state.Zones[beforeZone].Name} to {state.Zones[formation.Zone].Name}";
        AddEvent(state, $"{formation.Name} executed {OrderName(order.Kind)} {location}");
    }

    private static void ResolveZones(TheaterState state)
    {
        for (var zoneIndex = 0; zoneIndex < state.Zones.Count; zoneIndex++)
        {
            var zone = state.Zones[zoneIndex];
            if (!ZoneContested(state, zoneIndex))
            {
                if (state.Hour % 6 == 0) zone.CivilianRisk = Clamp(zone.CivilianRisk - 1);
                continue;
            }

            var idfPower = ActorPower(state, zoneIndex, TheaterActor.Idf);
            var hezbollahPower = ActorPower(state, zoneIndex, TheaterActor.Hezbollah);
            var intensity = Math.Clamp((idfPower + hezbollahPower + state.Escalation) / 25, 1, 12);
            ApplyZoneLoss(state, zoneIndex, TheaterActor.Idf,
                Math.Clamp(hezbollahPower / 30 + state.Random.NextInclusive(0, 2), 1, 8));
            ApplyZoneLoss(state, zoneIndex, TheaterActor.Hezbollah,
                Math.Clamp(idfPower / 30 + state.Random.NextInclusive(0, 2), 1, 8));

            zone.CivilianRisk = Clamp(zone.CivilianRisk + intensity);
            zone.Infrastructure = Clamp(zone.Infrastructure - intensity / 2);
            zone.Access = Clamp(zone.Access - intensity / 3);
            var newlyDisplaced = intensity * 125;
            zone.DisplacedPopulation += newlyDisplaced;
            state.TotalDisplaced += newlyDisplaced;
            state.Escalation = Clamp(state.Escalation + 1);
            AddEvent(state, $"Abstract engagement in {zone.Name}; intensity {intensity}/12");
        }
    }

    private static void ApplyBackgroundSystems(TheaterState state)
    {
        foreach (var formation in state.Formations.Where(item => item.Active))
        {
            if (!ZoneContested(state, formation.Zone)) formation.Supply = Clamp(formation.Supply + 1);
            if (formation.Supply < 20) formation.Cohesion = Clamp(formation.Cohesion - 1);
        }
        if (state.DiplomaticPressure > state.Escalation && state.Hour % 6 == 0)
        {
            state.Escalation = Clamp(state.Escalation - 1);
        }
    }

    private static void ApplyZoneLoss(TheaterState state, int zone, TheaterActor actor, int loss)
    {
        var formations = state.Formations.Where(item =>
            item.Active && item.Zone == zone && item.Actor == actor).ToArray();
        if (formations.Length == 0 || loss <= 0) return;
        var share = (loss + formations.Length - 1) / formations.Length;
        foreach (var formation in formations)
        {
            formation.Capacity = Clamp(formation.Capacity - share);
            formation.Cohesion = Clamp(formation.Cohesion - share / 2);
            formation.Supply = Clamp(formation.Supply - 2);
            formation.Active = formation.Capacity > 0;
        }
    }

    private static int ActorPower(TheaterState state, int zone, TheaterActor actor) =>
        state.Formations.Where(item => item.Active && item.Zone == zone && item.Actor == actor)
            .Sum(item => item.Capacity * (item.Cohesion + item.Supply + item.Awareness) / 300);

    private static bool ZoneContested(TheaterState state, int zone) =>
        HasActor(state, zone, TheaterActor.Idf) && HasActor(state, zone, TheaterActor.Hezbollah);

    private static bool OpposingPresence(TheaterState state, TheaterFormation formation, int zone) =>
        formation.Actor switch
        {
            TheaterActor.Idf => HasActor(state, zone, TheaterActor.Hezbollah),
            TheaterActor.Hezbollah => HasActor(state, zone, TheaterActor.Idf),
            _ => ZoneContested(state, zone)
        };

    private static bool HasActor(TheaterState state, int zone, TheaterActor actor) =>
        state.Formations.Any(item => item.Active && item.Zone == zone && item.Actor == actor);

    private static void AddEvent(TheaterState state, string message) =>
        state.Events.Add(new SimulationEvent(state.Hour, message));

    private static int Clamp(int value) => Math.Clamp(value, 0, 100);

    private static string OrderName(TheaterOrderKind kind) => kind switch
    {
        TheaterOrderKind.HumanitarianSupport => "humanitarian support",
        TheaterOrderKind.Deescalate => "de-escalate",
        _ => kind.ToString().ToLowerInvariant()
    };
}
