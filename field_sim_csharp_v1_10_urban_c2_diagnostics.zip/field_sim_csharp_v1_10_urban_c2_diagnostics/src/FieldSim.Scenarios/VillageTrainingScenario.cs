using FieldSim.Core;
using FieldSim.Domain;

namespace FieldSim.Scenarios;

public static class VillageTrainingScenario
{
    private const double CellSizeMeters = 25;

    public static TacticalState Create(
        VillageMapDefinition village,
        SmallArmsOsintDatabase? smallArms = null,
        IReadOnlyDictionary<string, string>? weaponAssignments = null,
        IReadOnlyDictionary<string, ScenarioInitialPlacement>? initialPlacements = null)
    {
        ArgumentNullException.ThrowIfNull(village);
        var state = new TacticalState(
            VillageGridReference.GridSize,
            VillageGridReference.GridSize,
            (uint)village.TerrainSeed,
            CellSizeMeters);
        var random = new DeterministicRng((uint)village.TerrainSeed);

        BuildFictionalTerrain(state, random, village.TerrainSeed);
        BuildSyntheticWorld(state, village.TerrainSeed);

        state.Environment.ApplyPreset(LightCondition.Day, WeatherVisibility.Clear);
        state.ScenarioName = $"{village.Name} Crossroads Meeting Engagement";
        state.MissionBriefing =
            "Synthetic meeting engagement. Individual entities use continuous local XYZ positions in meters; the 13x13 terrain grid is only a coarse navigation/context layer.";

        var starts = new[]
        {
            new GridPoint(3, 1), new GridPoint(2, 2), new GridPoint(4, 2), new GridPoint(1, 3), new GridPoint(5, 2),
            new GridPoint(9, 10), new GridPoint(8, 10), new GridPoint(10, 10), new GridPoint(8, 9), new GridPoint(10, 9),
            new GridPoint(1, 1), new GridPoint(11, 11), new GridPoint(6, 10), new GridPoint(7, 10)
        };
        foreach (var point in starts) PrepareOpenCell(state, point, road: false);
        var engagementAltitude = state.World.GroundAltitude(new GridPoint(6, 6));
        for (var y = 5; y <= 7; y++)
        for (var x = 4; x <= 8; x++)
            PrepareOpenCell(state, new GridPoint(x, y), road: y == 6,
                altitudeMeters: engagementAltitude);
        state.Infrastructure.SeedFromTiles(state.Tiles);

        AddSoldier(state, "blue-leader-01", TacticalFaction.Blue, starts[0], "Blue Leader", SoldierRole.Leader,
            InfantryWeaponDefinition.GenericRifle(OpticProfile.NightOptic), radio: true, medkit: false);
        AddSoldier(state, "blue-rifle-01", TacticalFaction.Blue, starts[1], "Blue Rifleman", SoldierRole.Rifleman,
            InfantryWeaponDefinition.GenericRifle(), radio: false, medkit: false);
        AddSoldier(state, "blue-auto-01", TacticalFaction.Blue, starts[2], "Blue Automatic", SoldierRole.AutomaticRifleman,
            InfantryWeaponDefinition.GenericMachineGun(), radio: false, medkit: false);
        AddSoldier(state, "blue-marksman-01", TacticalFaction.Blue, starts[3], "Blue Marksman", SoldierRole.Marksman,
            InfantryWeaponDefinition.GenericMarksmanRifle(), radio: false, medkit: false);
        AddSoldier(state, "blue-medic-01", TacticalFaction.Blue, starts[4], "Blue Medic", SoldierRole.Medic,
            InfantryWeaponDefinition.GenericRifle(), radio: false, medkit: true);

        var redLeaderWeapon = ResolveScenarioWeapon(
            smallArms, weaponAssignments, "red-leader-01", "hez-ak104",
            InfantryWeaponDefinition.GenericRifle(OpticProfile.ThermalOptic));
        var redRifleWeapon = ResolveScenarioWeapon(
            smallArms, weaponAssignments, "red-rifle-01", "hez-ak74m",
            InfantryWeaponDefinition.GenericRifle());
        var redAutomaticWeapon = ResolveScenarioWeapon(
            smallArms, weaponAssignments, "red-auto-01", "hez-pkm",
            InfantryWeaponDefinition.GenericMachineGun());
        var redMarksmanWeapon = ResolveScenarioWeapon(
            smallArms, weaponAssignments, "red-marksman-01", "hez-hoshdar-m",
            InfantryWeaponDefinition.GenericMarksmanRifle());
        var redMedicWeapon = ResolveScenarioWeapon(
            smallArms, weaponAssignments, "red-medic-01", "hez-aks74",
            InfantryWeaponDefinition.GenericRifle());

        AddSoldier(state, "red-leader-01", TacticalFaction.Red, starts[5], "Red Leader", SoldierRole.Leader,
            redLeaderWeapon, radio: true, medkit: false);
        AddSoldier(state, "red-rifle-01", TacticalFaction.Red, starts[6], "Red Rifleman", SoldierRole.Rifleman,
            redRifleWeapon, radio: false, medkit: false);
        AddSoldier(state, "red-auto-01", TacticalFaction.Red, starts[7], "Red Machine Gunner", SoldierRole.MachineGunner,
            redAutomaticWeapon, radio: false, medkit: false);
        AddSoldier(state, "red-marksman-01", TacticalFaction.Red, starts[8], "Red Marksman", SoldierRole.Marksman,
            redMarksmanWeapon, radio: false, medkit: false);
        AddSoldier(state, "red-medic-01", TacticalFaction.Red, starts[9], "Red Medic", SoldierRole.Medic,
            redMedicWeapon, radio: false, medkit: true);
        AddSoldier(state, "red-atgm-operator-01", TacticalFaction.Red, starts[12], "Hezbollah ATGM Operator · synthetic", SoldierRole.Rifleman,
            redRifleWeapon, radio: true, medkit: false, capabilities: ["weapon:kornet_e", "solver:atgm-pending"]);
        AddSoldier(state, "red-atgm-assistant-01", TacticalFaction.Red, starts[13], "Hezbollah ATGM Assistant · synthetic", SoldierRole.Rifleman,
            redMedicWeapon, radio: false, medkit: false, capabilities: ["support:atgm-team", "solver:atgm-pending"]);

        AddVehicleTeam(state, "blue-apc-01", TacticalFaction.Blue, starts[10], "Blue APC");
        AddLightSupportVehicle(state, "red-support-vehicle-01", TacticalFaction.Red, starts[11], "Red Light Support Vehicle");
        ApplyAuthoredPlacements(state, initialPlacements);

        var crossroads = new BattleObjective
        {
            Id = "crossroads-g07",
            DisplayName = "G07 central crossroads",
            Position = new GridPoint(6, 6),
            CaptureRadiusCells = 1,
            RequiredControlSeconds = 20
        };
        state.Objectives.Add(crossroads);

        var blueObjectives = new[]
        {
            new GridPoint(6, 5), new GridPoint(5, 6), new GridPoint(5, 7),
            new GridPoint(4, 5), new GridPoint(4, 7), new GridPoint(3, 6)
        };
        var redObjectives = new[]
        {
            new GridPoint(6, 7), new GridPoint(7, 6), new GridPoint(7, 5),
            new GridPoint(8, 5), new GridPoint(8, 7), new GridPoint(9, 6),
            new GridPoint(7, 7), new GridPoint(8, 6)
        };
        var blueUnits = state.Units.Where(unit => unit.Faction == TacticalFaction.Blue).ToArray();
        var redUnits = state.Units.Where(unit => unit.Faction == TacticalFaction.Red).ToArray();
        for (var index = 0; index < blueUnits.Length; index++)
            TacticalAiEngine.AssignOrder(state, blueUnits[index],
                index == blueUnits.Length - 1 ? TacticalOrderType.Support : TacticalOrderType.SeizeObjective,
                blueObjectives[index]);
        for (var index = 0; index < redUnits.Length; index++)
            TacticalAiEngine.AssignOrder(state, redUnits[index],
                index == redUnits.Length - 1 ? TacticalOrderType.Support : TacticalOrderType.DefendObjective,
                redObjectives[index]);

        // Establish initial faction knowledge without exposing it to the other side.
        DetectionEngine.Update(state);
        TacticalAiEngine.Initialize(state);
        return state;
    }

    private static void PrepareOpenCell(TacticalState state, GridPoint point, bool road,
        double? altitudeMeters = null)
    {
        state.Tiles[point.X, point.Y] = road ? TacticalTile.Road : TacticalTile.Open;
        var old = state.World.Context(point);
        state.World.SetCell(point, altitudeMeters ?? state.World.GroundAltitude(point), old with
        {
            Terrain = road ? TerrainType.Road : TerrainType.Open,
            Area = AreaType.OpenTerrain,
            BuildingDensity = 0,
            VegetationDensity = Math.Min(old.VegetationDensity, 0.08),
            Cover = road ? 0.02 : Math.Min(old.Cover, 0.08),
            Concealment = road ? 0.01 : Math.Min(old.Concealment, 0.08),
            ObstacleHeightMeters = 0
        });
    }

    private static void BuildFictionalTerrain(TacticalState state, DeterministicRng random, int seed)
    {
        for (var y = 0; y < state.Height; y++)
        for (var x = 0; x < state.Width; x++)
        {
            var selector = (x * 17 + y * 31 + seed) % 100;
            state.Tiles[x, y] = selector switch
            {
                < 18 => TacticalTile.Agricultural,
                < 29 => TacticalTile.Scrub,
                < 36 => TacticalTile.Rocky,
                _ => TacticalTile.Open
            };
        }

        var eastWestRoad = 5 + random.NextInclusive(0, 2);
        var northSouthRoad = 5 + random.NextInclusive(0, 2);
        for (var x = 0; x < state.Width; x++) state.Tiles[x, eastWestRoad] = TacticalTile.Road;
        for (var y = 0; y < state.Height; y++) state.Tiles[northSouthRoad, y] = TacticalTile.Road;

        // A synthetic village core and secondary built-up clusters. These are deliberately non-georeferenced.
        AddPatch(state, TacticalTile.Building, 3, 3, 3, 2);
        AddPatch(state, TacticalTile.Building, 4, 6, 3, 2);
        AddPatch(state, TacticalTile.Building, 2 + random.NextInclusive(0, 1), 8, 2, 2);
        AddPatch(state, TacticalTile.Building, 9, 2 + random.NextInclusive(0, 1), 2, 2);

        AddPatch(state, TacticalTile.Forest, 1 + random.NextInclusive(0, 1), 1 + random.NextInclusive(0, 1), 2, 2);
        AddPatch(state, TacticalTile.Forest, 9, 8 + random.NextInclusive(0, 1), 3, 2);

        var waterColumn = random.NextInclusive(0, 99) < 20 ? 0 : -1;
        if (waterColumn >= 0)
        {
            for (var y = 0; y < state.Height; y++) state.Tiles[waterColumn, y] = TacticalTile.Water;
        }
    }

    private static void BuildSyntheticWorld(TacticalState state, int seed)
    {
        var baseAltitude = 260 + seed % 110;

        for (var y = 0; y < state.Height; y++)
        for (var x = 0; x < state.Width; x++)
        {
            var hill = 52 * Math.Sin((x + seed * 0.01) * 0.43) +
                       38 * Math.Cos((y - seed * 0.013) * 0.39);
            var ridgeCenter = 8.2 + Math.Sin(seed * 0.001) * 1.5;
            var ridgeDistance = Math.Abs(y - ridgeCenter);
            var ridge = Math.Max(0, 1 - ridgeDistance / 4.2) * 84;
            var localNoise = ((x * 29 + y * 47 + seed) % 23) - 11;
            var altitude = Math.Max(5, baseAltitude + hill + ridge + localNoise);

            var tile = state.Tiles[x, y];
            var (terrain, area, vegetation, buildings, cover, concealment, obstacle) = tile switch
            {
                TacticalTile.Road => (TerrainType.Road, AreaType.OpenTerrain, 0.03, 0.02, 0.02, 0.01, 0.0),
                TacticalTile.Forest => (TerrainType.Forest, AreaType.Forest, 0.88, 0.02, 0.48, 0.66, 11.0),
                TacticalTile.Building => (TerrainType.UrbanSurface, AreaType.Village, 0.12, 0.82, 0.72, 0.58, 8.0),
                TacticalTile.Water => (TerrainType.Water, AreaType.Water, 0.0, 0.0, 0.0, 0.0, 0.0),
                TacticalTile.Scrub => (TerrainType.Scrub, AreaType.OpenTerrain, 0.46, 0.0, 0.16, 0.28, 1.6),
                TacticalTile.Agricultural => (TerrainType.Agricultural, AreaType.OpenTerrain, 0.24, 0.01, 0.08, 0.13, 0.8),
                TacticalTile.Rocky => (TerrainType.Rocky, AreaType.Wilderness, 0.08, 0.0, 0.28, 0.12, 1.2),
                _ => (TerrainType.Open, AreaType.OpenTerrain, 0.08, 0.0, 0.05, 0.04, 0.0)
            };

            var territory = y switch
            {
                <= 3 => TerritoryState.Friendly,
                >= 9 => TerritoryState.Hostile,
                6 or 7 => TerritoryState.Battlefield,
                _ => TerritoryState.Contested
            };
            TacticalFaction? controller = territory switch
            {
                TerritoryState.Friendly => TacticalFaction.Blue,
                TerritoryState.Hostile => TacticalFaction.Red,
                _ => null
            };

            state.World.SetCell(new GridPoint(x, y), altitude,
                new SpatialContext(
                    terrain,
                    area,
                    territory,
                    altitude,
                    vegetation,
                    buildings,
                    cover,
                    concealment,
                    obstacle,
                    controller));
        }
    }

    private static void AddPatch(TacticalState state, TacticalTile tile, int x, int y,
        int width, int height)
    {
        for (var row = y; row < y + height; row++)
        for (var column = x; column < x + width; column++)
        {
            if (state.InBounds(column, row)) state.Tiles[column, row] = tile;
        }
    }


    private static void ApplyAuthoredPlacements(
        TacticalState state,
        IReadOnlyDictionary<string, ScenarioInitialPlacement>? initialPlacements)
    {
        if (initialPlacements is null) return;
        var maxX = state.Width * state.World.CellSizeMeters;
        var maxY = state.Height * state.World.CellSizeMeters;
        foreach (var unit in state.Units)
        {
            if (!initialPlacements.TryGetValue(unit.EntityKey, out var placement)) continue;
            if (placement.XMeters < 0 || placement.XMeters >= maxX || placement.YMeters < 0 || placement.YMeters >= maxY)
                throw new InvalidDataException($"Initial placement for '{unit.EntityKey}' is outside the local scenario world.");
            unit.SetGroundPosition(state, new Position3D(
                placement.XMeters,
                placement.YMeters,
                state.World.GroundAltitudeAt(placement.XMeters, placement.YMeters)));
            unit.Orientation = unit.Orientation with { HeadingDegrees = NormalizeHeading(placement.HeadingDegrees) };
        }
    }

    private static double NormalizeHeading(double headingDegrees)
    {
        var normalized = headingDegrees % 360;
        return normalized < 0 ? normalized + 360 : normalized;
    }

    private static InfantryWeaponDefinition ResolveScenarioWeapon(
        SmallArmsOsintDatabase? smallArms,
        IReadOnlyDictionary<string, string>? weaponAssignments,
        string entityKey,
        string defaultWeaponId,
        InfantryWeaponDefinition fallback)
    {
        if (smallArms is null) return fallback;
        var weaponId = weaponAssignments is not null && weaponAssignments.TryGetValue(entityKey, out var authored)
            ? authored
            : defaultWeaponId;
        return SmallArmsRuntimeAdapter.FindRequired(smallArms, weaponId);
    }

    private static void AddSoldier(
        TacticalState state,
        string entityKey,
        TacticalFaction faction,
        GridPoint position,
        string name,
        SoldierRole role,
        InfantryWeaponDefinition weaponDefinition,
        bool radio,
        bool medkit,
        IReadOnlyList<string>? capabilities = null)
    {
        var weapon = new WeaponRuntime
        {
            Definition = weaponDefinition,
            Optic = weaponDefinition.DefaultOptic,
            SelectedFireMode = weaponDefinition.Class is InfantryWeaponClass.LightMachineGun or InfantryWeaponClass.GeneralPurposeMachineGun
                ? FireMode.Automatic
                : FireMode.SemiAutomatic
        };
        var supportWeapon = weaponDefinition.Class is InfantryWeaponClass.LightMachineGun or InfantryWeaponClass.GeneralPurposeMachineGun;
        weapon.InitializeAmmo(supportWeapon ? 300 : 150);

        var soldier = new SoldierRuntime
        {
            Role = role,
            PrimaryWeapon = weapon,
            BaseBodyMassKg = 78
        };
        soldier.Equipment.Radio = radio;
        soldier.Equipment.Medkit = medkit;
        soldier.Skills.Marksmanship01 = role switch
        {
            SoldierRole.Marksman => 0.76,
            SoldierRole.Leader => 0.66,
            SoldierRole.AutomaticRifleman or SoldierRole.MachineGunner => 0.60,
            _ => 0.57
        };
        soldier.Skills.Observation01 = role is SoldierRole.Leader or SoldierRole.Marksman ? 0.70 : 0.56;
        soldier.Skills.Medical01 = role == SoldierRole.Medic ? 0.82 : 0.20;
        soldier.Skills.Discipline01 = role == SoldierRole.Leader ? 0.74 : 0.61;

        var unit = new TacticalUnit
        {
            Id = state.Units.Count + 1,
            EntityKey = entityKey,
            Faction = faction,
            Position = position,
            DisplayName = name,
            UnitClass = TacticalUnitClass.Person,
            Bounds = Bounds3D.Human,
            Signature = SignatureProfile.Human,
            EyeHeightMeters = 1.7,
            SightRange = 6,
            Soldier = soldier
        };
        unit.SetGroundPosition(state, PreciseStartPosition(state, position, unit.Id));
        if (capabilities is not null) unit.CapabilityIds.AddRange(capabilities);
        unit.Sensors.Add(new SensorDefinition(
            $"visual-{unit.Id}", "Human visual/optic", SensorType.Visual,
            1.7, 1200, 0.58 + soldier.Skills.Observation01 * 0.20, 0.42, 160));
        if (weapon.Optic.Thermal)
        {
            unit.Sensors.Add(new SensorDefinition(
                $"thermal-{unit.Id}", "Weapon thermal optic", SensorType.Thermal,
                1.7, 1300, 0.70, 0.48, weapon.Optic.FieldOfViewDegrees));
        }
        state.Units.Add(unit);
    }

    private static void AddLightSupportVehicle(
        TacticalState state,
        string entityKey,
        TacticalFaction faction,
        GridPoint position,
        string name)
    {
        var unit = new TacticalUnit
        {
            Id = state.Units.Count + 1,
            EntityKey = entityKey,
            Faction = faction,
            Position = position,
            DisplayName = name,
            UnitClass = TacticalUnitClass.Vehicle,
            Bounds = new Bounds3D(5.1, 2.0, 1.9),
            Signature = new SignatureProfile(0.58, 0.62, 0.42, 0.58),
            EyeHeightMeters = 1.9,
            SightRange = 7
        };
        unit.SetGroundPosition(state, PreciseStartPosition(state, position, unit.Id));
        unit.Sensors.Add(new SensorDefinition(
            $"light-vehicle-visual-{unit.Id}", "Light vehicle visual channel", SensorType.Visual,
            1.9, 1300, 0.58, 0.40, 300));
        state.Units.Add(unit);
    }

    private static void AddVehicleTeam(
        TacticalState state,
        string entityKey,
        TacticalFaction faction,
        GridPoint position,
        string name)
    {
        var unit = new TacticalUnit
        {
            Id = state.Units.Count + 1,
            EntityKey = entityKey,
            Faction = faction,
            Position = position,
            DisplayName = name,
            UnitClass = TacticalUnitClass.ArmoredVehicle,
            Bounds = new Bounds3D(7.5, 3.2, 2.7),
            Signature = new SignatureProfile(0.78, 0.82, 0.70, 0.72),
            EyeHeightMeters = 2.45,
            SightRange = 8
        };
        unit.SetGroundPosition(state, PreciseStartPosition(state, position, unit.Id));
        unit.Sensors.Add(new SensorDefinition(
            $"vehicle-optical-{unit.Id}", "Vehicle optical channel", SensorType.Visual,
            2.55, 1900, 0.72, 0.60, 360));
        unit.Sensors.Add(new SensorDefinition(
            $"vehicle-thermal-{unit.Id}", "Vehicle thermal channel", SensorType.Thermal,
            2.55, 2300, 0.76, 0.62, 360));
        state.Units.Add(unit);
    }
    private static Position3D PreciseStartPosition(TacticalState state, GridPoint cell, int unitId)
    {
        var center = state.World.CellCenter(cell, 0);
        // Deterministic intra-cell dispersion keeps individuals as separate dots without
        // turning the navigation grid into a one-entity occupancy board.
        var angle = (unitId * 137.508) * Math.PI / 180.0;
        var radius = 2.0 + (unitId % 4) * 1.15;
        var x = center.X + Math.Cos(angle) * radius;
        var y = center.Y + Math.Sin(angle) * radius;
        return new Position3D(x, y, state.World.GroundAltitudeAt(x, y));
    }
}
