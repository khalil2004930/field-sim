using FieldSim.Core;
using FieldSim.Domain;

namespace FieldSim.Scenarios;

/// <summary>
/// Resolves authored scenario anchors/zones into local continuous-meter coordinates.
/// Public geographic anchors provide coarse map context; all subordinate offsets are scenario-fictional.
/// </summary>
public sealed class ScenarioPlacementResolver
{
    private readonly ScenarioPackage _package;
    private readonly Dictionary<string, ScenarioGeoAnchor> _anchors;
    private readonly Dictionary<string, ScenarioPlacementZone> _zones;
    private readonly Dictionary<string, ScenarioSupportPlacement> _supportPlacements;

    public ScenarioPlacementResolver(ScenarioPackage package)
    {
        _package = package ?? throw new ArgumentNullException(nameof(package));
        _anchors = package.GeoAnchors.ToDictionary(item => item.Id, StringComparer.Ordinal);
        _zones = package.PlacementZones.ToDictionary(item => item.Id, StringComparer.Ordinal);
        _supportPlacements = package.SupportPlacements.ToDictionary(item => item.AssetId, StringComparer.Ordinal);
    }

    public ScenarioLocalPoint AnchorPoint(string anchorId)
    {
        if (!_anchors.TryGetValue(anchorId, out var anchor))
            throw new InvalidDataException($"Scenario anchor '{anchorId}' was not found.");
        return ScenarioGeoProjection.ProjectToLocal(_package.DisplayMap, anchor.Latitude, anchor.Longitude);
    }

    public ScenarioLocalPoint ZoneCenter(string zoneId)
    {
        if (!_zones.TryGetValue(zoneId, out var zone))
            throw new InvalidDataException($"Scenario placement zone '{zoneId}' was not found.");
        var anchor = AnchorPoint(zone.AnchorId);
        return new ScenarioLocalPoint(anchor.X + zone.OffsetEastMeters, anchor.Y + zone.OffsetNorthMeters);
    }

    public ScenarioPlacementZone Zone(string zoneId)
    {
        if (!_zones.TryGetValue(zoneId, out var zone))
            throw new InvalidDataException($"Scenario placement zone '{zoneId}' was not found.");
        return zone;
    }

    public ScenarioLocalPoint Resolve(ScenarioInitialPlacement placement)
    {
        ArgumentNullException.ThrowIfNull(placement);
        if (string.IsNullOrWhiteSpace(placement.ZoneId))
            return new ScenarioLocalPoint(placement.XMeters, placement.YMeters);

        var center = ZoneCenter(placement.ZoneId);
        return new ScenarioLocalPoint(
            center.X + placement.OffsetEastMeters,
            center.Y + placement.OffsetNorthMeters);
    }

    public ScenarioLocalPoint ResolveEntity(string entityKey)
    {
        var assignment = _package.EntityAssignments.FirstOrDefault(item =>
            string.Equals(item.EntityKey, entityKey, StringComparison.Ordinal))
            ?? throw new InvalidDataException($"Scenario entity assignment '{entityKey}' was not found.");
        if (assignment.InitialPlacement is null)
            throw new InvalidDataException($"Scenario entity '{entityKey}' has no initial placement.");
        return Resolve(assignment.InitialPlacement);
    }

    public ScenarioLocalPoint ResolveObjective(ScenarioObjectiveDefinition objective)
    {
        var center = ZoneCenter(objective.ZoneId);
        return new ScenarioLocalPoint(
            center.X + objective.OffsetEastMeters,
            center.Y + objective.OffsetNorthMeters);
    }

    public ScenarioLocalPoint ResolveSupport(string assetId)
    {
        if (!_supportPlacements.TryGetValue(assetId, out var placement))
            throw new InvalidDataException($"Scenario support placement '{assetId}' was not found.");
        var center = ZoneCenter(placement.ZoneId);
        return new ScenarioLocalPoint(
            center.X + placement.OffsetEastMeters,
            center.Y + placement.OffsetNorthMeters);
    }

    public ScenarioSupportPlacement SupportPlacement(string assetId)
    {
        if (!_supportPlacements.TryGetValue(assetId, out var placement))
            throw new InvalidDataException($"Scenario support placement '{assetId}' was not found.");
        return placement;
    }

    public Position3D GroundPosition(TacticalState state, ScenarioLocalPoint point)
    {
        ArgumentNullException.ThrowIfNull(state);
        return new Position3D(point.X, point.Y, state.World.GroundAltitudeAt(point.X, point.Y));
    }

    public Position3D Position(TacticalState state, ScenarioLocalPoint point, double altitudeMeters)
    {
        ArgumentNullException.ThrowIfNull(state);
        var ground = state.World.GroundAltitudeAt(point.X, point.Y);
        return new Position3D(point.X, point.Y, ground + Math.Max(0, altitudeMeters));
    }

    public bool InsideTheater(ScenarioLocalPoint point) =>
        point.X >= 0 && point.Y >= 0 &&
        point.X < _package.DisplayMap.TheaterWidthMeters &&
        point.Y < _package.DisplayMap.TheaterHeightMeters;
}
