using FieldSim.Core;
using FieldSim.Domain;

namespace FieldSim.Scenarios;

/// <summary>
/// Converts provenance-heavy OSINT records into normalized simulation definitions.
/// The coefficients here are game/simulation abstractions; source records remain the
/// authority for identity/caliber/evidence and are never overwritten by these values.
/// </summary>
public static class SmallArmsRuntimeAdapter
{
    public static InfantryWeaponDefinition ToRuntimeDefinition(SmallArmOsintRecord record)
    {
        ArgumentNullException.ThrowIfNull(record);
        var normalizedClass = NormalizeClass(record.WeaponClass);
        var profile = ProfileFor(normalizedClass, record.Caliber);
        return new InfantryWeaponDefinition(
            record.Id,
            record.Name,
            normalizedClass,
            record.Caliber,
            profile.MagazineCapacity,
            profile.MassKg,
            profile.PracticalRangeMeters,
            profile.MaximumPhysicalRangeMeters,
            profile.CyclicRateRpm,
            profile.SustainedRateRpm,
            profile.ReloadSeconds,
            profile.Precision01,
            profile.Handling01,
            profile.Reliability01,
            profile.Suppression01,
            profile.FireModes,
            profile.DefaultOptic);
    }

    public static InfantryWeaponDefinition FindRequired(SmallArmsOsintDatabase database, string id)
    {
        ArgumentNullException.ThrowIfNull(database);
        var record = database.Weapons.FirstOrDefault(item => string.Equals(item.Id, id, StringComparison.Ordinal))
            ?? throw new InvalidDataException($"Small-arm record '{id}' was not found in {database.DatabaseName}.");
        return ToRuntimeDefinition(record);
    }

    private static InfantryWeaponClass NormalizeClass(string value) => value.ToLowerInvariant() switch
    {
        "assault_rifle" => InfantryWeaponClass.AssaultRifle,
        "carbine" or "compact_carbine" => InfantryWeaponClass.AssaultRifle,
        "general_purpose_machine_gun" => InfantryWeaponClass.GeneralPurposeMachineGun,
        "designated_marksman_sniper_rifle" => InfantryWeaponClass.DesignatedMarksmanRifle,
        "designated_marksman_battle_rifle" => InfantryWeaponClass.DesignatedMarksmanRifle,
        "bolt_action_precision_rifle" => InfantryWeaponClass.SniperRifle,
        "heavy_machine_gun" => InfantryWeaponClass.SupportWeapon,
        _ => InfantryWeaponClass.AssaultRifle
    };

    private static RuntimeProfile ProfileFor(InfantryWeaponClass weaponClass, string caliber)
    {
        var isIntermediate = caliber.Contains("5.45", StringComparison.Ordinal) ||
                             caliber.Contains("5.56", StringComparison.Ordinal) ||
                             caliber.Contains("7.62x39", StringComparison.OrdinalIgnoreCase);

        return weaponClass switch
        {
            InfantryWeaponClass.GeneralPurposeMachineGun => new RuntimeProfile(
                100, 7.5, 650, 3000, 700, 120, 5.2, 0.62, 0.48, 0.975, 0.82,
                [FireMode.Automatic], OpticProfile.IronSights),
            InfantryWeaponClass.DesignatedMarksmanRifle => new RuntimeProfile(
                10, 4.5, 700, 3200, 450, 40, 3.2, 0.80, 0.60, 0.982, 0.42,
                [FireMode.SemiAutomatic], OpticProfile.Magnified),
            InfantryWeaponClass.SniperRifle => new RuntimeProfile(
                10, 6.0, 900, 4000, 45, 20, 4.0, 0.90, 0.46, 0.988, 0.30,
                [FireMode.SingleShot], OpticProfile.Magnified),
            _ when isIntermediate => new RuntimeProfile(
                30, 3.6, 500, 2400, 650, 85, 2.8, 0.69, 0.75, 0.982, 0.44,
                [FireMode.SemiAutomatic, FireMode.Automatic], OpticProfile.IronSights),
            _ => new RuntimeProfile(
                20, 4.4, 600, 3000, 550, 65, 3.1, 0.74, 0.62, 0.982, 0.48,
                [FireMode.SemiAutomatic], OpticProfile.Magnified)
        };
    }

    private sealed record RuntimeProfile(
        int MagazineCapacity,
        double MassKg,
        double PracticalRangeMeters,
        double MaximumPhysicalRangeMeters,
        double CyclicRateRpm,
        double SustainedRateRpm,
        double ReloadSeconds,
        double Precision01,
        double Handling01,
        double Reliability01,
        double Suppression01,
        IReadOnlyList<FireMode> FireModes,
        OpticProfile DefaultOptic);
}
