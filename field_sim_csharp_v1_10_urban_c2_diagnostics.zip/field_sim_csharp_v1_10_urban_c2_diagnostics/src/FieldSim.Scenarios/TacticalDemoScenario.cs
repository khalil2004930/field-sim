using FieldSim.Core;

namespace FieldSim.Scenarios;

public static class TacticalDemoScenario
{
    public static TacticalState Create()
    {
        var state = new TacticalState(32, 20, 1234, 80);
        for (var x = 0; x < state.Width; x++)
        {
            state.Tiles[x, 9] = TacticalTile.Road;
            state.Tiles[x, 10] = TacticalTile.Road;
        }
        for (var y = 0; y < state.Height; y++) state.Tiles[15, y] = TacticalTile.Road;

        Fill(state, TacticalTile.Forest, 7, 2, 5, 5);
        Fill(state, TacticalTile.Forest, 21, 12, 6, 5);
        Fill(state, TacticalTile.Water, 18, 2, 5, 4);
        Fill(state, TacticalTile.Building, 12, 13, 3, 3);
        Fill(state, TacticalTile.Building, 25, 5, 3, 3);
        BuildWorld(state);

        Add(state, TacticalFaction.Blue, 3, 4);
        Add(state, TacticalFaction.Blue, 4, 5);
        Add(state, TacticalFaction.Blue, 3, 6);
        Add(state, TacticalFaction.Blue, 5, 5);
        Add(state, TacticalFaction.Red, 27, 13);
        Add(state, TacticalFaction.Red, 28, 15);
        Add(state, TacticalFaction.Red, 24, 17);
        DetectionEngine.Update(state);
        return state;
    }

    private static void BuildWorld(TacticalState state)
    {
        for (var y = 0; y < state.Height; y++)
        for (var x = 0; x < state.Width; x++)
        {
            var tile = state.Tiles[x, y];
            var altitude = 110 + 0.6 * x + 0.3 * y;
            var context = tile switch
            {
                TacticalTile.Forest => new SpatialContext(TerrainType.Forest, AreaType.Forest,
                    TerritoryState.Neutral, altitude, 0.85, 0.01, 0.4, 0.58, 9),
                TacticalTile.Building => new SpatialContext(TerrainType.UrbanSurface, AreaType.Village,
                    TerritoryState.Neutral, altitude, 0.08, 0.9, 0.7, 0.55, 9),
                TacticalTile.Water => new SpatialContext(TerrainType.Water, AreaType.Water,
                    TerritoryState.Neutral, altitude, 0, 0, 0, 0, 0),
                TacticalTile.Road => new SpatialContext(TerrainType.Road, AreaType.OpenTerrain,
                    TerritoryState.Neutral, altitude, 0.02, 0, 0.02, 0.01, 0),
                _ => new SpatialContext(TerrainType.Open, AreaType.OpenTerrain,
                    TerritoryState.Neutral, altitude, 0.08, 0, 0.05, 0.03, 0)
            };
            state.World.SetCell(new GridPoint(x, y), altitude, context);
        }
    }

    private static void Fill(TacticalState state, TacticalTile tile, int x, int y,
        int width, int height)
    {
        for (var row = y; row < y + height; row++)
        for (var column = x; column < x + width; column++)
        {
            if (state.InBounds(column, row)) state.Tiles[column, row] = tile;
        }
    }

    private static void Add(TacticalState state, TacticalFaction faction, int x, int y)
    {
        var unit = new TacticalUnit
        {
            Id = state.Units.Count + 1,
            Faction = faction,
            Position = new GridPoint(x, y),
            DisplayName = $"{faction} Unit {state.Units.Count + 1}",
            SightRange = 8
        };
        unit.Sensors.Add(new SensorDefinition(
            $"demo-visual-{unit.Id}", "Demo visual", SensorType.Visual,
            1.7, 1200, 0.6, 0.42, 180));
        state.Units.Add(unit);
    }
}
