using FieldSim.Core;

namespace FieldSim.Scenarios;

public enum TheaterActor
{
    Idf,
    Hezbollah,
    LebaneseArmedForces,
    Unifil
}

public enum TheaterOrderKind
{
    Hold,
    Move,
    Recon,
    Reorganize,
    HumanitarianSupport,
    Repair,
    Deescalate
}

public enum TheaterConditionKind
{
    Always,
    CapacityBelow,
    SupplyBelow,
    CivilianRiskAbove,
    ZoneContested,
    OpposingPresence
}

public sealed class TheaterZone
{
    public required string Name { get; init; }
    public HashSet<int> AdjacentZones { get; } = [];
    public int Infrastructure { get; set; }
    public int Access { get; set; }
    public int CivilianRisk { get; set; }
    public int DisplacedPopulation { get; set; }
}

public sealed class TheaterFormation
{
    public required string Name { get; init; }
    public required TheaterActor Actor { get; init; }
    public int Zone { get; set; }
    public int Capacity { get; set; }
    public int Supply { get; set; }
    public int Cohesion { get; set; }
    public int Mobility { get; set; }
    public int Awareness { get; set; }
    public bool Active { get; set; } = true;
}

public sealed class ScheduledOrder
{
    public required int Formation { get; init; }
    public required TheaterOrderKind Kind { get; init; }
    public required int TargetZone { get; init; }
    public required int EarliestHour { get; init; }
    public required TheaterConditionKind Condition { get; init; }
    public required int ConditionZone { get; init; }
    public required int Threshold { get; init; }
    public bool Executed { get; set; }
}

public sealed class TheaterState
{
    public required string ScenarioName { get; init; }
    public required List<TheaterZone> Zones { get; init; }
    public required List<TheaterFormation> Formations { get; init; }
    public required List<ScheduledOrder> Orders { get; init; }
    public required DeterministicRng Random { get; init; }
    public List<SimulationEvent> Events { get; } = [];
    public int Hour { get; set; }
    public int Escalation { get; set; } = 55;
    public int DiplomaticPressure { get; set; } = 35;
    public int TotalDisplaced { get; set; }
}

public sealed record TheaterOutcome(
    int IdfCapacity,
    int HezbollahCapacity,
    int CivilianRisk,
    int Infrastructure,
    int DisplacedPopulation,
    int Escalation);
