using FieldSim.Core;

namespace FieldSim.Scenarios;

public static class SouthLebanon2026Scenario
{
    public static TheaterState Create(uint seed)
    {
        var zones = new List<TheaterZone>
        {
            NewZone("Border Belt", 48, 55, 66, 18_000),
            NewZone("Coastal Sector", 62, 58, 51, 22_000),
            NewZone("Western Hills", 55, 44, 57, 14_000),
            NewZone("Central Highlands", 51, 38, 61, 17_000),
            NewZone("Eastern Corridor", 57, 49, 48, 11_000),
            NewZone("Northern Rear", 71, 69, 39, 30_000)
        };

        Connect(zones, 0, 1); Connect(zones, 0, 2); Connect(zones, 0, 3); Connect(zones, 0, 4);
        Connect(zones, 1, 2); Connect(zones, 1, 5); Connect(zones, 2, 3); Connect(zones, 2, 5);
        Connect(zones, 3, 4); Connect(zones, 3, 5); Connect(zones, 4, 5);

        var formations = new List<TheaterFormation>
        {
            Formation("IDF Border Task Group", TheaterActor.Idf, 0, 72, 78, 82, 76, 68),
            Formation("IDF Theater Reserve", TheaterActor.Idf, 0, 61, 84, 79, 81, 60),
            Formation("Hezbollah Border Elements", TheaterActor.Hezbollah, 0, 57, 61, 73, 64, 72),
            Formation("Hezbollah Western Elements", TheaterActor.Hezbollah, 2, 63, 66, 77, 57, 75),
            Formation("Hezbollah Central Elements", TheaterActor.Hezbollah, 3, 66, 70, 78, 54, 70),
            Formation("LAF Regional Coordination", TheaterActor.LebaneseArmedForces, 5, 46, 58, 72, 55, 48),
            Formation("UNIFIL Humanitarian Liaison", TheaterActor.Unifil, 1, 34, 65, 76, 50, 58)
        };

        var orders = new List<ScheduledOrder>
        {
            Order(0, TheaterOrderKind.Recon, 0, 0, TheaterConditionKind.Always, 0, 0),
            Order(0, TheaterOrderKind.Hold, 0, 2, TheaterConditionKind.ZoneContested, 0, 0),
            Order(1, TheaterOrderKind.Move, 2, 8, TheaterConditionKind.OpposingPresence, 2, 0),
            Order(0, TheaterOrderKind.Reorganize, 0, 18, TheaterConditionKind.CapacityBelow, 0, 45),
            Order(2, TheaterOrderKind.Hold, 0, 0, TheaterConditionKind.Always, 0, 0),
            Order(3, TheaterOrderKind.Recon, 2, 3, TheaterConditionKind.Always, 2, 0),
            Order(3, TheaterOrderKind.Move, 3, 20, TheaterConditionKind.CapacityBelow, 2, 44),
            Order(4, TheaterOrderKind.Reorganize, 3, 12, TheaterConditionKind.SupplyBelow, 3, 52),
            Order(5, TheaterOrderKind.HumanitarianSupport, 5, 0, TheaterConditionKind.CivilianRiskAbove, 5, 35),
            Order(5, TheaterOrderKind.Repair, 5, 24, TheaterConditionKind.Always, 5, 0),
            Order(6, TheaterOrderKind.HumanitarianSupport, 1, 0, TheaterConditionKind.CivilianRiskAbove, 1, 45),
            Order(6, TheaterOrderKind.Deescalate, 1, 30, TheaterConditionKind.CivilianRiskAbove, 1, 65)
        };

        return new TheaterState
        {
            ScenarioName = "Southern Lebanon 2026 — Abstract Observer Theater",
            Zones = zones,
            Formations = formations,
            Orders = orders,
            Random = new DeterministicRng(seed),
            TotalDisplaced = zones.Sum(zone => zone.DisplacedPopulation)
        };
    }

    private static TheaterZone NewZone(string name, int infrastructure, int access,
        int risk, int displaced) => new()
    {
        Name = name,
        Infrastructure = infrastructure,
        Access = access,
        CivilianRisk = risk,
        DisplacedPopulation = displaced
    };

    private static void Connect(IReadOnlyList<TheaterZone> zones, int first, int second)
    {
        zones[first].AdjacentZones.Add(second);
        zones[second].AdjacentZones.Add(first);
    }

    private static TheaterFormation Formation(string name, TheaterActor actor, int zone,
        int capacity, int supply, int cohesion, int mobility, int awareness) => new()
    {
        Name = name,
        Actor = actor,
        Zone = zone,
        Capacity = capacity,
        Supply = supply,
        Cohesion = cohesion,
        Mobility = mobility,
        Awareness = awareness
    };

    private static ScheduledOrder Order(int formation, TheaterOrderKind kind,
        int target, int hour, TheaterConditionKind condition, int conditionZone,
        int threshold) => new()
    {
        Formation = formation,
        Kind = kind,
        TargetZone = target,
        EarliestHour = hour,
        Condition = condition,
        ConditionZone = conditionZone,
        Threshold = threshold
    };
}
