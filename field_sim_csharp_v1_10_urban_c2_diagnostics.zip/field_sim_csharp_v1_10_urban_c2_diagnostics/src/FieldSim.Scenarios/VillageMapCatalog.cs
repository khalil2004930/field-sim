namespace FieldSim.Scenarios;

public sealed record VillageMapDefinition(
    string Id,
    string Name,
    string Sector,
    int TerrainSeed);

public sealed record VillageSectorDefinition(
    string Name,
    IReadOnlyList<VillageMapDefinition> Villages);

public static class VillageMapCatalog
{
    public static IReadOnlyList<VillageSectorDefinition> CreateDefault() =>
    [
        new VillageSectorDefinition("Western",
        [
            new("w-01", "Naqourah", "Western", 1197),
            new("w-02", "Alma el-Shaap", "Western", 1294),
            new("w-03", "Dhiyrah", "Western", 1391),
            new("w-04", "Yarineh", "Western", 1488)
        ]),
        new VillageSectorDefinition("Central",
        [
            new("c-01", "Aytaronn", "Central", 2297),
            new("c-02", "Blidah", "Central", 2394),
            new("c-03", "Maroun el-Rass", "Central", 2491),
            new("c-04", "Bint Jbail", "Central", 2588)
        ]),
        new VillageSectorDefinition("Eastern",
        [
            new("e-01", "Kfarkilah", "Eastern", 3397),
            new("e-02", "Odaiseh", "Eastern", 3494),
            new("e-03", "Houlaa", "Eastern", 3591),
            new("e-04", "Meiss el-Jabal", "Eastern", 3688)
        ])
    ];
}
