using FieldSim.Core;
using FieldSim.Data;
using FieldSim.Domain;
using FieldSim.Scenarios;

namespace FieldSim.Tests;

internal static class Program
{
    private static int _checks;

    private static int Main()
    {
        try
        {
            TestRandomDeterminism();
            TestAssetStateMachine();
            TestTacticalSimulation();
            TestVillageGridSystem();
            TestSpatialLosAndFactionKnowledge();
            TestV1InfantryEngagement();
            TestV12AutonomousEngagement();
            TestTheaterMapPackage();
            TestFormationDataset();
            TestVehicleDataset();
            TestForceDataModes();
            TestWeaponDataModes();
            TestTheaterDeterminism();
            TestV17ContinuousSpatialModel();
            TestV17SmallArmsAndScenarioPackage();
            TestV17OrbatSpatialAggregation();
            TestV17LosSamplingStability();
            TestV17FormationDestinationDistribution();
            TestV17StructureLodAndJournalScaffold();
            TestV18OpenEndedInfrastructureAndSupport();
            TestV193ScenarioPlacementRepair();
            TestV110UrbanC2Core();
            Console.WriteLine($"FieldSim tests passed: {_checks} checks");
            return 0;
        }
        catch (Exception exception)
        {
            Console.Error.WriteLine($"Test failure: {exception.Message}");
            return 1;
        }
    }

    private static void TestRandomDeterminism()
    {
        var first = new DeterministicRng(1234);
        var second = new DeterministicRng(1234);
        for (var index = 0; index < 100; index++)
        {
            Check(first.NextUInt32() == second.NextUInt32(), "RNG streams differ.");
        }
    }

    private static void TestAssetStateMachine()
    {
        var asset = new AssetState { AssetId = "test-1", PlatformId = "test-platform" };
        Check(asset.Assign(), "Ready asset could not be assigned.");
        Check(asset.BeginOperation(2, 20, 10, 3), "Assigned asset could not begin operation.");
        asset.TickHour();
        asset.TickHour();
        Check(asset.Status == AssetStatus.Turnaround, "Completed operation did not enter turnaround.");
        Check(asset.FuelPercent == 60 && asset.StoresPercent == 80, "Consumption was not applied.");
        asset.TickHour(); asset.TickHour(); asset.TickHour();
        Check(asset.Status == AssetStatus.Ready, "Turnaround did not return the asset to ready.");
        Check(asset.FuelPercent == 100 && asset.StoresPercent == 100, "Turnaround did not replenish the asset.");
    }

    private static void TestVillageGridSystem()
    {
        var sectors = VillageMapCatalog.CreateDefault();
        Check(sectors.Count == 3, "Village-grid sector count is incorrect.");
        Check(sectors.SelectMany(sector => sector.Villages).Count() == 12,
            "Unexpected default village-map count.");
        Check(VillageGridReference.GridSize == 13, "Village grid is not 13x13.");
        Check(VillageGridReference.RowName(0) == "Alpha" &&
            VillageGridReference.RowName(12) == "Mike",
            "Village grid row labels are incorrect.");
        Check(VillageGridReference.CellLabel(new GridPoint(0, 0)) == "Alpha-01" &&
            VillageGridReference.CellLabel(new GridPoint(12, 12)) == "Mike-13",
            "Village grid cell references are incorrect.");
        Check(VillageGridReference.KeypadFromNormalizedPosition(0.1, 0.1) == 7 &&
            VillageGridReference.KeypadFromNormalizedPosition(0.5, 0.5) == 5 &&
            VillageGridReference.KeypadFromNormalizedPosition(0.9, 0.9) == 3,
            "Village keypad orientation is incorrect.");

        foreach (var village in sectors.SelectMany(sector => sector.Villages))
        {
            var state = VillageTrainingScenario.Create(village);
            Check(state.Width == 13 && state.Height == 13,
                $"{village.Name} did not create a 13x13 tactical state.");
            Check(state.Units.Count == 14,
                $"{village.Name} did not create the expected v1.8 engagement units.");
            Check(state.Units.Count(unit => unit.Soldier is not null) == 12,
                $"{village.Name} did not create the expected v1.8 infantry elements.");
        }
    }

    private static void TestSpatialLosAndFactionKnowledge()
    {
        var state = new TacticalState(3, 1, 77, 100);
        for (var x = 0; x < 3; x++)
        {
            state.Tiles[x, 0] = TacticalTile.Open;
            state.World.SetCell(new GridPoint(x, 0), 100,
                new SpatialContext(TerrainType.Open, AreaType.OpenTerrain, TerritoryState.Contested,
                    100, 0, 0, 0, 0, 0));
        }

        var blue = new TacticalUnit
        {
            Id = 1, Faction = TacticalFaction.Blue, Position = new GridPoint(0, 0),
            DisplayName = "Blue test observer", UnitClass = TacticalUnitClass.Person,
            Signature = SignatureProfile.Human, EyeHeightMeters = 1.7
        };
        blue.Sensors.Add(new SensorDefinition("test-optic", "Synthetic test optic", SensorType.Visual,
            1.7, 1000, 1, 1, 360));
        var red = new TacticalUnit
        {
            Id = 2, Faction = TacticalFaction.Red, Position = new GridPoint(2, 0),
            DisplayName = "Red test vehicle", UnitClass = TacticalUnitClass.ArmoredVehicle,
            Bounds = new Bounds3D(7, 3, 2.5), Signature = new SignatureProfile(1, 1, 1, 1),
            EyeHeightMeters = 2.2
        };
        state.Units.Add(blue);
        state.Units.Add(red);

        var bluePosition = state.PositionOf(blue);
        Check(Math.Abs(bluePosition.X - 50) < 0.001 && Math.Abs(bluePosition.Y - 50) < 0.001 &&
              Math.Abs(bluePosition.Z - 101.7) < 0.001,
            "Local XYZ conversion is incorrect.");
        var los = LineOfSightEngine.Evaluate(state, blue, red);
        Check(los.State == LineOfSightState.Clear, "Flat synthetic terrain unexpectedly blocked LOS.");

        DetectionEngine.Update(state);
        var localContact = state.CommandAndControl.LocalFor(blue).GetContact(red.Id);
        Check(localContact is not null && (int)localContact.Classification >= (int)ContactClassification.ArmoredVehicle,
            "Observer-local detection contact was not created.");
        Check(state.Knowledge[TacticalFaction.Blue].GetContact(red.Id) is null,
            "v1.10 detection leaked into the faction picture before C2 delivery.");
        Check(state.Knowledge[TacticalFaction.Red].GetContact(blue.Id) is null,
            "Detection knowledge leaked reciprocally without a Red sensor.");
        var queuedReport = state.CommandAndControl.ContactReports.Single();
        Check(queuedReport.Status == ContactReportStatus.Queued,
            "Deterministic v1.10 C2 test unexpectedly dropped its contact report.");
        state.Tick = queuedReport.DeliverAtTick;
        state.CommandAndControl.ProcessReports(state);
        Check(state.Knowledge[TacticalFaction.Blue].GetContact(red.Id) is not null,
            "Queued v1.10 contact report did not enter the shared faction picture after delivery.");

        state.World.SetCell(new GridPoint(1, 0), 180,
            new SpatialContext(TerrainType.Rocky, AreaType.Wilderness, TerritoryState.Contested,
                180, 0, 0, 0.2, 0.05, 0));
        Check(LineOfSightEngine.Evaluate(state, blue, red).State == LineOfSightState.Blocked,
            "Synthetic ridge did not block 3D LOS.");
    }

    private static void TestV1InfantryEngagement()
    {
        var village = VillageMapCatalog.CreateDefault()
            .SelectMany(sector => sector.Villages)
            .First(item => item.Name == "Aytaronn");
        var first = VillageTrainingScenario.Create(village);
        var second = VillageTrainingScenario.Create(village);
        var firstRifle = first.Units.First(unit => unit.Soldier is not null).Soldier!.PrimaryWeapon;
        var originalPhysicalRange = firstRifle.Definition.MaximumPhysicalRangeMeters;
        first.Environment.ApplyPreset(LightCondition.Night, WeatherVisibility.Clear);
        second.Environment.ApplyPreset(LightCondition.Night, WeatherVisibility.Clear);
        Check(Math.Abs(firstRifle.Definition.MaximumPhysicalRangeMeters - originalPhysicalRange) < 0.001,
            "Night incorrectly changed a weapon's physical range.");

        for (var tick = 0; tick < 180; tick++)
        {
            TacticalEngine.Step(first);
            TacticalEngine.Step(second);
        }

        Check(first.CombatEvents.Count > 0, "v1.0 engagement produced no combat events.");
        Check(first.Units.Where(unit => unit.Soldier is not null)
                .Any(unit => unit.Soldier!.Vitals.Suppression01 > 0 || unit.Soldier.Vitals.Wounds.Count > 0 || !unit.Alive),
            "v1.0 engagement produced no infantry combat state change.");
        Check(first.Units.Where(unit => unit.Soldier is not null).All(unit =>
                unit.Soldier!.Vitals.BloodVolume01 is >= 0 and <= 1 &&
                unit.Soldier.Vitals.HitPoints is >= 0 and <= 100),
            "Infantry physiology escaped normalized bounds.");

        // Identical seeds and conditions must reproduce the same event stream.
        var firstMessages = first.CombatEvents.Select(item => $"{item.Tick}:{item.Message}").ToArray();
        var secondMessages = second.CombatEvents.Select(item => $"{item.Tick}:{item.Message}").ToArray();
        Check(firstMessages.SequenceEqual(secondMessages), "v1.0 engagement is not deterministic for the same seed.");
    }

    private static void TestFormationDataset()
    {
        var dataset = FormationDataLoader.LoadIdfPublicPeacetime(DataRootLocator.Find());
        Check(dataset.Formations.Count == 217, "Unexpected public IDF formation record count.");
        Check(FormationDatasetValidator.Validate(dataset).Count == 0, "Formation baseline validation failed.");
        Check(dataset.Find("north_cmd") is not null && dataset.Find("central_cmd") is not null &&
              dataset.Find("south_cmd") is not null, "Regional command nodes are missing.");
        Check(dataset.Find("div36")?.ParentId == "north_cmd" && dataset.Find("div162")?.ParentId == "south_cmd",
            "Regional division parentage is incorrect.");
        Check(dataset.Find("ground_forces")?.ParentId == "idf" && dataset.Find("north_cmd")?.ParentId == "regional_commands",
            "Ground Forces and regional operational commands were incorrectly collapsed into one chain.");
        Check(dataset.DataBoundary.Contains("deploy", StringComparison.OrdinalIgnoreCase),
            "Formation data boundary does not state its deployment limitation.");
    }

    private static void TestV12AutonomousEngagement()
    {
        var village = VillageMapCatalog.CreateDefault()
            .SelectMany(sector => sector.Villages)
            .First(item => item.Name == "Aytaronn");
        var first = VillageTrainingScenario.Create(village);
        var second = VillageTrainingScenario.Create(village);

        Check(first.ScenarioName.Contains("Crossroads", StringComparison.OrdinalIgnoreCase),
            "v1.2 autonomous scenario briefing was not loaded.");
        Check(first.Objectives.Count == 1 && first.Objectives[0].Position == new GridPoint(6, 6),
            "v1.2 central objective was not configured.");
        Check(first.UnitCommands.Count == first.Units.Count &&
              first.Units.Where(unit => unit.Soldier is not null).All(unit => unit.Path.Count > 0),
            "v1.2 pre-battle AI orders did not create movement routes.");
        var startingPositions = first.Units.ToDictionary(unit => unit.Id, unit => unit.Position);

        for (var tick = 0; tick < 180 && first.Result == BattleResult.Ongoing; tick++)
        {
            TacticalEngine.Step(first);
            TacticalEngine.Step(second);
        }

        Check(first.Units.Any(unit => unit.Position != startingPositions[unit.Id]),
            "v1.2 autonomous units never moved.");
        Check(first.ActivityEvents.Any(item => item.Type == TacticalEventType.Phase &&
                                               item.Message.Contains("ADVANCE", StringComparison.OrdinalIgnoreCase)),
            "v1.2 scenario never entered the advance phase.");
        Check(first.ActivityEvents.Any(item => item.Type == TacticalEventType.Contact),
            "v1.2 autonomous elements never made contact.");
        Check(first.CombatEvents.Any(item => item.Type == CombatEventType.Fire),
            "v1.2 autonomous elements never opened fire.");
        Check(first.Units.Where(unit => unit.Soldier is not null).Any(unit =>
                unit.Soldier!.Vitals.Wounds.Count > 0 || !unit.Soldier.IsCombatEffective),
            "v1.2 autonomous engagement produced no casualty state.");
        Check(first.Units.Select(unit => (unit.Id, unit.Position, unit.Alive))
                .SequenceEqual(second.Units.Select(unit => (unit.Id, unit.Position, unit.Alive))) &&
              first.ActivityEvents.Select(item => item.Message)
                .SequenceEqual(second.ActivityEvents.Select(item => item.Message)) &&
              first.CombatEvents.Select(item => item.Message)
                .SequenceEqual(second.CombatEvents.Select(item => item.Message)),
            "v1.2 autonomous engagement is not deterministic.");
    }

    private static void TestTheaterMapPackage()
    {
        var original = new GeoCoordinate(33.8938, 35.5018);
        var projected = WebMercator.Project(original);
        var restored = WebMercator.Unproject(projected);
        Check(Math.Abs(restored.Latitude - original.Latitude) < 0.0000001 &&
              Math.Abs(restored.Longitude - original.Longitude) < 0.0000001,
            "Web Mercator round trip lost coordinate precision.");
        Check(GeoMath.DistanceKilometers(new GeoCoordinate(33.8938, 35.5018),
                  new GeoCoordinate(32.7940, 34.9896)) is > 125 and < 145,
            "Geodesic distance calculation is outside the expected Beirut-Haifa range.");

        var package = TheaterMapLoader.LoadDefault(DataRootLocator.Find());
        Check(package.Manifest.CoordinateReferenceSystem == "EPSG:4326",
            "The theater map does not declare WGS84 coordinates.");
        Check(package.Layers.ContainsKey("lebanon-boundary") &&
              package.Layers.ContainsKey("israel-palestine-boundary") &&
              package.Layers.ContainsKey("reference-places"),
            "Required theater-map layers were not loaded.");
        Check(package.Layers["reference-places"].Count >= 20,
            "The public settlement reference layer is unexpectedly empty.");
        foreach (var optionalLayer in new[] { "roads", "water", "settlements", "terrain-contours" })
            Check(package.Layers.ContainsKey(optionalLayer) || package.MissingOptionalLayers.Contains(optionalLayer),
                $"Optional map layer '{optionalLayer}' was neither loaded nor reported missing.");
        var forbiddenPropertyNames = new[] { "target", "facility", "weaponSite", "deployment" };
        Check(package.Layers.Values.SelectMany(layer => layer).SelectMany(feature => feature.Properties.Keys)
                .All(key => !forbiddenPropertyNames.Contains(key, StringComparer.OrdinalIgnoreCase)),
            "The public map package contains a prohibited sensitive-site property.");
        Check(package.Manifest.DataBoundary.Contains("No current deployments", StringComparison.OrdinalIgnoreCase),
            "The map data boundary does not explicitly exclude current deployments.");
    }

    private static void TestVehicleDataset()
    {
        var dataset = VehicleDataLoader.LoadIdfGroundVehicleBaseline(DataRootLocator.Find());
        Check(dataset.Vehicles.Count == 6, "Unexpected IDF ground-vehicle baseline count.");
        Check(VehicleDatasetValidator.Validate(dataset).Count == 0, "Vehicle baseline validation failed.");
        foreach (var id in new[] { "merkava_mk3b", "merkava_mk3d", "merkava_mk4m", "merkava_mk4_barak", "namer_apc", "eitan_apc" })
        {
            Check(dataset.Find(id) is not null, $"Vehicle '{id}' is missing.");
        }
        var barak = dataset.Find("merkava_mk4_barak")!;
        Check(barak.Protection.Mode == ProtectionDataMode.SyntheticGameIndex &&
              barak.Protection.Zones.All(zone => zone.SyntheticKineticIndex is >= 0 and <= 1000),
            "Vehicle protection escaped the synthetic game-index model.");
        Check(barak.Signature.Boundary.Contains("RCS", StringComparison.OrdinalIgnoreCase),
            "Vehicle signature boundary does not make the non-RCS model explicit.");
        var namer = dataset.Find("namer_apc")!;
        var eitan = dataset.Find("eitan_apc")!;
        Check(namer.Kind == VehicleKind.HeavyApc && eitan.Kind == VehicleKind.WheeledApc,
            "Namer/Eitan vehicle types are incorrect.");

        var tankState = new TankEntityState("tank-test", TacticalFaction.Blue, new Position3D(0, 0, 0), barak);
        Check(tankState.Components.Count == barak.DamageComponents.Distinct(StringComparer.Ordinal).Count(),
            "Tank component damage state was not initialized.");
        Check(tankState.Crew.Count == barak.Crew.Crew && tankState.ArmorZones.Count == barak.Protection.Zones.Count,
            "Tank crew/armor runtime state was not initialized.");
        Check(tankState.Fuel.PublicCapacityLiters == barak.Mobility.PublicFuelCapacityLiters &&
              tankState.Ammunition.TotalCapacity == (barak.MainWeapon?.PublicAmmunitionCapacity ?? 0),
            "Tank fuel/ammunition state was not initialized.");
        Check(tankState.ApsGameBudgetRemaining == (barak.ActiveProtection?.GameCountermeasureBudget ?? 0),
            "Tank synthetic APS state was not initialized.");
    }

    private static void TestForceDataModes()
    {
        var dataset = ForceDataLoader.LoadBaseline(DataRootLocator.Find());
        Check(dataset.Sources.Count == 7, "Unexpected source count.");
        Check(dataset.Platforms.Count == 7, "Unexpected platform count.");
        Check(ForceDatasetValidator.Validate(dataset).Count == 0, "Baseline validation failed.");

        var f35 = dataset.FindPlatform("f35i_adir")!;
        Check(f35.Quantity.Likely == 50, "F-35 procurement value was not loaded.");
        Check(f35.ReadinessPercent is null, "Unknown readiness was converted into a value.");
        Check(dataset.FindPlatform("eitan_apc")!.ApsCoveragePercent is null,
            "Unknown Eitan APS coverage was converted into a value.");

        ForceDataLoader.ApplyOverrides(dataset,
            Path.Combine(AppContext.BaseDirectory, "fixtures", "overrides.json"));
        Check(f35.ReadinessPercent == 65 && dataset.TotalOverrides == 5,
            "Manual override was not applied.");
        Check(dataset.FindPlatform("merkava_4_barak")!.ApsCoveragePercent == 70,
            "APS override was not applied.");
        Check(dataset.FindPlatform("eitan_apc")!.Quantity.Likely == 60,
            "Quantity override was not applied.");
        Check(ForceDatasetValidator.Validate(dataset).Count == 0, "Overridden dataset validation failed.");
    }

    private static void TestTacticalSimulation()
    {
        var state = TacticalDemoScenario.Create();
        Check(state.Units.Count == 7, "Unexpected tactical unit count.");
        var selected = TacticalEngine.SelectAt(state, 3, 4);
        Check(selected == 0 && state.Units[0].Selected, "Blue unit selection failed.");
        var observedRed = TacticalEngine.SelectAt(state, 27, 13, null);
        Check(observedRed == 4 && state.Units[4].Selected,
            "Observer selection of the red faction failed.");
        selected = TacticalEngine.SelectAt(state, 3, 4);
        Check(TacticalEngine.IssueMove(state, selected, new GridPoint(10, 8)),
            "Reachable tactical movement order failed.");
        for (var tick = 0; tick < 1200 && (state.Units[0].Path.Count > 0 || state.Units[0].MovementDestinationMeters is not null); tick++)
        {
            TacticalEngine.Step(state);
        }
        Check(state.Units[0].Position == new GridPoint(10, 8), "Unit did not reach its destination.");
        Check(!TacticalEngine.IssueMove(state, selected, new GridPoint(19, 3)),
            "Movement into water was accepted.");
        Check(!TacticalEngine.HasLineOfSight(state, new GridPoint(10, 14), new GridPoint(16, 14)),
            "Building did not block line of sight.");
        Check(TacticalEngine.HasLineOfSight(state, new GridPoint(1, 1), new GridPoint(6, 1)),
            "Clear line of sight was blocked.");
    }

    private static void TestWeaponDataModes()
    {
        var dataset = WeaponDataLoader.LoadHezbollahBaseline(DataRootLocator.Find());
        Check(dataset.Sources.Count == 14, "Unexpected Hezbollah weapon source count.");
        Check(dataset.Weapons.Count == 30, "Unexpected Hezbollah weapon-system count.");
        Check(dataset.ResearchQueue.Count == 16, "Unexpected weapon research-queue count.");
        Check(WeaponDatasetValidator.Validate(dataset).Count == 0,
            "Hezbollah weapon baseline validation failed.");

        Check(dataset.Weapons.OfType<RocketSystem>().Count() == 11,
            "Rocket subclass records were not deserialized.");
        Check(dataset.Weapons.OfType<FixedWingDroneSystem>().Count() == 2,
            "Fixed-wing drone subclass records were not deserialized.");
        Check(dataset.Weapons.OfType<FpvDroneSystem>().Count() == 1,
            "FPV drone subclass record was not deserialized.");
        Check(dataset.Weapons.OfType<MortarSystem>().Count() == 1,
            "Mortar subclass record was not deserialized.");
        Check(dataset.Weapons.OfType<AtgmSystem>().Count() == 12,
            "ATGM subclass records were not deserialized.");
        Check(dataset.Weapons.OfType<CruiseMissileSystem>().Count() == 2,
            "Cruise-missile subclass records were not deserialized.");

        Check(dataset.FindWeapon("fadi_1") is not null &&
            dataset.FindWeapon("fadi_2") is not null && dataset.FindWeapon("fadi_6") is not null,
            "Corroborated Fadi records were not loaded.");
        Check(dataset.FindWeapon("fadi_3_candidate") is null &&
            dataset.ResearchQueue.Any(item => item.Id == "fadi_3_candidate"),
            "Uncorroborated Fadi variant escaped the research queue.");
        Check(dataset.ResearchQueue.Any(item => item.Id == "atcm_candidate" &&
            item.Status == CandidateReviewStatus.AmbiguousDesignation),
            "Ambiguous ATCM designation was not preserved.");

        var malyutka = dataset.FindWeapon("malyutka_9m14_sagger")!;
        var raad = dataset.FindWeapon("raad_iranian_malyutka")!;
        Check(malyutka.Id != raad.Id && malyutka.Aliases.Contains("Sagger") &&
            raad.Aliases.Contains("Raad ATGM"),
            "Malyutka and Iranian Raad identities were collapsed.");
        Check(dataset.FindWeapon("raad_2_3_rocket_family")!.Category == WeaponCategory.Rocket &&
            raad.Category == WeaponCategory.AntiTankGuidedMissile,
            "Raad rocket/ATGM name collision was not separated.");

        var almasRanges = dataset.Weapons.OfType<AtgmSystem>()
            .Where(item => item.Family == "Almas")
            .Select(item => item.Range.MaximumKm)
            .ToArray();
        Check(almasRanges.SequenceEqual(new double?[] { 4, 8, 16 }),
            "Almas variant ranges were collapsed.");

        var kornet = dataset.FindWeapon("kornet_e")!;
        var metis = dataset.FindWeapon("metis_m")!;
        var konkurs = dataset.FindWeapon("konkurs")!;
        Check(kornet.Range.MaximumKm == 5 && metis.Range.MaximumKm == 1.5 &&
            konkurs.Range.MaximumKm == 4, "Distinct ATGM ranges were collapsed.");
        Check(kornet.Accuracy.Measure == AccuracyMeasure.OperatorDependent,
            "ATGM accuracy was incorrectly represented as CEP.");

        var katyusha = dataset.FindWeapon("katyusha_107_122_family")!;
        Check(katyusha.Accuracy.Measure == AccuracyMeasure.ImpactArea &&
            katyusha.Accuracy.CepMeters is null,
            "Unguided rocket impact-area evidence was incorrectly converted to CEP.");
        Check(dataset.Weapons.All(weapon => weapon.Quantity.IsUnknown),
            "A historical weapon record was converted into a current stock count.");
        Check(dataset.Weapons.All(weapon => weapon.BaselineReliabilityPercent is null),
            "Advertised or unsourced reliability was promoted into realistic mode.");

        var fpv = dataset.FindWeapon("fiber_optic_fpv_category")!;
        var unsourcedWeather = WeatherAssessmentEngine.Assess(fpv,
            new WeatherCondition(12, 5, 3, 20, false));
        Check(!unsourcedWeather.NumericRangeAdjustmentAvailable,
            "Weather engine invented a numeric realistic-mode range adjustment.");

        WeaponDataLoader.ApplyOverrides(dataset,
            Path.Combine(AppContext.BaseDirectory, "fixtures", "weapon_overrides.json"));
        Check(dataset.TotalOverrides == 8, "Weapon override count is incorrect.");
        Check(fpv.Range.MinimumKm == 1 && fpv.Range.MaximumKm == 12 &&
            fpv.BaselineReliabilityPercent == 55,
            "FPV manual overrides were not applied.");
        var manualWeather = WeatherAssessmentEngine.Assess(fpv,
            new WeatherCondition(12, 5, 3, 20, false), 0.8);
        Check(manualWeather.NumericRangeAdjustmentAvailable &&
            Math.Abs(manualWeather.AdjustedMaximumRangeKm!.Value - 9.6) < 0.0001,
            "Manual weather what-if did not apply its explicit multiplier.");
        Check(WeaponDatasetValidator.Validate(dataset).Count == 0,
            "Overridden weapon dataset validation failed.");
    }

    private static void TestTheaterDeterminism()
    {
        var first = SouthLebanon2026Scenario.Create(42);
        var second = SouthLebanon2026Scenario.Create(42);
        TheaterEngine.Run(first, 72);
        TheaterEngine.Run(second, 72);
        Check(TheaterEngine.GetOutcome(first) == TheaterEngine.GetOutcome(second),
            "Equal seeds produced different outcomes.");
        Check(first.Events.SequenceEqual(second.Events), "Equal seeds produced different timelines.");
        Check(first.Hour == 72 && first.Events.Count > 0, "Observer run did not advance.");

        var outcome = TheaterEngine.GetOutcome(first);
        Check(outcome.CivilianRisk is >= 0 and <= 100, "Civilian risk escaped its bounds.");
        Check(outcome.Infrastructure is >= 0 and <= 100, "Infrastructure escaped its bounds.");
        Check(outcome.Escalation is >= 0 and <= 100, "Escalation escaped its bounds.");
    }


    private static void TestV17ContinuousSpatialModel()
    {
        var state = new TacticalState(4, 4, 1701, 25);
        for (var y = 0; y < state.Height; y++)
        for (var x = 0; x < state.Width; x++)
        {
            state.Tiles[x, y] = TacticalTile.Open;
            state.World.SetCell(new GridPoint(x, y), 100,
                new SpatialContext(TerrainType.Open, AreaType.OpenTerrain, TerritoryState.Contested,
                    100, 0, 0, 0.05, 0.02, 0));
        }
        var first = new TacticalUnit
        {
            Id = 1, EntityKey = "continuous-a", Faction = TacticalFaction.Blue,
            Position = new GridPoint(1, 1), DisplayName = "Continuous A"
        };
        var second = new TacticalUnit
        {
            Id = 2, EntityKey = "continuous-b", Faction = TacticalFaction.Blue,
            Position = new GridPoint(1, 1), DisplayName = "Continuous B"
        };
        var center = state.World.CellCenter(new GridPoint(1, 1), 0);
        first.SetGroundPosition(state, center with { X = center.X - 2.0 });
        second.SetGroundPosition(state, center with { X = center.X + 2.0 });
        state.Units.Add(first);
        state.Units.Add(second);
        state.RebuildSpatialIndex();

        Check(first.Position == second.Position, "v1.7 no longer permits multiple individuals in one coarse navigation cell.");
        Check(state.GroundPositionOf(first).HorizontalDistanceTo(state.GroundPositionOf(second)) > 3.9,
            "v1.7 continuous positions collapsed to the coarse cell center.");
        Check(state.SpatialIndex.QueryRadius(center, 5).Count == 2,
            "v1.7 spatial hash did not return nearby continuous entities.");
    }

    private static void TestV17SmallArmsAndScenarioPackage()
    {
        var dataRoot = DataRootLocator.Find();
        var database = SmallArmsDataLoader.LoadHezbollahSmallArms(dataRoot);
        Check(database.Weapons.Count == 18, "Unexpected v1.7 Hezbollah small-arms record count.");
        foreach (var id in new[] { "hez-ak74", "hez-ak74m", "hez-aks74", "hez-ak104", "hez-pkm", "hez-hoshdar-m" })
            Check(database.Weapons.Any(item => item.Id == id), $"Small-arm '{id}' is missing from the v1.7 OSINT seed dataset.");

        var cartridges = AmmunitionDataLoader.LoadSmallArmsCartridgeFamilies(dataRoot);
        Check(cartridges.Cartridges.Count == 6, "Unexpected v1.7 cartridge-family count.");
        Check(cartridges.Cartridges.All(item => item.SimulationProjectileProfileId is null),
            "v1.7 cartridge identity dataset unexpectedly contains terminal-effect profiles.");

        var package = ScenarioPackageLoader.LoadV17(dataRoot);
        Check(package.EntityAssignments.Count == 14, "Unexpected v1.8 scenario entity-assignment count.");
        Check(package.EntityAssignments.Select(item => item.EntityKey).Distinct(StringComparer.Ordinal).Count() == 14,
            "v1.8 scenario entity keys are not stable/unique.");

        var village = VillageMapCatalog.CreateDefault().SelectMany(sector => sector.Villages)
            .First(item => item.Id == package.VillageId);
        var weaponAssignments = package.EntityAssignments
            .Where(item => !string.IsNullOrWhiteSpace(item.WeaponId))
            .ToDictionary(item => item.EntityKey, item => item.WeaponId!, StringComparer.Ordinal);
        var initialPlacements = package.EntityAssignments
            .Where(item => item.InitialPlacement is not null)
            .ToDictionary(item => item.EntityKey, item => item.InitialPlacement!, StringComparer.Ordinal);
        Check(initialPlacements.Count == 14, "v1.8 scenario package did not provide authored local-meter placement for every integration entity.");

        var state = VillageTrainingScenario.Create(village, database, weaponAssignments, initialPlacements);
        var redByKey = state.Units.Where(unit => unit.Faction == TacticalFaction.Red)
            .ToDictionary(unit => unit.EntityKey, StringComparer.Ordinal);
        Check(redByKey["red-leader-01"].Soldier?.PrimaryWeapon.Definition.Id == "hez-ak104",
            "v1.7 red leader did not receive the scenario's OSINT-backed weapon definition.");
        Check(redByKey["red-auto-01"].Soldier?.PrimaryWeapon.Definition.Id == "hez-pkm",
            "v1.7 machine gunner did not receive the PKM runtime definition.");
        Check(redByKey["red-marksman-01"].Soldier?.PrimaryWeapon.Definition.Id == "hez-hoshdar-m",
            "v1.7 marksman did not receive the Hoshdar-M runtime definition.");

        var expectedLeaderPlacement = package.EntityAssignments
            .Single(item => item.EntityKey == "red-leader-01").InitialPlacement!;
        var actualLeaderPlacement = state.GroundPositionOf(redByKey["red-leader-01"]);
        Check(Math.Abs(actualLeaderPlacement.X - expectedLeaderPlacement.XMeters) < 0.01 &&
              Math.Abs(actualLeaderPlacement.Y - expectedLeaderPlacement.YMeters) < 0.01,
            "v1.7 scenario-authored exact local-meter placement was not applied to the runtime entity.");
    }

    private static void TestV17OrbatSpatialAggregation()
    {
        var dataRoot = DataRootLocator.Find();
        var database = SmallArmsDataLoader.LoadHezbollahSmallArms(dataRoot);
        var package = ScenarioPackageLoader.LoadV17(dataRoot);
        var orbat = ScenarioOrbatDataLoader.LoadPrototype(dataRoot);
        Check(ScenarioOrbatDataset.Validate(orbat).Count == 0, "v1.7 ORBAT graph validation failed.");
        Check(orbat.Find("blue-inf-a1-s1") is not null, "v1.7 Blue squad-level ORBAT node is missing.");

        var village = VillageMapCatalog.CreateDefault().SelectMany(sector => sector.Villages)
            .First(item => item.Id == package.VillageId);
        var weaponAssignments = package.EntityAssignments
            .Where(item => !string.IsNullOrWhiteSpace(item.WeaponId))
            .ToDictionary(item => item.EntityKey, item => item.WeaponId!, StringComparer.Ordinal);
        var initialPlacements = package.EntityAssignments
            .Where(item => item.InitialPlacement is not null)
            .ToDictionary(item => item.EntityKey, item => item.InitialPlacement!, StringComparer.Ordinal);
        var state = VillageTrainingScenario.Create(village, database, weaponAssignments, initialPlacements);
        var assignments = package.EntityAssignments.ToDictionary(item => item.EntityKey, item => item.OrbatNodeId, StringComparer.Ordinal);
        var spatial = FormationSpatialCalculator.Calculate(orbat, "blue-inf-a1", assignments, state.Units, state);
        Check(spatial is not null && spatial.EntityCount == 5,
            "v1.7 formation centroid did not derive from platoon member entities.");
        Check(spatial!.DispersionRadiusMeters >= 0 && spatial.FrontageMeters >= 0,
            "v1.7 formation spatial metrics are invalid.");
    }

    private static void TestV17LosSamplingStability()
    {
        var world = new TacticalWorldModel(8, 1, 25);
        for (var x = 0; x < 8; x++)
        {
            var point = new GridPoint(x, 0);
            world.SetCell(point, 100,
                new SpatialContext(TerrainType.Scrub, AreaType.OpenTerrain, TerritoryState.Contested,
                    100, 0.45, 0.05, 0.08, 0.18, 0));
        }
        var from = new Position3D(5, 12.5, 102);
        var to = new Position3D(195, 12.5, 102);
        var fine = LineOfSightEngine.Evaluate(world, from, to, 5);
        var coarse = LineOfSightEngine.Evaluate(world, from, to, 20);
        Check(fine.State != LineOfSightState.Blocked && coarse.State != LineOfSightState.Blocked,
            "Synthetic scrub unexpectedly blocked the v1.7 LOS stability test.");
        Check(Math.Abs(fine.ObscurationFactor - coarse.ObscurationFactor) < 0.04,
            "LOS obscuration still changes materially with sampling resolution.");
    }

    private static void TestV17FormationDestinationDistribution()
    {
        var state = new TacticalState(4, 4, 1702, 25);
        for (var y = 0; y < state.Height; y++)
        for (var x = 0; x < state.Width; x++)
        {
            state.Tiles[x, y] = TacticalTile.Open;
            state.World.SetCell(new GridPoint(x, y), 50,
                new SpatialContext(TerrainType.Open, AreaType.OpenTerrain, TerritoryState.Contested,
                    50, 0, 0, 0, 0, 0));
        }

        var units = Enumerable.Range(1, 5).Select(id => new TacticalUnit
        {
            Id = id,
            EntityKey = $"dist-{id}",
            Faction = TacticalFaction.Blue,
            Position = new GridPoint(0, 0),
            DisplayName = $"Distributed {id}"
        }).ToArray();
        foreach (var unit in units) state.Units.Add(unit);
        state.EnsurePrecisePositions();
        var center = state.World.CellCenter(new GridPoint(2, 2), 0);
        var destinations = FormationDestinationAllocator.Allocate(state, units, center);

        Check(destinations.Count == units.Length, "v1.7 did not allocate one destination per formation member.");
        Check(destinations.Values.Select(position => (Math.Round(position.X, 2), Math.Round(position.Y, 2))).Distinct().Count() == units.Length,
            "v1.7 formation destination allocator stacked all members on one coordinate.");
        Check(destinations.Values.All(position => state.InBounds(
                state.World.GridPointFromWorld(position.X, position.Y).X,
                state.World.GridPointFromWorld(position.X, position.Y).Y)),
            "v1.7 formation destination allocator produced an out-of-world destination.");
    }

    private static void TestV17StructureLodAndJournalScaffold()
    {
        var structure = new StructureVolume
        {
            Id = "synthetic-structure-1",
            Name = "Synthetic multi-level test volume",
            Type = StructureVolumeType.Bunker,
            Bounds = new AxisAlignedBounds3D(new Position3D(0, 0, -8), new Position3D(20, 20, 8)),
            Compartments =
            [
                new StructureCompartment
                {
                    Id = "surface-room", Name = "Surface room", LevelIndex = 0,
                    Bounds = new AxisAlignedBounds3D(new Position3D(0, 0, 0), new Position3D(10, 10, 4)),
                    DominantMaterial = StructureMaterialClass.Masonry
                },
                new StructureCompartment
                {
                    Id = "lower-room", Name = "Lower room", LevelIndex = -1,
                    Bounds = new AxisAlignedBounds3D(new Position3D(0, 0, -6), new Position3D(10, 10, -2)),
                    DominantMaterial = StructureMaterialClass.ReinforcedConcrete
                }
            ],
            Portals =
            [
                new NavigationPortal("stairs-1", "surface-room", "lower-room", NavigationPortalType.Stair,
                    new Position3D(5, 5, -1))
            ]
        };
        Check(structure.CompartmentAt(new Position3D(4, 4, -4))?.Id == "lower-room",
            "v1.7 structure scaffold cannot resolve an underground compartment.");
        Check(structure.PortalsFor("lower-room").Count() == 1,
            "v1.7 structure scaffold did not expose the level connection.");

        var policy = new SimulationLodPolicy(EntityRadiusMeters: 2000, CloseQuartersRadiusMeters: 200);
        Check(policy.Select(100, false, false, true) == SimulationDetailLevel.CloseQuarters,
            "v1.7 LOD policy did not promote a detailed structure to close-quarters simulation.");
        Check(policy.Select(10_000, false, false, false) == SimulationDetailLevel.AggregateFormation,
            "v1.7 LOD policy did not aggregate a distant inactive formation.");

        var journal = new SimulationJournal(100);
        journal.Append(1, "Scenario", "Synthetic journal event");
        journal.Append(2, "Movement", "Synthetic movement event", "entity-1", TacticalFaction.Blue);
        Check(journal.Since(1).Count == 1 && journal.Since(1)[0].EntityKey == "entity-1",
            "v1.7 semantic event journal sequence filtering failed.");
    }

    private static void TestV18OpenEndedInfrastructureAndSupport()
    {
        var state = new TacticalState(2, 1, 1801, 25) { OpenEndedScenario = true };
        state.Tiles[0, 0] = TacticalTile.Road;
        state.Tiles[1, 0] = TacticalTile.Open;
        state.Infrastructure.SeedFromTiles(state.Tiles);
        var road = state.Infrastructure.RoadAt(new GridPoint(0, 0));
        Check(road is not null && road.UsableByVehicles, "v1.8 road state was not seeded from tactical terrain.");
        road!.ApplyDamage(85, 80);
        Check(!road.UsableByVehicles && road.UsableOnFoot,
            "v1.8 damaged road did not distinguish vehicle and foot usability.");
        road.Repair(45, 70);
        Check(road.UsableByVehicles && road.CapacityMultiplier > 0,
            "v1.8 road repair did not restore route capacity.");

        state.Units.Add(new TacticalUnit
        {
            Id = 1, EntityKey = "open-ended-blue", Faction = TacticalFaction.Blue,
            Position = new GridPoint(1, 0), DisplayName = "Open-ended survivor",
            Soldier = new SoldierRuntime { Role = SoldierRole.Rifleman, PrimaryWeapon = new WeaponRuntime { Definition = InfantryWeaponDefinition.GenericRifle() } }
        });
        TacticalAiEngine.UpdateBattleState(state);
        Check(state.Result == BattleResult.Ongoing,
            "v1.8 open-ended tactical state declared a terminal battle result.");

        var asset = new SupportAssetRuntime
        {
            Id = "rescue-test-1",
            Faction = TacticalFaction.Blue,
            Definition = new SupportAssetDefinition
            {
                Id = "rescue-capability", DisplayName = "Synthetic rescue asset",
                Kind = SupportAssetKind.RescueHelicopter,
                DataBoundary = "Synthetic executable test asset."
            },
            Availability = new AssetState { AssetId = "rescue-test-1", PlatformId = "rescue-capability" }
        };
        state.OperationalSupport.Assets.Add(asset);
        var request = new SupportRequest
        {
            Id = "medevac-test-1", RequesterEntityKey = "open-ended-blue",
            Faction = TacticalFaction.Blue, Kind = SupportRequestKind.CasualtyEvacuation,
            CreatedTick = 0
        };
        Check(state.OperationalSupport.Queue(request, 2), "v1.8 support request could not be queued.");
        state.OperationalSupport.Process(2);
        Check(request.Status == SupportRequestStatus.Assigned && request.AssignedAssetId == asset.Id,
            "v1.8 support coordinator did not assign a compatible ready rescue asset.");
    }


    private static void TestV193ScenarioPlacementRepair()
    {
        var dataRoot = DataRootLocator.Find();
        var package = ScenarioPackageLoader.LoadCountryScaleV193(dataRoot);
        var resolver = new ScenarioPlacementResolver(package);
        var anchor = resolver.AnchorPoint(CountryScaleScenario.PrimaryAnchorId);

        Check(Math.Abs(anchor.X - 41_447.9) < 25 && Math.Abs(anchor.Y - 23_625.1) < 25,
            "v1.9.3 Bint Jbeil anchor did not project to the expected local theater area.");
        Check(resolver.InsideTheater(anchor), "v1.9.3 Bint Jbeil anchor fell outside the country-scale theater.");
        Check(package.PlacementZones.Count >= 15, "v1.9.3 placement zones were not loaded.");
        Check(package.SupportPlacements.Count == 17, "v1.9.3 support placement count is incorrect.");
        Check(package.Objectives.Count == 2, "v1.9.3 meter-native scenario objectives are missing.");

        var database = SmallArmsDataLoader.LoadHezbollahSmallArms(dataRoot);
        var weaponAssignments = package.EntityAssignments
            .Where(item => !string.IsNullOrWhiteSpace(item.WeaponId))
            .ToDictionary(item => item.EntityKey, item => item.WeaponId!, StringComparer.Ordinal);
        var state = CountryScaleScenario.Create(package, database, weaponAssignments);
        Check(state.Units.Count == 14, "v1.9.3 scenario did not create the expected integration entities.");
        Check(state.Objectives.Count == 2 && state.Objectives.All(item => item.PrecisePositionMeters is not null),
            "v1.9.3 objectives did not use continuous meter coordinates.");
        Check(state.Objectives.All(item => item.CaptureRadiusMeters is > 0 and < 500),
            "v1.9.3 objective control radii fell back to kilometer-scale cells.");

        foreach (var assignment in package.EntityAssignments)
        {
            var authored = assignment.InitialPlacement!;
            var expected = resolver.Resolve(authored);
            var unit = state.Units.Single(item => item.EntityKey == assignment.EntityKey);
            var actual = state.GroundPositionOf(unit);
            Check(Math.Abs(expected.X - actual.X) < 0.01 && Math.Abs(expected.Y - actual.Y) < 0.01,
                $"v1.9.3 runtime entity '{assignment.EntityKey}' ignored its zone-authored placement.");
        }

        var redPositions = state.Units.Where(item => item.Faction == TacticalFaction.Red)
            .Select(state.GroundPositionOf).ToArray();
        var bluePositions = state.Units.Where(item => item.Faction == TacticalFaction.Blue)
            .Select(state.GroundPositionOf).ToArray();
        Check(redPositions.All(point => new ScenarioLocalPoint(point.X, point.Y).DistanceTo(anchor) < 3_500),
            "v1.9.3 Red integration force is no longer clustered around the Bint Jbeil defense scenario.");
        Check(bluePositions.All(point => point.Y < anchor.Y),
            "v1.9.3 Blue approach force did not start south of the Bint Jbeil scenario anchor.");
        Check(state.Units.All(item => Math.Abs(state.GroundPositionOf(item).X - 76_000) > 5_000),
            "v1.9.3 still appears to be using the old magic ActiveAreaCenter placement.");
    }

    private static void TestV110UrbanC2Core()
    {
        var dataRoot = DataRootLocator.Find();
        var package = ScenarioPackageLoader.LoadCountryScaleV110(dataRoot);
        Check(package.Id == "fieldsim-v1-10-urban-c2-diagnostics",
            "v1.10 scenario package id is incorrect.");
        Check(package.Objectives.Count == 2 && package.SupportPlacements.Count == 17,
            "v1.10 scenario package lost the v1.9.3 placement/objective baseline.");

        var database = SmallArmsDataLoader.LoadHezbollahSmallArms(dataRoot);
        var weaponAssignments = package.EntityAssignments
            .Where(item => !string.IsNullOrWhiteSpace(item.WeaponId))
            .ToDictionary(item => item.EntityKey, item => item.WeaponId!, StringComparer.Ordinal);
        var state = CountryScaleScenario.Create(package, database, weaponAssignments);

        Check(state.Structures.Count >= 20 && state.Structures.All(item => item.SyntheticScenarioElement),
            "v1.10 synthetic urban layer was not created.");
        Check(state.Structures.All(item => item.Compartments.Count >= 4 && item.Portals.Count >= 4),
            "v1.10 synthetic structures are missing compartment/portal metadata.");
        var medicalAssets = state.OperationalSupport.Assets
            .Where(asset => asset.Definition.Kind == SupportAssetKind.MedicalTeam)
            .ToArray();
        Check(medicalAssets.Length == 2,
            "v1.10 synthetic medical support assets were not initialized.");
        Check(medicalAssets.Count(asset => asset.Faction == TacticalFaction.Blue) == 1 &&
              medicalAssets.Count(asset => asset.Faction == TacticalFaction.Red) == 1,
            "v1.10 medical support assets are not faction-bound.");

        var blueEvac = new SupportRequest
        {
            Id = "v110-blue-evac-test", RequesterEntityKey = "test-blue", Faction = TacticalFaction.Blue,
            Kind = SupportRequestKind.CasualtyEvacuation, CreatedTick = state.Tick
        };
        var redEvac = new SupportRequest
        {
            Id = "v110-red-evac-test", RequesterEntityKey = "test-red", Faction = TacticalFaction.Red,
            Kind = SupportRequestKind.CasualtyEvacuation, CreatedTick = state.Tick
        };
        Check(state.OperationalSupport.Queue(blueEvac, 1) && state.OperationalSupport.Queue(redEvac, 1),
            "v1.10 faction support requests could not be queued.");
        state.OperationalSupport.Process(state.Tick + 1);
        Check(blueEvac.Status == SupportRequestStatus.Assigned &&
              state.OperationalSupport.Assets.Single(asset => asset.Id == blueEvac.AssignedAssetId).Faction == TacticalFaction.Blue,
            "v1.10 Blue casualty request cross-assigned or failed to assign its same-side medical asset.");
        Check(redEvac.Status == SupportRequestStatus.Assigned &&
              state.OperationalSupport.Assets.Single(asset => asset.Id == redEvac.AssignedAssetId).Faction == TacticalFaction.Red,
            "v1.10 Red casualty request cross-assigned or failed to assign its same-side medical asset.");

        var structure = state.Structures[0];
        var center = structure.Bounds.Center;
        var losHeight = Math.Max(structure.Bounds.Minimum.Z + 1.7, center.Z);
        var from = new Position3D(structure.Bounds.Minimum.X - 15, center.Y, losHeight);
        var to = new Position3D(structure.Bounds.Maximum.X + 15, center.Y, losHeight);
        Check(LineOfSightEngine.Evaluate(state, from, to).State == LineOfSightState.Blocked,
            "v1.10 synthetic structure did not block line of sight.");

        var mover = state.Units.First(unit => unit.UnitClass == TacticalUnitClass.Person);
        var moverIndex = state.Units.IndexOf(mover);
        Check(!TacticalEngine.IssueMoveMeters(state, moverIndex, new Position3D(-1, center.Y, 0)) &&
              !TacticalEngine.IssueMoveMeters(state, moverIndex,
                  new Position3D(state.Width * state.World.CellSizeMeters + 1, center.Y, 0)),
            "v1.10 exact movement accepted an out-of-theater destination.");
        mover.SetGroundPosition(state, new Position3D(structure.Bounds.Minimum.X - 20, center.Y, 0));
        var destination = new Position3D(structure.Bounds.Maximum.X + 20, center.Y, 0);
        Check(UrbanSpatialQueries.TryFindDetour(state, mover, state.GroundPositionOf(mover), destination, out var detour) && detour.Count > 0,
            "v1.10 meter-native urban detour could not route around a synthetic structure.");

        var casualty = state.Units.First(unit => unit.Soldier is not null);
        casualty.Soldier!.Vitals.Condition |= SoldierCondition.Incapacitated;
        CasualtyLogisticsEngine.Update(state);
        Check(casualty.Soldier.EvacuationRequestId is not null &&
              state.OperationalSupport.Requests.Any(item => item.Id == casualty.Soldier.EvacuationRequestId),
            "v1.10 incapacitated casualty did not create an evacuation request.");

        Check(state.Objectives.All(item => item.BlueProgress == ObjectiveProgressState.Unreached &&
                                           item.RedProgress == ObjectiveProgressState.Unreached),
            "v1.10 objective progress did not start in the unreached state.");

        // Shared/stale contact knowledge must not be enough to fire using the target's current
        // authoritative position. A shooter needs a fresh local detection.
        var knowledgeState = new TacticalState(4, 4, 11010, 25);
        for (var y = 0; y < knowledgeState.Height; y++)
        for (var x = 0; x < knowledgeState.Width; x++)
        {
            knowledgeState.Tiles[x, y] = TacticalTile.Open;
            knowledgeState.World.SetCell(new GridPoint(x, y), 0,
                new SpatialContext(TerrainType.Open, AreaType.OpenTerrain, TerritoryState.Contested,
                    0, 0, 0, 0, 0, 0));
        }
        var shooterWeapon = new WeaponRuntime { Definition = InfantryWeaponDefinition.GenericRifle() };
        shooterWeapon.InitializeAmmo(60);
        var shooter = new TacticalUnit
        {
            Id = 101, EntityKey = "knowledge-blue", Faction = TacticalFaction.Blue,
            Position = new GridPoint(1, 1), PrecisePositionMeters = new Position3D(30, 30, 0),
            DisplayName = "Knowledge Blue",
            Soldier = new SoldierRuntime { PrimaryWeapon = shooterWeapon }
        };
        var targetWeapon = new WeaponRuntime { Definition = InfantryWeaponDefinition.GenericRifle() };
        targetWeapon.InitializeAmmo(60);
        var targetUnit = new TacticalUnit
        {
            Id = 102, EntityKey = "knowledge-red", Faction = TacticalFaction.Red,
            Position = new GridPoint(2, 1), PrecisePositionMeters = new Position3D(55, 30, 0),
            DisplayName = "Knowledge Red",
            Soldier = new SoldierRuntime { PrimaryWeapon = targetWeapon }
        };
        knowledgeState.Units.Add(shooter);
        knowledgeState.Units.Add(targetUnit);
        knowledgeState.EnsurePrecisePositions();
        knowledgeState.Knowledge[TacticalFaction.Blue].UpdateContact(new DetectionContact
        {
            ObserverUnitId = shooter.Id, TargetUnitId = targetUnit.Id, ObserverFaction = TacticalFaction.Blue,
            LastKnownPosition = new Position3D(50, 30, 1), LastDetectedTick = knowledgeState.Tick,
            Classification = ContactClassification.Person, DetectionConfidence = 0.9, IdentificationConfidence = 0.9
        });
        EngagementEngine.Step(knowledgeState);
        Check(!knowledgeState.CombatEvents.Any(item => item.Type == CombatEventType.Fire && item.SourceUnitId == shooter.Id),
            "v1.10 shared contact knowledge leaked enough authoritative target state to permit firing without local detection.");

        // Objective control must be revocable: enter/secure, then abandon should become Lost.
        var objectiveState = new TacticalState(4, 4, 11011, 25) { OpenEndedScenario = true };
        for (var y = 0; y < objectiveState.Height; y++)
        for (var x = 0; x < objectiveState.Width; x++)
        {
            objectiveState.Tiles[x, y] = TacticalTile.Open;
            objectiveState.World.SetCell(new GridPoint(x, y), 0,
                new SpatialContext(TerrainType.Open, AreaType.OpenTerrain, TerritoryState.Contested,
                    0, 0, 0, 0, 0, 0));
        }
        var objectiveWeapon = new WeaponRuntime { Definition = InfantryWeaponDefinition.GenericRifle() };
        objectiveWeapon.InitializeAmmo(60);
        var objectiveUnit = new TacticalUnit
        {
            Id = 201, EntityKey = "objective-blue", Faction = TacticalFaction.Blue,
            Position = new GridPoint(1, 1), PrecisePositionMeters = new Position3D(37.5, 37.5, 0),
            DisplayName = "Objective Blue",
            Soldier = new SoldierRuntime { PrimaryWeapon = objectiveWeapon }
        };
        objectiveState.Units.Add(objectiveUnit);
        objectiveState.Objectives.Add(new BattleObjective
        {
            Id = "objective-test", DisplayName = "Objective test", Position = new GridPoint(1, 1),
            PrecisePositionMeters = new Position3D(37.5, 37.5, 0), CaptureRadiusMeters = 10,
            CaptureRadiusCells = 0, RequiredControlSeconds = 2
        });
        TacticalAiEngine.UpdateBattleState(objectiveState);
        TacticalAiEngine.UpdateBattleState(objectiveState);
        Check(objectiveState.Objectives[0].BlueProgress == ObjectiveProgressState.Secured,
            "v1.10 objective did not reach Secured after sustained uncontested presence.");
        objectiveUnit.SetGroundPosition(objectiveState, new Position3D(87.5, 87.5, 0));
        TacticalAiEngine.UpdateBattleState(objectiveState);
        Check(objectiveState.Objectives[0].BlueProgress == ObjectiveProgressState.Lost,
            "v1.10 abandoned secured objective did not transition to Lost.");
    }

    private static void Check(bool condition, string message)
    {
        _checks++;
        if (!condition) throw new InvalidOperationException(message);
    }
}
