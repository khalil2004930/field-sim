param(
    [string]$OutputDirectory = "",
    [switch]$IncludeElevation,
    [switch]$ForceDownload
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$projectRoot = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $OutputDirectory = Join-Path $projectRoot "data\maps\theater\generated"
}
$downloadDirectory = Join-Path $projectRoot "map_downloads"
New-Item -ItemType Directory -Force -Path $OutputDirectory, $downloadDirectory | Out-Null

foreach ($tool in @("ogr2ogr", "ogrmerge.py")) {
    if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
        throw "Required GDAL/OGR command '$tool' was not found. Run this from an OSGeo4W/QGIS shell or add GDAL to PATH."
    }
}

function Get-PublicFile([string]$Url, [string]$Destination) {
    if ($ForceDownload -or -not (Test-Path $Destination)) {
        Write-Host "Downloading $Url"
        Invoke-WebRequest -Uri $Url -OutFile $Destination
    } else {
        Write-Host "Using cached $Destination"
    }
}

function Invoke-Checked([string]$Command, [string[]]$Arguments) {
    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Command failed with exit code $LASTEXITCODE." }
}

$extracts = @(
    @{ Name = "lebanon"; Url = "https://download.geofabrik.de/asia/lebanon-latest.osm.pbf" },
    @{ Name = "israel_palestine"; Url = "https://download.geofabrik.de/asia/israel-and-palestine-latest.osm.pbf" }
)

$roadParts = @()
$waterParts = @()
$settlementParts = @()
foreach ($extract in $extracts) {
    $pbf = Join-Path $downloadDirectory ($extract.Name + ".osm.pbf")
    Get-PublicFile $extract.Url $pbf

    $roads = Join-Path $downloadDirectory ($extract.Name + "_roads.geojson")
    $water = Join-Path $downloadDirectory ($extract.Name + "_water.geojson")
    $settlements = Join-Path $downloadDirectory ($extract.Name + "_settlements.geojson")
    Invoke-Checked "ogr2ogr" @("-f", "GeoJSON", "-overwrite", "-lco", "RFC7946=YES",
        "-spat", "33.65", "29.35", "36.75", "34.85", "-simplify", "0.00015",
        $roads, $pbf, "lines", "-where", "highway IS NOT NULL")
    Invoke-Checked "ogr2ogr" @("-f", "GeoJSON", "-overwrite", "-lco", "RFC7946=YES",
        "-spat", "33.65", "29.35", "36.75", "34.85", "-simplify", "0.00015",
        $water, $pbf, "multipolygons", "-where", "natural='water' OR waterway IS NOT NULL")
    Invoke-Checked "ogr2ogr" @("-f", "GeoJSON", "-overwrite", "-lco", "RFC7946=YES",
        "-spat", "33.65", "29.35", "36.75", "34.85",
        $settlements, $pbf, "points", "-where", "place IN ('city','town','village')")
    $roadParts += $roads
    $waterParts += $water
    $settlementParts += $settlements
}

Invoke-Checked "ogrmerge.py" (@("-single", "-overwrite_ds", "-f", "GeoJSON", "-o",
    (Join-Path $OutputDirectory "roads.geojson")) + $roadParts)
Invoke-Checked "ogrmerge.py" (@("-single", "-overwrite_ds", "-f", "GeoJSON", "-o",
    (Join-Path $OutputDirectory "water.geojson")) + $waterParts)
Invoke-Checked "ogrmerge.py" (@("-single", "-overwrite_ds", "-f", "GeoJSON", "-o",
    (Join-Path $OutputDirectory "settlements.geojson")) + $settlementParts)

if ($IncludeElevation) {
    foreach ($tool in @("gdalbuildvrt", "gdal_contour")) {
        if (-not (Get-Command $tool -ErrorAction SilentlyContinue)) {
            throw "Required elevation command '$tool' was not found."
        }
    }
    $tileCodes = @("N32_00_E034_00", "N32_00_E035_00", "N33_00_E034_00", "N33_00_E035_00")
    $tiles = @()
    foreach ($code in $tileCodes) {
        $baseName = "Copernicus_DSM_COG_10_${code}_DEM"
        $tile = Join-Path $downloadDirectory ($baseName + ".tif")
        Get-PublicFile "https://copernicus-dem-30m.s3.amazonaws.com/$baseName/$baseName.tif" $tile
        $tiles += $tile
    }
    $vrt = Join-Path $downloadDirectory "south_lebanon_dem.vrt"
    $rawContours = Join-Path $downloadDirectory "terrain_contours_raw.geojson"
    Invoke-Checked "gdalbuildvrt" (@($vrt) + $tiles)
    Invoke-Checked "gdal_contour" @("-i", "50", "-a", "elevation_m", "-f", "GeoJSON", $vrt, $rawContours)
    Invoke-Checked "ogr2ogr" @("-f", "GeoJSON", "-overwrite", "-lco", "RFC7946=YES",
        "-clipsrc", "34.92", "32.90", "35.80", "33.68", "-simplify", "0.0001",
        (Join-Path $OutputDirectory "terrain_contours.geojson"), $rawContours)
}

Write-Host "Map layers prepared in $OutputDirectory"
Write-Host "Validate with: dotnet run --project src\FieldSim.Runner -- map status"
